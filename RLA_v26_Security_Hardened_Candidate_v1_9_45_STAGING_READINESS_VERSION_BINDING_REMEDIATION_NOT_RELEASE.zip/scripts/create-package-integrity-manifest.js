'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { createPackageIntegrityManifest } = require('../app/package-integrity-manifest');
const rootDir = path.resolve(__dirname, '..');
const outputPath = path.resolve(process.argv[2] || path.join(rootDir, 'docs', 'package-integrity-manifest-v1.9.8.json'));
try {
  const manifest = createPackageIntegrityManifest({ rootDir, manifestPath: outputPath });
  fs.mkdirSync(path.dirname(outputPath), { recursive: true, mode: 0o700 });
  const fd = fs.openSync(outputPath, 'wx', 0o600);
  try { fs.writeFileSync(fd, JSON.stringify(manifest, null, 2) + '\n', 'utf8'); fs.fsyncSync(fd); }
  finally { fs.closeSync(fd); }
  process.stdout.write(JSON.stringify({ status: 'PASS', manifestPath: outputPath, entryCount: manifest.entryCount, packageName: manifest.packageName, packageVersion: manifest.packageVersion }) + '\n');
} catch (error) {
  process.stderr.write(`${error.message || 'PACKAGE_INTEGRITY_MANIFEST_CREATE_FAILED'}\n`);
  process.exitCode = 2;
}
