#!/usr/bin/env node
'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const { stageVerifiedBackup } = require('../app/backup-manifest');

function validateOperatorAttestation(env = process.env) {
  if (env.RLA_RESTORE_CONFIRM !== 'YES') {
    throw new Error('Restore blocked: set RLA_RESTORE_CONFIRM=YES after reviewing the target and recovery plan');
  }
  if (env.RLA_RESTORE_MAINTENANCE_MODE !== 'STOPPED') {
    throw new Error('Restore blocked: set RLA_RESTORE_MAINTENANCE_MODE=STOPPED only after stopping the application and database writers');
  }
  if (typeof env.RLA_BACKUP_MANIFEST_KEY !== 'string' || Buffer.byteLength(env.RLA_BACKUP_MANIFEST_KEY, 'utf8') < 32) {
    throw new Error('Restore blocked: RLA_BACKUP_MANIFEST_KEY must contain at least 32 UTF-8 bytes');
  }
}

function hashFile(filePath) {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash('sha256');
    const stream = fs.createReadStream(filePath);
    stream.on('error', reject);
    stream.on('data', chunk => hash.update(chunk));
    stream.on('end', () => resolve(hash.digest('hex')));
  });
}

function sqliteIntegrity(sqlite3, filename) {
  return new Promise((resolve, reject) => {
    const db = new sqlite3.Database(filename, sqlite3.OPEN_READONLY, openError => {
      if (openError) return reject(openError);
      db.get('PRAGMA integrity_check', (integrityError, row) => {
        if (integrityError) return closeThenReject(db, integrityError, reject);
        if (!row || row.integrity_check !== 'ok') {
          return closeThenReject(db, new Error('SQLite integrity_check did not return ok'), reject);
        }
        db.all('PRAGMA foreign_key_check', (fkError, rows) => {
          if (fkError) return closeThenReject(db, fkError, reject);
          if (!Array.isArray(rows) || rows.length !== 0) {
            return closeThenReject(db, new Error('SQLite foreign_key_check reported violations'), reject);
          }
          db.close(closeError => closeError ? reject(closeError) : resolve({ integrity: 'ok', foreignKeyViolations: 0 }));
        });
      });
    });
  });
}

function closeThenReject(db, error, reject) {
  db.close(() => reject(error));
}

async function assertSafeTarget(targetPath) {
  const parent = path.dirname(targetPath);
  const parentStat = await fs.promises.lstat(parent);
  if (parentStat.isSymbolicLink() || !parentStat.isDirectory()) {
    throw new Error('Restore target parent must be an existing directory, not a symbolic link');
  }
  for (const suffix of ['', '-wal', '-shm']) {
    const candidate = `${targetPath}${suffix}`;
    try {
      const st = await fs.promises.lstat(candidate);
      if (suffix) throw new Error(`Restore blocked: SQLite sidecar ${path.basename(candidate)} exists; stop writers and resolve it before restore`);
      if (st.isSymbolicLink() || !st.isFile()) throw new Error('Restore target must be a regular file, not a symbolic link');
    } catch (error) {
      if (error.code !== 'ENOENT') throw error;
    }
  }
}

async function fsyncDirectory(directory) {
  let handle;
  try {
    handle = await fs.promises.open(directory, 'r');
    await handle.sync();
  } finally {
    if (handle) await handle.close();
  }
}

async function restoreVerifiedBackup({ backupPath, manifestPath, stagingRoot, targetPath, env = process.env, sqlite3: sqlite3Override }) {
  validateOperatorAttestation(env);
  const backup = path.resolve(backupPath);
  const manifest = path.resolve(manifestPath);
  const target = path.resolve(targetPath);
  if ([backup, manifest].includes(target)) throw new Error('Restore target must differ from backup and manifest paths');
  await assertSafeTarget(target);

  // Load the native driver only after explicit operator gates and target checks.
  // Optional adapter injection is only for deterministic tests; the CLI never supplies it.
  const sqlite3 = sqlite3Override || require('sqlite3');
  const staged = await stageVerifiedBackup(backup, manifest, stagingRoot, env.RLA_BACKUP_MANIFEST_KEY);
  let tempPath;
  let priorPath;
  let priorMoved = false;
  try {
    const stagedIntegrity = await sqliteIntegrity(sqlite3, staged.stagedPath);
    const targetDirectory = path.dirname(target);
    tempPath = path.join(targetDirectory, `.${path.basename(target)}.restore-${process.pid}-${crypto.randomBytes(8).toString('hex')}.tmp`);
    await fs.promises.copyFile(staged.stagedPath, tempPath, fs.constants.COPYFILE_EXCL);
    await fs.promises.chmod(tempPath, 0o600);
    const tempHandle = await fs.promises.open(tempPath, 'r+');
    try { await tempHandle.sync(); } finally { await tempHandle.close(); }
    const stagedHash = await hashFile(staged.stagedPath);
    if (await hashFile(tempPath) !== stagedHash) throw new Error('Restore temp file hash differs from verified staged backup');
    const tempIntegrity = await sqliteIntegrity(sqlite3, tempPath);

    // Re-check sidecars immediately before the atomic replacement.
    await assertSafeTarget(target);
    try {
      await fs.promises.lstat(target);
      priorPath = `${target}.pre-restore-${new Date().toISOString().replace(/[:.]/g, '-')}-${crypto.randomBytes(4).toString('hex')}`;
      await fs.promises.rename(target, priorPath);
      priorMoved = true;
    } catch (error) {
      if (error.code !== 'ENOENT') throw error;
    }
    try {
      await fs.promises.rename(tempPath, target);
      tempPath = null;
      await fsyncDirectory(path.dirname(target));
    } catch (error) {
      if (priorMoved) {
        await fs.promises.rename(priorPath, target).catch(() => {});
        priorMoved = false;
      }
      throw error;
    }
    return {
      ok: true,
      targetPath: target,
      previousDatabasePath: priorMoved ? priorPath : null,
      stagedPath: staged.stagedPath,
      sha256: staged.sha256,
      sizeBytes: staged.sizeBytes,
      stagedIntegrity,
      installedIntegrity: tempIntegrity,
      recoveryPoint: priorMoved ? 'previous database retained' : 'new target created'
    };
  } finally {
    if (tempPath) await fs.promises.unlink(tempPath).catch(() => {});
    // Keep the private staged artifact for post-restore evidence and controlled cleanup.
  }
}

async function main() {
  const [backupPath, manifestPath, stagingRoot, targetPath] = process.argv.slice(2);
  if (!backupPath || !manifestPath || !stagingRoot || !targetPath) {
    process.stderr.write('Usage: RLA_BACKUP_MANIFEST_KEY=<secret> RLA_RESTORE_CONFIRM=YES RLA_RESTORE_MAINTENANCE_MODE=STOPPED node scripts/restore-verified-backup.js <backup-file> <manifest-file> <private-staging-root> <target-db-file>\n');
    process.exitCode = 2;
    return;
  }
  try {
    const result = await restoreVerifiedBackup({ backupPath, manifestPath, stagingRoot, targetPath });
    process.stdout.write(`${JSON.stringify(result)}\n`);
  } catch (error) {
    process.stderr.write(`${JSON.stringify({ ok: false, error: error.message })}\n`);
    process.exitCode = 1;
  }
}

if (require.main === module) main();
module.exports = { validateOperatorAttestation, assertSafeTarget, restoreVerifiedBackup };
