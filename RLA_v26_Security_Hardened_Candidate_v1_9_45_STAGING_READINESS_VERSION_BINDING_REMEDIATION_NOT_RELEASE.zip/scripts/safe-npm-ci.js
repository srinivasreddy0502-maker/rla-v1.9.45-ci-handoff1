'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { buildSafeNpmEnvironment, resolveSafeInstallConfig } = require('../app/safe-npm-ci');

const rootDir = path.resolve(__dirname, '..');
const sourceNpmExecPath = process.env.npm_execpath;
const report = resolveSafeInstallConfig(rootDir, process.env.RLA_APPROVED_NPM_REGISTRIES);
process.stdout.write(JSON.stringify(report, null, 2) + '\n');
if (!report.installAllowed) {
  process.exitCode = 2;
} else {
  const args = report.commandArgs;
  let command;
  let commandArgs;
  if (process.platform === 'win32') {
    // Avoid npm.cmd shell invocation. Windows runners must provide a separately
    // reviewed native launcher before this wrapper can execute installation.
    process.stderr.write('SAFE_NPM_CI_EXECUTION_ERROR:TRUSTED_NATIVE_NPM_LAUNCHER_REQUIRED_ON_WINDOWS\n');
    process.exitCode = 2;
    return;
  } else {
    // Do not execute process.env.npm_execpath as a Node script: it is inherited
    // input and can point to an arbitrary npm-cli.js. Resolve the npm executable
    // through the trusted CI runner PATH with shell:false instead.
    command = 'npm';
    commandArgs = args;
  }
  let childEnv;
  try {
    childEnv = buildSafeNpmEnvironment(process.env, [report.registryPinnedToApprovedHost]);
  } catch {
    process.stderr.write('SAFE_NPM_CI_EXECUTION_ERROR:SAFE_ENVIRONMENT_BUILD_FAILED\n');
    process.exitCode = 2;
    return;
  }
  const result = spawnSync(command, commandArgs, { cwd: rootDir, env: childEnv, stdio: 'inherit', shell: false });
  if (result.error) {
    process.stderr.write(`SAFE_NPM_CI_EXECUTION_ERROR:${result.error.code || result.error.message}\n`);
    process.exitCode = 2;
  } else if (result.status !== 0) {
    process.exitCode = Number.isInteger(result.status) ? result.status : 2;
  } else {
    process.stdout.write(JSON.stringify({
      schemaVersion: 1,
      check: 'SAFE_NPM_CI_RESULT',
      status: 'DEPENDENCIES_FETCHED_WITH_SCRIPTS_SUPPRESSED',
      lifecycleScriptsExecuted: false,
      inheritedNpmConfigStripped: true,
      nodeRuntimeInjectionVariablesStripped: true,
      registryPinnedToApprovedHost: report.registryPinnedToApprovedHost,
      nativeBuildReady: false,
      productionUseAuthorized: false,
      nextStep: 'REVIEW_NATIVE_DEPENDENCY_BUILD_AND_RUN_NATIVE_SQLITE_PREFLIGHT'
    }, null, 2) + '\n');
    // Non-zero is intentional: npm ci succeeded, but native build and runtime validation remain pending.
    process.exitCode = 3;
  }
}
