#!/usr/bin/env node
'use strict';
const fs = require('node:fs/promises');
const path = require('node:path');
const { verifyEvidenceChain, verifyEvidenceFiles } = require('../app/audit-evidence-chain');
(async () => {
  const [recordsDir, evidenceRoot] = process.argv.slice(2);
  const key = process.env.RLA_AUDIT_EVIDENCE_KEY;
  if (!recordsDir || !evidenceRoot || !key) {
    console.error('Usage: RLA_AUDIT_EVIDENCE_KEY=<external-secret> node scripts/verify-audit-evidence-chain.js <records-dir> <evidence-root>');
    process.exitCode = 2; return;
  }
  const names = (await fs.readdir(recordsDir)).filter(n => /^record-[0-9]{6}\.json$/.test(n)).sort();
  if (!names.length) throw new Error('No audit evidence records found');
  const records = [];
  for (const name of names) records.push(JSON.parse(await fs.readFile(path.join(recordsDir, name), 'utf8')));
  const result = verifyEvidenceChain(records, key);
  for (const record of records) await verifyEvidenceFiles(record, evidenceRoot);
  process.stdout.write(JSON.stringify({ ...result, evidenceFilesVerified: true }, null, 2) + '\n');
})().catch(error => { console.error(`AUDIT_EVIDENCE_VERIFY_FAILED: ${error.message}`); process.exitCode = 1; });
