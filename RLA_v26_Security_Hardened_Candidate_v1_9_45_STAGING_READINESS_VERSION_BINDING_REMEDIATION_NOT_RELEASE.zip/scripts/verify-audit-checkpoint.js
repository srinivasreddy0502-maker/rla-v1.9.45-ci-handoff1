#!/usr/bin/env node
'use strict';
const { verifyAuditCheckpoint } = require('../app/audit-evidence-checkpoint');
async function main() {
  const [recordsDir, checkpointPath] = process.argv.slice(2);
  const key = process.env.RLA_AUDIT_EVIDENCE_KEY;
  if (!recordsDir || !checkpointPath || !key) throw new Error('Usage: RLA_AUDIT_EVIDENCE_KEY=<secret> node scripts/verify-audit-checkpoint.js <private-records-dir> <checkpoint-path>');
  const result = await verifyAuditCheckpoint({ recordsDir, checkpointPath, key });
  process.stdout.write(JSON.stringify({ ok: true, ...result }) + '\n');
}
main().catch(err => { process.stderr.write(`AUDIT_CHECKPOINT_VERIFY_FAILED: ${err.message}\n`); process.exitCode = 1; });
