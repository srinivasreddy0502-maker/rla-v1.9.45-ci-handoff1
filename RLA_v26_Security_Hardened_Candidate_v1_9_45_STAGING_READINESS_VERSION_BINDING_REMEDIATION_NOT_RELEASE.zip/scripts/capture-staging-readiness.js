'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { buildStagingReadinessReport } = require('../app/staging-readiness-report');
const { checkDependencyLockfile, parseApprovedHosts } = require('../app/dependency-lockfile-preflight');

const outputPath = path.resolve(process.argv[2] || path.join(__dirname, '..', 'docs', 'staging-readiness-evidence-v1.9.8.json'));
const preflightPath = path.join(__dirname, 'native-sqlite-preflight.js');
const run = spawnSync(process.execPath, [preflightPath], { encoding: 'utf8', timeout: 30000, windowsHide: true, maxBuffer: 1024 * 1024 });
const exitCode = Number.isInteger(run.status) ? run.status : 124;
const stdout = typeof run.stdout === 'string' ? run.stdout : '';
const stderr = [run.error ? `${run.error.code || 'SPAWN_ERROR'}: ${run.error.message}` : '', typeof run.stderr === 'string' ? run.stderr : ''].filter(Boolean).join('\n');
const report = buildStagingReadinessReport({ exitCode, stdout, stderr, generatedAt: new Date().toISOString() });
try {
  const approvedHosts = parseApprovedHosts(process.env.RLA_APPROVED_NPM_REGISTRIES);
  report.dependencyLockfilePreflight = checkDependencyLockfile({ rootDir: path.resolve(__dirname, '..'), approvedHosts });
} catch (error) {
  report.dependencyLockfilePreflight = { schemaVersion: 1, check: 'DEPENDENCY_LOCKFILE_PREFLIGHT', status: 'BLOCKED', blockers: ['APPROVED_REGISTRY_CONFIGURATION_INVALID'], installAllowed: false, productionUseAuthorized: false };
}
fs.mkdirSync(path.dirname(outputPath), { recursive: true, mode: 0o700 });
const fd = fs.openSync(outputPath, 'wx', 0o600);
try { fs.writeFileSync(fd, JSON.stringify(report, null, 2) + '\n', 'utf8'); fs.fsyncSync(fd); }
finally { fs.closeSync(fd); }
process.stdout.write(JSON.stringify({ reportPath: outputPath, preflightStatus: report.preflightStatus, releaseStatus: report.releaseStatus, blockedFollowUps: report.requiredFollowUp.length }) + '\n');
if (report.preflightStatus !== 'DRIVER_SMOKE_PASS' || report.dependencyLockfilePreflight.status !== 'PASS') process.exitCode = 2;
