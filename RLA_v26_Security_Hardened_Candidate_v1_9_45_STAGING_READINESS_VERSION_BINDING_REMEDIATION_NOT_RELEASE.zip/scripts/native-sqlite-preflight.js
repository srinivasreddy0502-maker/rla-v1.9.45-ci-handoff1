'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { loadNativeSqlite3 } = require('../app/native-sqlite-restore-drill');

function openMemory(sqlite3) {
  return new Promise((resolve, reject) => {
    const db = new sqlite3.Database(':memory:', sqlite3.OPEN_READWRITE | sqlite3.OPEN_CREATE, err => err ? reject(err) : resolve(db));
  });
}
function get(db, sql) {
  return new Promise((resolve, reject) => db.get(sql, (err, row) => err ? reject(err) : resolve(row)));
}
function close(db) {
  return new Promise((resolve, reject) => db.close(err => err ? reject(err) : resolve()));
}
function assertIntegrityCheckRow(row) {
  if (!row || row.integrity_check !== 'ok') {
    throw new Error('PRAGMA integrity_check did not return ok');
  }
  return row.integrity_check;
}
async function main() {
  const sqlite3 = loadNativeSqlite3();
  if (!sqlite3 || typeof sqlite3.Database !== 'function') throw new Error('sqlite3 module interface invalid');
  const modulePath = require.resolve('sqlite3');
  let packageVersion = 'UNKNOWN';
  try { packageVersion = JSON.parse(fs.readFileSync(path.join(path.dirname(modulePath), 'package.json'), 'utf8')).version; }
  catch (_) {
    try { packageVersion = require('sqlite3/package.json').version; } catch (_) { /* Keep UNKNOWN; do not infer. */ }
  }
  if (typeof sqlite3.Database.prototype.backup !== 'function') throw new Error('Database#backup API is unavailable');
  const db = await openMemory(sqlite3);
  let sqliteVersion;
  try {
    const row = await get(db, 'SELECT sqlite_version() AS version');
    if (!row || typeof row.version !== 'string' || !row.version) throw new Error('SQLite version query returned no version');
    sqliteVersion = row.version;
    assertIntegrityCheckRow(await get(db, 'PRAGMA integrity_check'));
  } finally { await close(db); }
  process.stdout.write(JSON.stringify({
    status: 'DRIVER_SMOKE_PASS',
    nativeDriver: true,
    npmPackage: 'sqlite3',
    packageVersion,
    modulePath,
    nodeVersion: process.version,
    nodeModuleAbi: process.versions.modules,
    platform: process.platform,
    architecture: process.arch,
    sqliteLibraryVersion: sqliteVersion,
    databaseBackupApi: true,
    checks: ['module-load', 'in-memory-open-close', 'sqlite-version-query', 'integrity-check-ok', 'backup-api-presence'],
    limitation: 'This is a driver smoke test only; it does not prove a file backup/restore drill or release readiness.'
  }) + '\n');
}
if (require.main === module) {
main().catch(err => {
  process.stderr.write(JSON.stringify({
    status: 'BLOCKED',
    code: err.code || 'SQLITE_PREFLIGHT_FAILED',
    message: err.message,
    nodeVersion: process.version,
    nodeModuleAbi: process.versions.modules,
    platform: process.platform,
    architecture: process.arch,
    nativeDriver: false,
    limitation: 'No real native SQLite backup/restore drill was completed.'
  }) + '\n');
  process.exitCode = 2;
});
}

module.exports = { assertIntegrityCheckRow };
