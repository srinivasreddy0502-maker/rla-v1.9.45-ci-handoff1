#!/usr/bin/env node
'use strict';
const { inspectSchedulerLock } = require('../app/scheduler-lock');
async function main() {
  const [lockPath] = process.argv.slice(2);
  if (!lockPath) {
    process.stderr.write('Usage: node scripts/inspect-scheduler-lock.js <private-lock-path>\n');
    process.exitCode = 2;
    return;
  }
  try {
    const result = await inspectSchedulerLock(lockPath);
    process.stdout.write(`${JSON.stringify(result)}\n`);
  } catch (error) {
    process.stderr.write(`${JSON.stringify({ ok: false, error: error.message, automaticCleanup: false })}\n`);
    process.exitCode = 1;
  }
}
if (require.main === module) main();
module.exports = { main };
