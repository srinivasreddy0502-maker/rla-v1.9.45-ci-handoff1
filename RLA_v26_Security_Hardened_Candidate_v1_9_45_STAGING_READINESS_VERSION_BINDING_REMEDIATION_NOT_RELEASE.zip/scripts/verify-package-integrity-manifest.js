'use strict';
const path = require('node:path');
const { verifyPackageIntegrityManifest } = require('../app/package-integrity-manifest');
const rootDir = path.resolve(__dirname, '..');
const manifestPath = path.resolve(process.argv[2] || path.join(rootDir, 'docs', 'package-integrity-manifest-v1.9.8.json'));
const report = verifyPackageIntegrityManifest({ rootDir, manifestPath });
process.stdout.write(JSON.stringify(report, null, 2) + '\n');
if (report.status !== 'PASS') process.exitCode = 2;
