#!/usr/bin/env node
'use strict';
const fs = require('node:fs/promises');
const path = require('node:path');
const { createSchedulerRecoveryAuthorization, verifySchedulerRecoveryAuthorization } = require('../app/scheduler-lock-recovery');

async function main() {
  const [lockPath, outputPath] = process.argv.slice(2);
  const key = process.env.RLA_SCHEDULER_RECOVERY_AUDIT_KEY;
  let attestations;
  try { attestations = JSON.parse(process.env.RLA_RECOVERY_ATTESTATIONS || '{}'); }
  catch { attestations = {}; }
  const required = ['RLA_RECOVERY_OPERATOR_ID', 'RLA_RECOVERY_APPROVER_ID', 'RLA_RECOVERY_INCIDENT_REF', 'RLA_RECOVERY_REASON'];
  if (!lockPath || !outputPath || !key || required.some(name => !process.env[name])) {
    process.stderr.write('Usage: set recovery audit key, operator/approver IDs, incident ref, reason, and JSON attestations; node scripts/authorize-scheduler-lock-recovery.js <lock-path> <new-output.json>\n');
    process.exitCode = 2; return;
  }
  try {
    const record = await createSchedulerRecoveryAuthorization({
      lockPath, key,
      operatorId: process.env.RLA_RECOVERY_OPERATOR_ID,
      approverId: process.env.RLA_RECOVERY_APPROVER_ID,
      incidentRef: process.env.RLA_RECOVERY_INCIDENT_REF,
      reason: process.env.RLA_RECOVERY_REASON,
      attestations
    });
    verifySchedulerRecoveryAuthorization(record, key);
    const absoluteOutput = path.resolve(outputPath);
    const parentStat = await fs.lstat(path.dirname(absoluteOutput));
    if (parentStat.isSymbolicLink() || !parentStat.isDirectory()) throw new Error('Output parent must be a real directory');
    if (process.platform !== 'win32' && (parentStat.mode & 0o077) !== 0) throw new Error('Output parent must be private (mode 0700)');
    const handle = await fs.open(absoluteOutput, 'wx', 0o600);
    try { await handle.writeFile(`${JSON.stringify(record, null, 2)}\n`, 'utf8'); await handle.sync(); }
    finally { await handle.close(); }
    process.stdout.write(`${JSON.stringify({ ok: true, outputPath: absoluteOutput, automaticCleanup: false, lockRemoved: false })}\n`);
  } catch (error) {
    process.stderr.write(`${JSON.stringify({ ok: false, error: error.message, lockRemoved: false, secretLogged: false })}\n`);
    process.exitCode = 1;
  }
}
if (require.main === module) main();
module.exports = { main };
