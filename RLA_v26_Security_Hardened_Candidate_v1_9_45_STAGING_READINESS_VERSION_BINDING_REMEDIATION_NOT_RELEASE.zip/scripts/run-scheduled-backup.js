#!/usr/bin/env node
'use strict';

const path = require('node:path');
const { acquireSchedulerLock, releaseSchedulerLock } = require('../app/scheduler-lock');
const { createConsistentBackup } = require('./create-consistent-backup');

async function runScheduledBackup({ sourcePath, backupPath, manifestPath, lockPath, key, sqlite3 }) {
  if (typeof key !== 'string' || Buffer.byteLength(key, 'utf8') < 32) {
    throw new Error('RLA_BACKUP_MANIFEST_KEY must contain at least 32 UTF-8 bytes');
  }
  const lock = await acquireSchedulerLock(lockPath);
  let result;
  let operationError;
  try {
    result = await createConsistentBackup({ sourcePath, backupPath, manifestPath, key, ...(sqlite3 ? { sqlite3 } : {}) });
  } catch (error) {
    operationError = error;
  }
  try {
    await releaseSchedulerLock(lock);
  } catch (releaseError) {
    if (operationError) throw new Error(`${operationError.message}; additionally failed to release scheduler lock: ${releaseError.message}`);
    throw releaseError;
  }
  if (operationError) throw operationError;
  return { ...result, schedulerLock: 'acquired-and-released', lockPath: path.resolve(lockPath) };
}

async function main() {
  const [sourcePath, backupPath, manifestPath, lockPath] = process.argv.slice(2);
  const key = process.env.RLA_BACKUP_MANIFEST_KEY;
  if (!sourcePath || !backupPath || !manifestPath || !lockPath || !key) {
    process.stderr.write('Usage: RLA_BACKUP_MANIFEST_KEY=<secret-from-secret-manager> node scripts/run-scheduled-backup.js <source-db> <new-backup-file> <new-manifest-file> <private-lock-path>\n');
    process.exitCode = 2;
    return;
  }
  try {
    const result = await runScheduledBackup({ sourcePath, backupPath, manifestPath, lockPath, key });
    process.stdout.write(`${JSON.stringify(result)}\n`);
  } catch (error) {
    process.stderr.write(`${JSON.stringify({ ok: false, error: error.message, secretLogged: false })}\n`);
    process.exitCode = 1;
  }
}

if (require.main === module) main();
module.exports = { runScheduledBackup };
