'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { validateLockfilePromotionEvidence } = require('../app/lockfile-promotion-evidence');
const { readEvidenceFileNoFollow } = require('../app/staging-evidence-intake');

const evidencePath = process.argv[2];
if (!evidencePath) {
  process.stdout.write(JSON.stringify({ status: 'BLOCKED', blockers: ['EVIDENCE_PATH_REQUIRED'], productionUseAuthorized: false, releaseStatus: 'RELEASE_BLOCKED' }, null, 2) + '\n');
  process.exitCode = 2;
} else {
  try {
    const evidence = JSON.parse(readEvidenceFileNoFollow(path.resolve(evidencePath)));
    const result = validateLockfilePromotionEvidence({ rootDir: path.resolve(process.argv[3] || path.resolve(__dirname, '..')), evidence, env: process.env });
    process.stdout.write(JSON.stringify(result, null, 2) + '\n');
    if (result.status === 'BLOCKED') process.exitCode = 2;
  } catch (error) {
    process.stdout.write(JSON.stringify({ status: 'BLOCKED', blockers: [`EVIDENCE_READ_FAILED:${error.code || 'INVALID_JSON'}`], productionUseAuthorized: false, releaseStatus: 'RELEASE_BLOCKED' }, null, 2) + '\n');
    process.exitCode = 2;
  }
}
