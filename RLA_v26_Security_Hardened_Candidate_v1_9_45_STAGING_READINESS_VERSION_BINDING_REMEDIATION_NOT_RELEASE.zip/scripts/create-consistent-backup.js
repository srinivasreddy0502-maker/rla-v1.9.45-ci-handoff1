#!/usr/bin/env node
'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const { createManifest, verifyManifest } = require('../app/backup-manifest');

function requireBackupKey(key) {
  if (typeof key !== 'string' || Buffer.byteLength(key, 'utf8') < 32) {
    throw new Error('RLA_BACKUP_MANIFEST_KEY must contain at least 32 UTF-8 bytes');
  }
}

async function assertRegularFile(filePath, label) {
  const stat = await fs.promises.lstat(filePath);
  if (stat.isSymbolicLink() || !stat.isFile()) {
    throw new Error(`${label} must be a regular file, not a symbolic link`);
  }
  return stat;
}

async function assertAbsent(filePath, label) {
  try {
    await fs.promises.lstat(filePath);
    throw new Error(`${label} already exists; refusing to overwrite it`);
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
  }
}

async function fsyncDirectory(directory) {
  let handle;
  try {
    handle = await fs.promises.open(directory, 'r');
    await handle.sync();
  } finally {
    if (handle) await handle.close();
  }
}

function backupDatabase(db, destination) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const done = error => {
      if (settled) return;
      settled = true;
      error ? reject(error) : resolve();
    };
    try {
      // node-sqlite3 uses SQLite's online backup API. This is preferable to
      // copying the live database file, especially when WAL mode is enabled.
      db.backup(destination, done);
    } catch (error) {
      done(error);
    }
  });
}

function closeDatabase(db) {
  return new Promise((resolve, reject) => {
    if (!db) return resolve();
    db.close(error => error ? reject(error) : resolve());
  });
}

async function createConsistentBackup({ sourcePath, backupPath, manifestPath, key, sqlite3 = require('sqlite3') }) {
  requireBackupKey(key);
  const source = path.resolve(sourcePath);
  const backup = path.resolve(backupPath);
  const manifest = path.resolve(manifestPath);
  if (new Set([source, backup, manifest]).size !== 3) {
    throw new Error('Source database, backup artifact, and manifest must use distinct paths');
  }
  const sourceStat = await assertRegularFile(source, 'Source database');
  if (sourceStat.size < 1) throw new Error('Source database must not be empty');
  await assertAbsent(backup, 'Backup destination');
  await assertAbsent(manifest, 'Manifest destination');

  const backupDirectory = path.dirname(backup);
  const manifestDirectory = path.dirname(manifest);
  const backupParent = await fs.promises.lstat(backupDirectory);
  const manifestParent = await fs.promises.lstat(manifestDirectory);
  if (backupParent.isSymbolicLink() || !backupParent.isDirectory() ||
      manifestParent.isSymbolicLink() || !manifestParent.isDirectory()) {
    throw new Error('Backup and manifest parent paths must be existing directories, not symbolic links');
  }
  if (process.platform !== 'win32' && ((backupParent.mode & 0o077) !== 0 || (manifestParent.mode & 0o077) !== 0)) {
    throw new Error('Backup and manifest directories must not grant group or other permissions');
  }

  const tempPath = path.join(backupDirectory, `.${path.basename(backup)}.${process.pid}.${crypto.randomBytes(10).toString('hex')}.tmp`);
  let db;
  let publishedBackup = false;
  try {
    db = await new Promise((resolve, reject) => {
      const connection = new sqlite3.Database(source, sqlite3.OPEN_READONLY, error => {
        if (error) {
          connection.close(() => reject(error));
        } else {
          resolve(connection);
        }
      });
    });
    await backupDatabase(db, tempPath);
    await closeDatabase(db);
    db = null;

    const tempStat = await assertRegularFile(tempPath, 'Temporary backup');
    if (tempStat.size < 1) throw new Error('SQLite online backup produced an empty artifact');
    await fs.promises.chmod(tempPath, 0o600);
    let handle = await fs.promises.open(tempPath, 'r+');
    try { await handle.sync(); } finally { await handle.close(); }
    await fs.promises.rename(tempPath, backup);
    publishedBackup = true;
    await fsyncDirectory(backupDirectory);

    const manifestResult = await createManifest(backup, manifest, key);
    const verified = await verifyManifest(backup, manifest, key);
    await fsyncDirectory(manifestDirectory);
    return {
      ok: true,
      backupPath: backup,
      manifestPath: manifest,
      sizeBytes: verified.sizeBytes,
      sha256: verified.sha256,
      manifestCreatedAt: manifestResult.createdAt,
      method: 'sqlite3-online-backup-api',
      manifestVerified: true
    };
  } catch (error) {
    if (db) await closeDatabase(db).catch(() => {});
    await fs.promises.unlink(tempPath).catch(() => {});
    // Do not leave an apparently complete but unauthenticated backup if manifest
    // creation/verification fails. Preserve evidence only through approved logs.
    if (publishedBackup) await fs.promises.unlink(backup).catch(() => {});
    await fs.promises.unlink(manifest).catch(() => {});
    throw error;
  }
}

async function main() {
  const [sourcePath, backupPath, manifestPath] = process.argv.slice(2);
  const key = process.env.RLA_BACKUP_MANIFEST_KEY;
  if (!sourcePath || !backupPath || !manifestPath || !key) {
    process.stderr.write('Usage: RLA_BACKUP_MANIFEST_KEY=<secret-from-secret-manager> node scripts/create-consistent-backup.js <source-db> <new-backup-file> <new-manifest-file>\n');
    process.exitCode = 2;
    return;
  }
  try {
    const result = await createConsistentBackup({ sourcePath, backupPath, manifestPath, key });
    process.stdout.write(`${JSON.stringify(result)}\n`);
  } catch (error) {
    process.stderr.write(`${JSON.stringify({ ok: false, error: error.message })}\n`);
    process.exitCode = 1;
  }
}

if (require.main === module) main();
module.exports = { createConsistentBackup };
