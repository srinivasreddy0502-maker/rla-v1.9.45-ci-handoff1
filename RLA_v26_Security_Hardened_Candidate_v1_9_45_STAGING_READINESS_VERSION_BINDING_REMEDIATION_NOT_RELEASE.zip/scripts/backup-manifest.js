#!/usr/bin/env node
'use strict';
const { createManifest, verifyManifest, stageVerifiedBackup } = require('../app/backup-manifest');

async function main() {
  const [command, backupPath, manifestPath, stagingRoot] = process.argv.slice(2);
  const key = process.env.RLA_BACKUP_MANIFEST_KEY;
  if (!['create', 'verify', 'stage'].includes(command) || !backupPath || !manifestPath || !key || (command === 'stage' && !stagingRoot)) {
    process.stderr.write('Usage: RLA_BACKUP_MANIFEST_KEY=<secret-at-least-32-bytes> node scripts/backup-manifest.js <create|verify> <backup-file> <manifest-file>\n       RLA_BACKUP_MANIFEST_KEY=<secret-at-least-32-bytes> node scripts/backup-manifest.js stage <backup-file> <manifest-file> <private-staging-root>\n');
    process.exitCode = 2;
    return;
  }
  try {
    const result = command === 'create'
      ? await createManifest(backupPath, manifestPath, key)
      : command === 'verify'
        ? await verifyManifest(backupPath, manifestPath, key)
        : await stageVerifiedBackup(backupPath, manifestPath, stagingRoot, key);
    process.stdout.write(`${JSON.stringify({ command, ok: true, artifact: result.artifact, sizeBytes: result.sizeBytes, sha256: result.sha256, ...(result.stagedPath ? { stagedPath: result.stagedPath } : {}) })}\n`);
  } catch (error) {
    process.stderr.write(`${JSON.stringify({ command, ok: false, error: error.message })}\n`);
    process.exitCode = 1;
  }
}
main();
