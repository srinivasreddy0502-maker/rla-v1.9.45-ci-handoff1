'use strict';
const path = require('node:path');
const { resolveLockfileAcquisitionPlan } = require('../app/dependency-lockfile-acquisition-plan');
const rootDir = path.resolve(__dirname, '..');
const report = resolveLockfileAcquisitionPlan(rootDir, process.env);
process.stdout.write(JSON.stringify(report, null, 2) + '\n');
if (report.status === 'BLOCKED') process.exitCode = 2;
