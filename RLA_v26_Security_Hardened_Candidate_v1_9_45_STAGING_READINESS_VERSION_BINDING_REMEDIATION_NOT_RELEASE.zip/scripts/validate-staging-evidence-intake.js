'use strict';
const { readEvidenceFileNoFollow, validateStagingEvidenceIntake } = require('../app/staging-evidence-intake');

const inputPath = process.argv[2];
if (!inputPath) {
  process.stderr.write('Usage: node scripts/validate-staging-evidence-intake.js <evidence.json>\n');
  process.exitCode = 64;
} else {
  try {
    const raw = readEvidenceFileNoFollow(inputPath);
    let parsed;
    try { parsed = JSON.parse(raw); }
    catch { throw Object.assign(new Error('evidence file is not valid JSON'), { code: 'EVIDENCE_JSON_INVALID' }); }
    const report = validateStagingEvidenceIntake(parsed);
    process.stdout.write(JSON.stringify(report, null, 2) + '\n');
    if (report.intakeStatus !== 'EVIDENCE_COMPLETE_PENDING_INDEPENDENT_VERIFICATION') process.exitCode = 2;
  } catch (error) {
    process.stderr.write(JSON.stringify({ status: 'BLOCKED', code: error.code || 'EVIDENCE_INTAKE_FAILED', message: String(error.message || 'evidence intake failed').slice(0, 300), releaseStatus: 'RELEASE_BLOCKED', productionUseAuthorized: false }) + '\n');
    process.exitCode = 2;
  }
}
