#!/usr/bin/env node
'use strict';
const { createAuditCheckpoint } = require('../app/audit-evidence-checkpoint');
async function main() {
  const [recordsDir, checkpointPath] = process.argv.slice(2);
  const key = process.env.RLA_AUDIT_EVIDENCE_KEY;
  if (!recordsDir || !checkpointPath || !key) throw new Error('Usage: RLA_AUDIT_EVIDENCE_KEY=<secret> node scripts/create-audit-checkpoint.js <private-records-dir> <new-checkpoint-path>');
  const result = await createAuditCheckpoint({ recordsDir, checkpointPath, key });
  process.stdout.write(JSON.stringify({ ok: true, ...result }) + '\n');
}
main().catch(err => { process.stderr.write(`AUDIT_CHECKPOINT_CREATE_FAILED: ${err.message}\n`); process.exitCode = 1; });
