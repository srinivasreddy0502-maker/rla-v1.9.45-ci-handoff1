#!/usr/bin/env node
'use strict';
const { appendEvidenceRecord } = require('../app/audit-evidence-chain');
async function main() {
  const [recordsDir, evidenceRoot, evidenceNamesArg, actorId, eventType, changeRef] = process.argv.slice(2);
  const key = process.env.RLA_AUDIT_EVIDENCE_KEY;
  if (!recordsDir || !evidenceRoot || !evidenceNamesArg || !actorId || !eventType || !changeRef || !key) {
    throw new Error('Usage: RLA_AUDIT_EVIDENCE_KEY=<secret-from-approved-secret-manager> node scripts/append-audit-evidence.js <private-records-dir> <private-evidence-root> <comma-separated-evidence-names> <actor-id> <event-type> <change-ref>');
  }
  const result = await appendEvidenceRecord({ recordsDir, evidenceRoot, evidenceNames: evidenceNamesArg.split(','), key, actorId, eventType, changeRef });
  process.stdout.write(JSON.stringify({ ok: true, ...result }) + '\n');
}
main().catch(err => { process.stderr.write(`AUDIT_EVIDENCE_APPEND_FAILED: ${err.message}\n`); process.exitCode = 1; });
