#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const path = require('node:path');

function requireKey(key) {
  if (typeof key !== 'string' || Buffer.byteLength(key, 'utf8') < 32) {
    throw new Error('Backup preflight failed: RLA_BACKUP_MANIFEST_KEY must contain at least 32 UTF-8 bytes');
  }
}

async function requireRegularFile(filePath, label) {
  const stat = await fs.promises.lstat(filePath);
  if (stat.isSymbolicLink() || !stat.isFile()) throw new Error(`${label} must be a regular file, not a symbolic link`);
  if (stat.size < 1) throw new Error(`${label} must not be empty`);
  return stat;
}

async function requirePrivateDirectory(dirPath, label) {
  const stat = await fs.promises.lstat(dirPath);
  if (stat.isSymbolicLink() || !stat.isDirectory()) throw new Error(`${label} must be an existing directory, not a symbolic link`);
  if (process.platform !== 'win32' && (stat.mode & 0o077) !== 0) {
    throw new Error(`${label} must not grant group or other permissions (use mode 0700)`);
  }
  return stat;
}

async function requireAbsent(filePath, label) {
  try {
    await fs.promises.lstat(filePath);
    throw new Error(`${label} already exists; preflight refuses to overwrite it`);
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
  }
}

function validateNativeDriver(sqlite3) {
  if (!sqlite3 || typeof sqlite3.Database !== 'function' || typeof sqlite3.OPEN_READONLY !== 'number' ||
      !sqlite3.Database.prototype || typeof sqlite3.Database.prototype.backup !== 'function') {
    throw new Error('Backup preflight failed: native sqlite3 driver with Database.backup support is unavailable');
  }
}

async function backupPreflight({ sourcePath, backupPath, manifestPath, key, sqlite3 = require('sqlite3') }) {
  requireKey(key);
  validateNativeDriver(sqlite3);
  const source = path.resolve(sourcePath);
  const backup = path.resolve(backupPath);
  const manifest = path.resolve(manifestPath);
  if (new Set([source, backup, manifest]).size !== 3) throw new Error('Source, backup, and manifest paths must be distinct');
  await requireRegularFile(source, 'Source database');
  await requirePrivateDirectory(path.dirname(backup), 'Backup directory');
  await requirePrivateDirectory(path.dirname(manifest), 'Manifest directory');
  await requireAbsent(backup, 'Backup destination');
  await requireAbsent(manifest, 'Manifest destination');
  return {
    ok: true,
    sourcePath: source,
    backupPath: backup,
    manifestPath: manifest,
    driver: 'sqlite3-online-backup-api-available',
    secretPresent: true,
    secretValueLogged: false,
    overwrite: false
  };
}

async function main() {
  const [sourcePath, backupPath, manifestPath] = process.argv.slice(2);
  const key = process.env.RLA_BACKUP_MANIFEST_KEY;
  if (!sourcePath || !backupPath || !manifestPath || !key) {
    process.stderr.write('Usage: RLA_BACKUP_MANIFEST_KEY=<secret-from-secret-manager> node scripts/backup-preflight.js <source-db> <new-backup-file> <new-manifest-file>\n');
    process.exitCode = 2;
    return;
  }
  try {
    const result = await backupPreflight({ sourcePath, backupPath, manifestPath, key });
    process.stdout.write(`${JSON.stringify(result)}\n`);
  } catch (error) {
    process.stderr.write(`${JSON.stringify({ ok: false, error: error.message })}\n`);
    process.exitCode = 1;
  }
}

if (require.main === module) main();
module.exports = { backupPreflight, requireKey, requirePrivateDirectory, validateNativeDriver };
