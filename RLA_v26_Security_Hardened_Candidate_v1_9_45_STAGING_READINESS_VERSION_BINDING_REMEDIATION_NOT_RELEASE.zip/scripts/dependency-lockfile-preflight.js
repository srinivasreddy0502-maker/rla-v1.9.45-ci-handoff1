'use strict';
const path = require('node:path');
const { checkDependencyLockfile, parseApprovedHosts } = require('../app/dependency-lockfile-preflight');

let approvedHosts;
try { approvedHosts = parseApprovedHosts(process.env.RLA_APPROVED_NPM_REGISTRIES); }
catch (error) {
  process.stdout.write(JSON.stringify({ schemaVersion: 1, check: 'DEPENDENCY_LOCKFILE_PREFLIGHT', status: 'BLOCKED', blockers: ['APPROVED_REGISTRY_CONFIGURATION_INVALID'], installAllowed: false, productionUseAuthorized: false }) + '\n');
  process.exitCode = 2;
  return;
}
const report = checkDependencyLockfile({ rootDir: path.resolve(__dirname, '..'), approvedHosts });
process.stdout.write(JSON.stringify(report, null, 2) + '\n');
if (report.status !== 'PASS') process.exitCode = 2;
