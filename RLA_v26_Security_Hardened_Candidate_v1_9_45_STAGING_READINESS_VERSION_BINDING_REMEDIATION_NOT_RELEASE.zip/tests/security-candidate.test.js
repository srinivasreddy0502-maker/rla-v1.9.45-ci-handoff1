const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const source = fs.readFileSync(path.join(__dirname, '../app/server.js'), 'utf8');

test('no hardcoded demo administrator token remains', () => {
  assert.equal(source.includes('demo-admin-token'), false);
  assert.match(source, /RLA_BOOTSTRAP_ADMIN_TOKEN/);
});
test('production fails closed without explicit authorization policy', () => {
  assert.match(source, /RLA_AUTHZ_POLICY_JSON is required in production/);
  assert.match(source, /AUTHORIZATION_POLICY_NOT_CONFIGURED/);
});
test('route permissions default deny and are explicit', () => {
  assert.match(source, /function allowed\(policy, user, permission\)/);
  assert.match(source, /applications:read/);
  assert.match(source, /applications:create/);
  assert.match(source, /applications:transition/);
  assert.match(source, /audit:read/);
});
test('record mutations and audit writes use a transaction', () => {
  assert.match(source, /async function inTransaction/);
  assert.match(source, /await writeAudit/);
  assert.match(source, /BEGIN IMMEDIATE/);
  assert.match(source, /ROLLBACK/);
});
test('application queries are scoped by jurisdiction', () => {
  assert.match(source, /WHERE jurisdiction=\?/);
  assert.match(source, /function scoped\(user, row\)/);
});
test('request body has a size limit and schema checks', () => {
  assert.match(source, /MAX_BODY_BYTES = 64 \* 1024/);
  assert.match(source, /BODY_TOO_LARGE/);
  assert.match(source, /INVALID_JSON/);
});
test('audit writes and reads are jurisdiction-scoped', () => {
  assert.match(source, /jurisdiction TEXT/);
  assert.match(source, /idx_audit_scope_created ON audit\(jurisdiction, created_at\)/);
  assert.match(source, /INSERT INTO audit\(id,actor,action,object_id,from_state,to_state,created_at,jurisdiction\)/);
  assert.match(source, /FROM audit WHERE jurisdiction=\?/);
});
test('optimistic concurrency is enforced in the update predicate', () => {
  assert.match(source, /WHERE id=\? AND version=\?/);
});

test('production bootstrap secret is required only for a new bootstrap account', () => {
  assert.match(source, /const existing = await dbGet\("SELECT id FROM users WHERE id='U_BOOTSTRAP_ADMIN'"\)/);
  assert.match(source, /if \(!existing\) \{/);
  assert.match(source, /RLA_BOOTSTRAP_ADMIN_TOKEN is required for initial secure bootstrap/);
});
test('oversized request is drained safely instead of destroying the socket', () => {
  assert.match(source, /let tooLarge = false/);
  assert.match(source, /Continue draining without retaining an oversized body/);
  assert.doesNotMatch(source, /req\.destroy\(\)/);
});
test('authorization policy is validated before database bootstrap writes', () => {
  assert.ok(source.indexOf('Validate policy before mutating the database') < source.indexOf('await dbExec(`'));
  assert.match(source, /must map roles to non-empty arrays of explicit permissions/);
});

test('empty development policy is not reported as configured or accepted by routes', () => {
  assert.match(source, /let policyConfigured = false/);
  assert.match(source, /readiness: policyConfigured \? 'configured' : 'authorization-policy-missing'/);
  assert.match(source, /if \(!policyConfigured\) return fail\(res, 503, 'AUTHORIZATION_POLICY_NOT_CONFIGURED'\)/);
  assert.match(source, /policyConfigured = Boolean\(process\.env\.RLA_AUTHZ_POLICY_JSON\)/);
});


test('empty authorization policy is rejected rather than treated as configured', () => {
  assert.match(source, /entries\.length === 0/);
  assert.match(source, /must define at least one role/);
});
test('wildcard authorization permission is prohibited', () => {
  assert.match(source, /p\.trim\(\) === '\*'/);
  assert.match(source, /wildcard permission is prohibited/);
});
