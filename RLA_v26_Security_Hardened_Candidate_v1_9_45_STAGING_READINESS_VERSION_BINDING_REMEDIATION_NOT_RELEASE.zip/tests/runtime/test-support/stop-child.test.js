'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const stopChildProcess = require('./stop-child');

function startChild(source) {
  return spawn(process.execPath, ['-e', source], { stdio: ['ignore', 'pipe', 'pipe'] });
}
function waitReady(child) {
  return new Promise((resolve, reject) => {
    let output = '';
    const onData = chunk => {
      output += chunk.toString();
      if (output.includes('READY')) { cleanup(); resolve(); }
    };
    const onExit = code => { cleanup(); reject(new Error(`child exited before READY: ${code}; ${output}`)); };
    const onError = err => { cleanup(); reject(err); };
    const cleanup = () => {
      child.stdout.removeListener('data', onData);
      child.removeListener('exit', onExit);
      child.removeListener('error', onError);
    };
    child.stdout.on('data', onData);
    child.once('exit', onExit);
    child.once('error', onError);
  });
}

test('stop helper reports no child without throwing', async () => {
  assert.deepEqual(await stopChildProcess(null), { status: 'NO_CHILD' });
});

test('stop helper waits for graceful SIGTERM exit', async () => {
  const child = startChild("process.on('SIGTERM',()=>process.exit(0)); process.stdout.write('READY\\n'); setInterval(()=>{},1000);");
  await waitReady(child);
  const result = await stopChildProcess(child, { gracefulTimeoutMs: 500, forceTimeoutMs: 500 });
  assert.equal(result.status, 'EXITED_AFTER_SIGTERM');
  assert.equal(child.exitCode, 0);
});

test('stop helper force-kills a child that ignores SIGTERM and confirms exit', async () => {
  const child = startChild("process.on('SIGTERM',()=>{}); process.stdout.write('READY\\n'); setInterval(()=>{},1000);");
  await waitReady(child);
  const result = await stopChildProcess(child, { gracefulTimeoutMs: 100, forceTimeoutMs: 1000 });
  assert.equal(result.status, 'EXITED_AFTER_SIGKILL');
  assert.equal(child.signalCode, 'SIGKILL');
});

test('stop helper recognizes an already-exited process', async () => {
  const child = spawn(process.execPath, ['-e', 'process.exit(0)'], { stdio: 'ignore' });
  await new Promise((resolve, reject) => {
    child.once('exit', resolve);
    child.once('error', reject);
  });
  const result = await stopChildProcess(child);
  assert.equal(result.status, 'ALREADY_EXITED');
});

test('stop helper rejects invalid timeout configuration', async () => {
  const child = startChild("process.stdout.write('READY\\n'); setInterval(()=>{},1000);");
  await waitReady(child);
  await assert.rejects(stopChildProcess(child, { gracefulTimeoutMs: -1 }), /CHILD_SHUTDOWN_TIMEOUT_INVALID/);
  await stopChildProcess(child, { gracefulTimeoutMs: 500, forceTimeoutMs: 500 });
});
