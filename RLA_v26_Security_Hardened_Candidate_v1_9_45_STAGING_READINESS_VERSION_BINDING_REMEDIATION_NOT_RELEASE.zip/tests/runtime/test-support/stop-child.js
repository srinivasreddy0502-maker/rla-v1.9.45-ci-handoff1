'use strict';

// Deterministic test-process teardown. Request graceful shutdown, wait for the OS
// child process to exit, force-kill only after the grace period, then verify exit.
function hasExited(child) {
  return child.exitCode !== null || child.signalCode !== null;
}

function sendSignal(child, signal) {
  try {
    return child.kill(signal);
  } catch (error) {
    // ESRCH means the child raced to exit between the state check and kill().
    if (error && error.code === 'ESRCH') return false;
    throw error;
  }
}

function waitForExit(child, timeoutMs) {
  return new Promise(resolve => {
    let settled = false;
    let timer;
    const finish = exited => {
      if (settled) return;
      settled = true;
      if (timer) clearTimeout(timer);
      child.removeListener('exit', onExit);
      child.removeListener('error', onError);
      resolve(exited);
    };
    const onExit = () => finish(true);
    const onError = () => finish(hasExited(child) || child.pid == null);
    child.once('exit', onExit);
    child.once('error', onError);
    timer = setTimeout(() => finish(hasExited(child)), timeoutMs);
    // Recheck after listeners are installed to avoid missing a just-completed exit.
    if (hasExited(child)) finish(true);
  });
}

module.exports = async function stopChildProcess(child, options = {}) {
  const gracefulTimeoutMs = options.gracefulTimeoutMs ?? 2000;
  const forceTimeoutMs = options.forceTimeoutMs ?? 2000;
  if (!child) return { status: 'NO_CHILD' };
  if (hasExited(child)) return { status: 'ALREADY_EXITED' };
  if (!Number.isFinite(gracefulTimeoutMs) || gracefulTimeoutMs < 0 ||
      !Number.isFinite(forceTimeoutMs) || forceTimeoutMs < 0) {
    throw new TypeError('CHILD_SHUTDOWN_TIMEOUT_INVALID');
  }

  const gracefulExit = waitForExit(child, gracefulTimeoutMs);
  if (!hasExited(child)) sendSignal(child, 'SIGTERM');
  if (await gracefulExit) {
    return { status: 'EXITED_AFTER_SIGTERM', exitCode: child.exitCode, signalCode: child.signalCode };
  }

  const forcedExit = waitForExit(child, forceTimeoutMs);
  if (!hasExited(child)) sendSignal(child, 'SIGKILL');
  if (await forcedExit) {
    return { status: 'EXITED_AFTER_SIGKILL', exitCode: child.exitCode, signalCode: child.signalCode };
  }

  throw new Error(`Child process pid ${child.pid} did not exit after SIGKILL`);
};
