'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { validateInstallScriptPolicy } = require('../../app/install-script-policy');

const now = new Date('2026-10-12T12:00:00.000Z');
const packageKey = 'node_modules/sqlite3';
const packages = { [packageKey]: { name: 'sqlite3', version: '5.1.7', hasInstallScript: true } };
const approval = { packageKey, packageName: 'sqlite3', version: '5.1.7', reason: 'Native binding build/install step required after review', approvedBy: 'security-reviewer', reviewedAt: '2026-10-01T00:00:00.000Z', expiresAt: '2026-12-01T00:00:00.000Z', changeTicket: 'RLA-SEC-REVIEW-001' };

test('install script is blocked without an exact package approval', () => {
  const blockers = validateInstallScriptPolicy(packages, { schemaVersion: 1, policyStatus: 'UNAPPROVED_TEMPLATE', policyOwner: null, approvedScripts: [] }, now);
  assert.ok(blockers.includes('INSTALL_SCRIPT_NOT_APPROVED:node_modules/sqlite3'));
});
test('reviewed exact package/version approval passes when policy is approved', () => {
  assert.deepEqual(validateInstallScriptPolicy(packages, { schemaVersion: 1, policyStatus: 'APPROVED', policyOwner: 'RLA Security Governance', approvedScripts: [approval] }, now), []);
});
test('policy approval status is mandatory even if entry metadata exists', () => {
  const blockers = validateInstallScriptPolicy(packages, { schemaVersion: 1, policyStatus: 'UNAPPROVED_TEMPLATE', policyOwner: null, approvedScripts: [approval] }, now);
  assert.ok(blockers.includes('INSTALL_SCRIPT_POLICY_NOT_APPROVED:node_modules/sqlite3'));
});
test('package version mismatch is rejected', () => {
  const blockers = validateInstallScriptPolicy(packages, { schemaVersion: 1, policyStatus: 'APPROVED', policyOwner: 'review board', approvedScripts: [{ ...approval, version: '5.1.8' }] }, now);
  assert.ok(blockers.includes('INSTALL_SCRIPT_APPROVAL_IDENTITY_MISMATCH:node_modules/sqlite3'));
});
test('expired approval is rejected', () => {
  const blockers = validateInstallScriptPolicy(packages, { schemaVersion: 1, policyStatus: 'APPROVED', policyOwner: 'review board', approvedScripts: [{ ...approval, expiresAt: '2026-10-11T00:00:00.000Z' }] }, now);
  assert.ok(blockers.includes('INSTALL_SCRIPT_APPROVAL_EXPIRED:node_modules/sqlite3'));
});
test('invalid or missing approval metadata is rejected', () => {
  const blockers = validateInstallScriptPolicy(packages, { schemaVersion: 1, policyStatus: 'APPROVED', policyOwner: 'review board', approvedScripts: [{ packageKey }] }, now);
  assert.ok(blockers.includes('INSTALL_SCRIPT_APPROVAL_FIELDS_INVALID'));
});
test('duplicate approvals are rejected', () => {
  const blockers = validateInstallScriptPolicy(packages, { schemaVersion: 1, policyStatus: 'APPROVED', policyOwner: 'review board', approvedScripts: [approval, approval] }, now);
  assert.ok(blockers.includes('INSTALL_SCRIPT_APPROVAL_DUPLICATE:node_modules/sqlite3'));
});
test('stale approvals for packages without install scripts are rejected', () => {
  const blockers = validateInstallScriptPolicy({ [packageKey]: { name: 'sqlite3', version: '5.1.7', hasInstallScript: false } }, { schemaVersion: 1, policyStatus: 'APPROVED', policyOwner: 'review board', approvedScripts: [approval] }, now);
  assert.ok(blockers.includes('INSTALL_SCRIPT_APPROVAL_STALE:node_modules/sqlite3'));
});
test('malformed policy and package maps fail closed', () => {
  assert.deepEqual(validateInstallScriptPolicy([], {}, now), ['INSTALL_SCRIPT_PACKAGE_MAP_INVALID']);
  assert.deepEqual(validateInstallScriptPolicy(packages, null, now), ['INSTALL_SCRIPT_POLICY_INVALID']);
});
