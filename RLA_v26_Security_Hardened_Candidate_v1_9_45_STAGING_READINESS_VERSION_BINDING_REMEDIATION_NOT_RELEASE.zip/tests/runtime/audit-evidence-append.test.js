'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const { appendEvidenceRecord, verifyEvidenceChain, verifyEvidenceFiles } = require('../../app/audit-evidence-chain');
const KEY = 'unit-test-audit-evidence-key-do-not-use-1234567890';
async function fixture(t) {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'rla-audit-append-'));
  await fs.chmod(root, 0o700);
  const recordsDir = path.join(root, 'records');
  const evidenceRoot = path.join(root, 'evidence');
  await fs.mkdir(recordsDir, { mode: 0o700 });
  await fs.mkdir(evidenceRoot, { mode: 0o700 });
  await fs.writeFile(path.join(evidenceRoot, 'event.json'), '{"event":"backup-completed"}\n', { mode: 0o600 });
  t.after(() => fs.rm(root, { recursive: true, force: true }));
  return { root, recordsDir, evidenceRoot };
}
async function append(f, overrides = {}) {
  return appendEvidenceRecord({ recordsDir: f.recordsDir, evidenceRoot: f.evidenceRoot, evidenceNames: ['event.json'], key: KEY,
    actorId: 'operator-12', eventType: 'BACKUP_VERIFIED', changeRef: 'CHG-2026-1001',
    now: new Date('2026-10-12T12:00:00.000Z'), ...overrides });
}
async function loadChain(f) {
  const names = (await fs.readdir(f.recordsDir)).filter(n => /^record-\d{6}\.json$/.test(n)).sort();
  return Promise.all(names.map(n => fs.readFile(path.join(f.recordsDir, n), 'utf8').then(JSON.parse)));
}
test('appends first record and creates a valid private record file', async t => {
  const f = await fixture(t); const result = await append(f);
  assert.equal(result.sequence, 1);
  const st = await fs.stat(path.join(f.recordsDir, result.recordName));
  if (process.platform !== 'win32') assert.equal(st.mode & 0o777, 0o600);
  const records = await loadChain(f);
  assert.equal(verifyEvidenceChain(records, KEY).recordCount, 1);
  assert.equal(await verifyEvidenceFiles(records[0], f.evidenceRoot), true);
});
test('appends contiguous linked records', async t => {
  const f = await fixture(t); await append(f);
  await append(f, { eventType: 'RESTORE_VERIFIED', changeRef: 'CHG-2026-1002' });
  assert.equal(verifyEvidenceChain(await loadChain(f), KEY).recordCount, 2);
});
test('refuses append when an append lock already exists', async t => {
  const f = await fixture(t); await fs.mkdir(path.join(f.recordsDir, '.append.lock'), { mode: 0o700 });
  await assert.rejects(append(f), /lock exists/);
});
test('refuses append when prior chain has been tampered with', async t => {
  const f = await fixture(t); await append(f);
  const p = path.join(f.recordsDir, 'record-000001.json'); const record = JSON.parse(await fs.readFile(p, 'utf8'));
  record.eventType = 'ALTERED'; await fs.writeFile(p, JSON.stringify(record));
  await assert.rejects(append(f), /HMAC verification failed/);
});
test('refuses unsafe evidence names', async t => {
  const f = await fixture(t); await assert.rejects(append(f, { evidenceNames: ['../event.json'] }), /safe relative path/);
});
test('refuses non-private records or evidence directories on POSIX', async t => {
  const f = await fixture(t); if (process.platform === 'win32') return;
  await fs.chmod(f.recordsDir, 0o755); await assert.rejects(append(f), /must be private/);
});
test('rejects invalid existing sequence file without overwriting it', async t => {
  const f = await fixture(t); const p = path.join(f.recordsDir, 'record-000001.json');
  await fs.writeFile(p, 'not a valid record', { mode: 0o600 });
  await assert.rejects(append(f), /HMAC verification failed|schema is invalid|not valid JSON|Unexpected token/);
  assert.equal(await fs.readFile(p, 'utf8'), 'not a valid record');
});

test('refuses to follow a symlink substituted for an existing audit record', async t => {
  const f = await fixture(t); const first = await append(f);
  const recordPath = path.join(f.recordsDir, first.recordName);
  const outside = path.join(f.root, 'outside-record.json');
  await fs.copyFile(recordPath, outside);
  await fs.unlink(recordPath);
  await fs.symlink(outside, recordPath);
  await assert.rejects(append(f), /regular non-symlink file|ELOOP|too many symbolic links/i);
});
test('rejects an oversized existing audit record before parsing it', async t => {
  const f = await fixture(t); const p = path.join(f.recordsDir, 'record-000001.json');
  await fs.writeFile(p, 'x'.repeat(1024 * 1024 + 1), { mode: 0o600 });
  await assert.rejects(append(f), /1 MiB size limit/);
});
