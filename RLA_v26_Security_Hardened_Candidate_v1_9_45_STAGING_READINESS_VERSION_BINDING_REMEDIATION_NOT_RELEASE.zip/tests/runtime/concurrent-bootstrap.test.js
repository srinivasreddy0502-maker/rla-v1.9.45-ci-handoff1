'use strict';
// Test-only offline smoke test: two Node processes initialize the same fresh SQLite file concurrently.
// Uses the node:sqlite compatibility adapter, not the native npm sqlite3 driver.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawn } = require('node:child_process');
const stopChildProcess = require('./test-support/stop-child');
const root = path.resolve(__dirname, '../..');
const adapterNodeModules = path.join(__dirname, 'test-support', 'node_modules');
const token = 'offline-concurrent-bootstrap-token-0123456789';
const policy = JSON.stringify({ ADMIN: ['applications:create', 'applications:read', 'audit:read'] });
function freePort() {
  const net = require('node:net');
  return new Promise((resolve, reject) => {
    const srv = net.createServer(); srv.once('error', reject);
    srv.listen(0, '127.0.0.1', () => { const port = srv.address().port; srv.close(err => err ? reject(err) : resolve(port)); });
  });
}
function startServer(port, dbPath) {
  return spawn(process.execPath, ['app/server.js'], { cwd: root, env: {
    ...process.env,
    NODE_PATH: adapterNodeModules + (process.env.NODE_PATH ? path.delimiter + process.env.NODE_PATH : ''),
    PORT: String(port), RLA_DB_PATH: dbPath, RLA_BOOTSTRAP_ADMIN_TOKEN: token,
    RLA_BOOTSTRAP_ADMIN_JURISDICTION: 'TEST-JURISDICTION', RLA_AUTHZ_POLICY_JSON: policy, NODE_ENV: 'test'
  }, stdio: ['ignore', 'pipe', 'pipe'] });
}
async function waitReady(proc, port) {
  const deadline = Date.now() + 10000; let output = '';
  proc.stdout.on('data', d => { output += d.toString(); }); proc.stderr.on('data', d => { output += d.toString(); });
  while (Date.now() < deadline) {
    if (proc.exitCode !== null) throw new Error(`server exited early: ${output}`);
    try { const res = await fetch(`http://127.0.0.1:${port}/api/health`, { signal: AbortSignal.timeout(1000) }); if (res.ok) return; } catch (_) {}
    await new Promise(r => setTimeout(r, 50));
  }
  throw new Error(`server readiness timeout: ${output}`);
}
async function stopServer(proc) {
  return stopChildProcess(proc, { gracefulTimeoutMs: 2000, forceTimeoutMs: 2000 });
}
test('two processes can concurrently initialize schema and one-time bootstrap on a fresh database', async t => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rla-bootstrap-race-'));
  const dbPath = path.join(dir, 'fresh.sqlite');
  const ports = await Promise.all([freePort(), freePort()]);
  assert.notEqual(ports[0], ports[1]);
  const first = startServer(ports[0], dbPath);
  const second = startServer(ports[1], dbPath);
  t.after(async () => { await stopServer(second); await stopServer(first); fs.rmSync(dir, { recursive: true, force: true }); });
  const outcomes = await Promise.allSettled([waitReady(first, ports[0]), waitReady(second, ports[1])]);
  assert.deepEqual(outcomes.map(x => x.status), ['fulfilled', 'fulfilled'], JSON.stringify(outcomes.map(x => x.status === 'rejected' ? String(x.reason) : 'ready')));
  const resps = await Promise.all(ports.map(port => fetch(`http://127.0.0.1:${port}/api/applications`, { headers: { authorization: `Bearer ${token}` } })));
  assert.deepEqual(resps.map(r => r.status), [200, 200]);
  const adminCount = await new Promise((resolve, reject) => {
    const { DatabaseSync } = require('node:sqlite');
    try { const db = new DatabaseSync(dbPath); const row = db.prepare("SELECT COUNT(*) AS n FROM users WHERE id='U_BOOTSTRAP_ADMIN'").get(); db.close(); resolve(Number(row.n)); }
    catch (e) { reject(e); }
  });
  assert.equal(adminCount, 1, 'one-time bootstrap administrator must exist exactly once');
});
