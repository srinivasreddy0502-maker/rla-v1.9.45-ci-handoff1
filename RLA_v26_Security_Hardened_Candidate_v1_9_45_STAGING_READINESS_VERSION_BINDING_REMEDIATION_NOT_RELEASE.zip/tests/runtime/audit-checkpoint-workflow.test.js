'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const { createEvidenceRecord } = require('../../app/audit-evidence-chain');
const { healthCheckEvidenceStore, checkpointAndPublish, inspectCheckpointStore, verifyPublishedCheckpoint } = require('../../app/audit-evidence-checkpoint-workflow');
const auditKey = 'audit-workflow-test-key-at-least-32-bytes-long';
const storeKey = 'store-workflow-test-key-at-least-32-bytes-long';
async function fixture(t) {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'rla-checkpoint-workflow-'));
  t.after(() => fs.rm(root, { recursive: true, force: true }));
  const recordsDir = path.join(root, 'records');
  const stagingDir = path.join(root, 'staging');
  const storageDir = path.join(root, 'store');
  for (const d of [recordsDir, stagingDir, storageDir]) await fs.mkdir(d, { mode: 0o700 });
  const evidenceRoot = path.join(root, 'evidence');
  await fs.mkdir(evidenceRoot, { mode: 0o700 });
  await fs.writeFile(path.join(evidenceRoot, 'sample.txt'), 'evidence for checkpoint workflow\n', { mode: 0o600 });
  const record = await createEvidenceRecord({ evidenceRoot, evidenceNames: ['sample.txt'], sequence: 1, previousRecordDigest: null, key: auditKey, actorId: 'test-operator', eventType: 'CHECKPOINT_WORKFLOW_TEST', changeRef: 'TEST-0001', now: new Date('2026-10-12T00:00:00.000Z') });
  await fs.writeFile(path.join(recordsDir, 'record-000001.json'), JSON.stringify(record, null, 2)+'\n', { mode: 0o600 });
  return { recordsDir, stagingDir, storageDir };
}
test('storage health check writes, fsyncs, and removes a unique probe', async t => {
  const f = await fixture(t);
  assert.deepEqual(await healthCheckEvidenceStore(f.storageDir), { healthy: true, writable: true, fsync: true, probeRemoved: true });
  assert.deepEqual(await fs.readdir(f.storageDir), []);
});
test('orchestrates verified chain checkpoint publication and independent verification', async t => {
  const f = await fixture(t);
  const result = await checkpointAndPublish({ ...f, checkpointId: 'flow-0001', auditKey, storeKey, storeKeyId: 'store-key-a', now: new Date('2026-10-12T01:00:00.000Z') });
  assert.equal(result.status, 'PUBLISHED');
  assert.equal(result.recordCount, 1);
  const verified = await verifyPublishedCheckpoint({ storageDir: f.storageDir, checkpointId: 'flow-0001', storeKeys: { 'store-key-a': storeKey }, checkpointKey: auditKey, recordsDir: f.recordsDir });
  assert.equal(verified.valid, true);
});
test('does not overwrite a checkpoint id or erase staged evidence on repeat attempt', async t => {
  const f = await fixture(t);
  const args = { ...f, checkpointId: 'immutable-0001', auditKey, storeKey, storeKeyId: 'store-key-a' };
  await checkpointAndPublish(args);
  await assert.rejects(() => checkpointAndPublish(args), /EEXIST/);
  assert.equal((await fs.readdir(f.stagingDir)).includes('immutable-0001.checkpoint.json'), true);
});
test('read-only inventory identifies a partial checkpoint publication without auto-repair', async t => {
  const f = await fixture(t);
  await fs.writeFile(path.join(f.storageDir, 'orphan-0001.checkpoint.json'), '{"forensic":"retain"}\n', { mode: 0o400 });
  const inventory = await inspectCheckpointStore(f.storageDir);
  assert.equal(inventory.readOnly, true);
  assert.equal(inventory.automaticRepair, false);
  assert.equal(inventory.items[0].state, 'ORPHAN_CHECKPOINT_REQUIRES_RECONCILIATION');
  assert.equal(await fs.readFile(path.join(f.storageDir, 'orphan-0001.checkpoint.json'), 'utf8'), '{"forensic":"retain"}\n');
});
test('flags receipt-only partial publication for operator reconciliation', async t => {
  const f = await fixture(t);
  await fs.writeFile(path.join(f.storageDir, 'orphan-0002.receipt.json'), '{}\n', { mode: 0o400 });
  const inventory = await inspectCheckpointStore(f.storageDir);
  assert.equal(inventory.items[0].state, 'ORPHAN_RECEIPT_REQUIRES_RECONCILIATION');
});
test('rejects using same directory for staging and external store', async t => {
  const f = await fixture(t);
  await assert.rejects(() => checkpointAndPublish({ ...f, storageDir: f.stagingDir, checkpointId: 'bad-layout', auditKey, storeKey, storeKeyId: 'store-key-a' }), /must be separate/);
});
