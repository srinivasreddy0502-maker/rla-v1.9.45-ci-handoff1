'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const { acquireSchedulerLock, releaseSchedulerLock, inspectSchedulerLock } = require('../../app/scheduler-lock');

async function fixture(t) {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'rla-lock-inspect-'));
  await fs.chmod(root, 0o700);
  t.after(() => fs.rm(root, { recursive: true, force: true }));
  return root;
}

test('inspection reports existing PID conservatively and never exposes token', async t => {
  const root = await fixture(t);
  const lock = await acquireSchedulerLock(path.join(root, 'backup.lock'));
  const result = await inspectSchedulerLock(lock.lockPath, { processExists: async pid => pid === process.pid });
  assert.equal(result.status, 'pid-present-owner-identity-unproven-review-required');
  assert.equal(result.automaticCleanup, false);
  assert.equal(result.tokenExposed, false);
  assert.equal(Object.hasOwn(result, 'token'), false);
  await releaseSchedulerLock(lock);
});

test('missing PID is only possibly stale and lock remains untouched', async t => {
  const root = await fixture(t);
  const lock = await acquireSchedulerLock(path.join(root, 'backup.lock'));
  const result = await inspectSchedulerLock(lock.lockPath, { processExists: async () => false });
  assert.equal(result.status, 'possibly-stale-lock-operator-review-required');
  assert.equal(result.automaticCleanup, false);
  assert.equal((await fs.stat(lock.lockPath)).isDirectory(), true);
  await releaseSchedulerLock(lock);
});

test('invalid metadata schema fails closed', async t => {
  const root = await fixture(t);
  const lock = await acquireSchedulerLock(path.join(root, 'backup.lock'));
  await fs.writeFile(path.join(lock.lockPath, 'owner.json'), JSON.stringify({ schemaVersion: 1, pid: -1 }));
  await assert.rejects(inspectSchedulerLock(lock.lockPath), /schema is invalid/);
});

test('symlink metadata is rejected', async t => {
  const root = await fixture(t);
  const lock = await acquireSchedulerLock(path.join(root, 'backup.lock'));
  const metadata = path.join(lock.lockPath, 'owner.json');
  const replacement = path.join(root, 'replacement.json');
  await fs.writeFile(replacement, await fs.readFile(metadata));
  await fs.unlink(metadata);
  await fs.symlink(replacement, metadata);
  await assert.rejects(inspectSchedulerLock(lock.lockPath), /not a regular file/);
});

test('unknown process state remains review-required', async t => {
  const root = await fixture(t);
  const lock = await acquireSchedulerLock(path.join(root, 'backup.lock'));
  const result = await inspectSchedulerLock(lock.lockPath, { processExists: async () => null });
  assert.equal(result.status, 'process-state-unknown-operator-review-required');
  await releaseSchedulerLock(lock);
});
