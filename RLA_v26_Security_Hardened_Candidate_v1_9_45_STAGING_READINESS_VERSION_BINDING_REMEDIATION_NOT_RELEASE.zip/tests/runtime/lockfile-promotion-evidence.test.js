'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { validateLockfilePromotionEvidence } = require('../../app/lockfile-promotion-evidence');

const registry = 'https://registry.npmjs.org/';
const env = { RLA_APPROVED_NPM_REGISTRIES: 'registry.npmjs.org' };
function sha(bytes) { return crypto.createHash('sha256').update(bytes).digest('hex'); }
function setup() {
  const rootDir = fs.mkdtempSync(path.join(os.tmpdir(), 'rla-lock-promotion-'));
  const packageBytes = Buffer.from(JSON.stringify({ name: 'rla-fixture', version: '1.0.0', dependencies: { sqlite3: '5.1.7' } }, null, 2) + '\n');
  const lockBytes = Buffer.from(JSON.stringify({ name: 'rla-fixture', version: '1.0.0', lockfileVersion: 3, requires: true, packages: { '': { name: 'rla-fixture', version: '1.0.0', dependencies: { sqlite3: '5.1.7' } } } }, null, 2) + '\n');
  fs.writeFileSync(path.join(rootDir, 'package.json'), packageBytes, { mode: 0o644 });
  fs.writeFileSync(path.join(rootDir, 'package-lock.json'), lockBytes, { mode: 0o644 });
  const evidence = {
    schemaVersion: 1,
    candidateVersion: require('../../package.json').version,
    generatedAt: '2026-10-13T10:00:00.000Z',
    staging: { approved: true, isolated: true, environmentId: 'STAGE-TEST-01', operatorId: 'operator-17' },
    registry: { origin: registry, tlsValidated: true, responseStatus: 200 },
    capture: {
      command: ['npm', 'install', '--package-lock-only', '--ignore-scripts', '--no-audit', '--no-fund', '--lockfile-version=3', `--registry=${registry}`],
      exitCode: 0, networkTestPerformed: true, installScriptsDisabled: true, npmCiExecuted: false,
      npmVersion: '10.8.2', nodeVersion: 'v22.10.0', workingDirectoryIsolated: true
    },
    lockfile: {
      sha256: sha(lockBytes), bytes: lockBytes.length, lockfileVersion: 3, packageJsonSha256: sha(packageBytes),
      dependencyReviewStatus: 'PASS', dependencyGraphReviewRef: 'review://graph/123', provenanceReviewed: true
    },
    review: { status: 'PASS', reviewerId: 'reviewer-42', reviewedAt: '2026-10-13T10:30:00.000Z', evidenceRef: 'audit://change/123' }
  };
  return { rootDir, evidence, cleanup: () => fs.rmSync(rootDir, { recursive: true, force: true }) };
}
function validate(fixture) { return validateLockfilePromotionEvidence({ rootDir: fixture.rootDir, evidence: fixture.evidence, env }); }

test('accepts internally consistent capture evidence only as pending external attestation', t => {
  const f = setup(); t.after(f.cleanup);
  const result = validate(f);
  assert.equal(result.status, 'EVIDENCE_CONSISTENT_PENDING_EXTERNAL_ATTESTATION');
  assert.deepEqual(result.blockers, []);
  assert.equal(result.cryptographicAttestationVerified, false);
  assert.equal(result.independentEnvironmentVerificationComplete, false);
  assert.equal(result.productionUseAuthorized, false);
  assert.equal(result.releaseStatus, 'RELEASE_BLOCKED');
});

test('rejects a stale hard-coded candidate version instead of the current package version', t => {
  const f = setup(); t.after(f.cleanup);
  f.evidence.candidateVersion = '1.9.39-candidate';
  assert.ok(validate(f).blockers.includes('CANDIDATE_VERSION_MISMATCH'));
});

test('blocks a lockfile whose bytes do not match the submitted digest', t => {
  const f = setup(); t.after(f.cleanup);
  fs.appendFileSync(path.join(f.rootDir, 'package-lock.json'), ' ');
  assert.ok(validate(f).blockers.includes('PACKAGE_LOCK_SHA256_MISMATCH'));
});

test('blocks a package manifest whose bytes do not match the reviewed digest', t => {
  const f = setup(); t.after(f.cleanup);
  fs.appendFileSync(path.join(f.rootDir, 'package.json'), ' ');
  assert.ok(validate(f).blockers.includes('PACKAGE_JSON_SHA256_MISMATCH'));
});

test('blocks an unapproved registry origin', t => {
  const f = setup(); t.after(f.cleanup);
  f.evidence.registry.origin = 'https://evil.example/';
  f.evidence.capture.command[7] = '--registry=https://evil.example/';
  assert.ok(validate(f).blockers.includes('REGISTRY_NOT_IN_APPROVED_ALLOWLIST'));
});

test('blocks a capture command that omits --ignore-scripts', t => {
  const f = setup(); t.after(f.cleanup);
  f.evidence.capture.command[2] = '--no-audit';
  assert.ok(validate(f).blockers.includes('CAPTURE_COMMAND_NOT_APPROVED'));
});

test('blocks any claim that npm ci ran during lockfile-only capture', t => {
  const f = setup(); t.after(f.cleanup);
  f.evidence.capture.npmCiExecuted = true;
  assert.ok(validate(f).blockers.includes('CAPTURE_EXECUTION_EVIDENCE_INCOMPLETE'));
});

test('blocks maker-checker identity reuse', t => {
  const f = setup(); t.after(f.cleanup);
  f.evidence.review.reviewerId = f.evidence.staging.operatorId;
  assert.ok(validate(f).blockers.includes('MAKER_CHECKER_SEPARATION_VIOLATION'));
});

test('blocks a review timestamp earlier than evidence generation', t => {
  const f = setup(); t.after(f.cleanup);
  f.evidence.review.reviewedAt = '2026-10-13T09:00:00.000Z';
  assert.ok(validate(f).blockers.includes('REVIEW_PRECEDES_EVIDENCE_GENERATION'));
});

test('blocks a symlinked lockfile', t => {
  const f = setup();
  const actual = path.join(f.rootDir, 'package-lock-real.json');
  fs.renameSync(path.join(f.rootDir, 'package-lock.json'), actual);
  fs.symlinkSync(actual, path.join(f.rootDir, 'package-lock.json'));
  t.after(f.cleanup);
  assert.ok(validate(f).blockers.includes('PACKAGE_LOCK_FILE_UNSAFE'));
});

test('blocks lockfiles with the wrong lockfile version', t => {
  const f = setup(); t.after(f.cleanup);
  const lockPath = path.join(f.rootDir, 'package-lock.json');
  const bytes = Buffer.from(JSON.stringify({ lockfileVersion: 2, packages: {} }) + '\n');
  fs.writeFileSync(lockPath, bytes);
  f.evidence.lockfile.sha256 = sha(bytes);
  f.evidence.lockfile.bytes = bytes.length;
  assert.ok(validate(f).blockers.includes('PACKAGE_LOCK_VERSION_NOT_3'));
});

test('blocks incomplete dependency graph review evidence', t => {
  const f = setup(); t.after(f.cleanup);
  f.evidence.lockfile.dependencyReviewStatus = 'PENDING';
  assert.ok(validate(f).blockers.includes('LOCKFILE_REVIEW_EVIDENCE_INCOMPLETE'));
});

test('blocks when approved isolated staging is not evidenced', t => {
  const f = setup(); t.after(f.cleanup);
  f.evidence.staging.isolated = false;
  assert.ok(validate(f).blockers.includes('APPROVED_ISOLATED_STAGING_EVIDENCE_INCOMPLETE'));
});

test('blocks unexpected fields to prevent silent schema drift', t => {
  const f = setup(); t.after(f.cleanup);
  f.evidence.lockfile.extraApproval = true;
  assert.ok(validate(f).blockers.includes('UNEXPECTED_FIELD_LOCKFILE:extraApproval'));
});

test('blocks a staging root that is itself a symlink', t => {
  const f = setup();
  const alias = `${f.rootDir}-alias`;
  fs.symlinkSync(f.rootDir, alias, 'dir');
  t.after(() => { fs.rmSync(alias, { force: true }); f.cleanup(); });
  const result = validateLockfilePromotionEvidence({ rootDir: alias, evidence: f.evidence, env });
  assert.ok(result.blockers.includes('STAGING_ROOT_UNSAFE'));
  assert.equal(result.observedLockfileSha256, null);
});

test('blocks a registry response that is not HTTP 200', t => {
  const f = setup(); t.after(f.cleanup);
  f.evidence.registry.responseStatus = 302;
  assert.ok(validate(f).blockers.includes('REGISTRY_CONNECTIVITY_EVIDENCE_INCOMPLETE'));
});

test('blocks lockfile root metadata that does not match package.json', t => {
  const f = setup(); t.after(f.cleanup);
  const lockPath = path.join(f.rootDir, 'package-lock.json');
  const lock = JSON.parse(fs.readFileSync(lockPath, 'utf8'));
  lock.packages[''].dependencies.sqlite3 = '5.1.6';
  const bytes = Buffer.from(JSON.stringify(lock, null, 2) + '\n');
  fs.writeFileSync(lockPath, bytes);
  f.evidence.lockfile.sha256 = sha(bytes);
  f.evidence.lockfile.bytes = bytes.length;
  assert.ok(validate(f).blockers.includes('PACKAGE_LOCK_ROOT_DEPENDENCIES_MISMATCH'));
});
