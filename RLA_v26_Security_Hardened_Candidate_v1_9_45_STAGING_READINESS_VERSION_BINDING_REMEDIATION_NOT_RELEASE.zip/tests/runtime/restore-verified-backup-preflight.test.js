'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { validateOperatorAttestation } = require('../../scripts/restore-verified-backup');

const SCRIPT = path.resolve(__dirname, '../../scripts/restore-verified-backup.js');
const KEY = 'test-only-restore-key-with-32-bytes-min';

test('restore requires explicit maintenance-stop and confirmation attestations', () => {
  assert.throws(() => validateOperatorAttestation({ RLA_BACKUP_MANIFEST_KEY: KEY }), /RLA_RESTORE_CONFIRM=YES/);
  assert.throws(() => validateOperatorAttestation({ RLA_BACKUP_MANIFEST_KEY: KEY, RLA_RESTORE_CONFIRM: 'YES' }), /MAINTENANCE_MODE=STOPPED/);
  assert.throws(() => validateOperatorAttestation({ RLA_BACKUP_MANIFEST_KEY: 'short', RLA_RESTORE_CONFIRM: 'YES', RLA_RESTORE_MAINTENANCE_MODE: 'STOPPED' }), /at least 32/);
  assert.doesNotThrow(() => validateOperatorAttestation({ RLA_BACKUP_MANIFEST_KEY: KEY, RLA_RESTORE_CONFIRM: 'YES', RLA_RESTORE_MAINTENANCE_MODE: 'STOPPED' }));
});

test('CLI fails closed before loading native sqlite3 when operator confirmation is absent', async t => {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'rla-restore-preflight-'));
  t.after(() => fs.rm(dir, { recursive: true, force: true }));
  const target = path.join(dir, 'target.sqlite');
  await fs.writeFile(target, 'existing-target-must-remain-untouched');
  const result = spawnSync(process.execPath, [SCRIPT, path.join(dir, 'backup.sqlite'), path.join(dir, 'manifest.json'), dir, target], {
    encoding: 'utf8',
    env: { ...process.env, RLA_BACKUP_MANIFEST_KEY: KEY, RLA_RESTORE_CONFIRM: '', RLA_RESTORE_MAINTENANCE_MODE: '' }
  });
  assert.equal(result.status, 1);
  assert.match(result.stderr, /RLA_RESTORE_CONFIRM=YES/);
  assert.equal(await fs.readFile(target, 'utf8'), 'existing-target-must-remain-untouched');
});

test('restore target preflight rejects SQLite WAL/SHM sidecars', async t => {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'rla-restore-sidecar-'));
  t.after(() => fs.rm(dir, { recursive: true, force: true }));
  const target = path.join(dir, 'target.sqlite');
  await fs.writeFile(target, 'existing-db');
  await fs.writeFile(`${target}-wal`, 'wal');
  const { assertSafeTarget } = require('../../scripts/restore-verified-backup');
  await assert.rejects(() => assertSafeTarget(target), /sidecar .* exists/);
});
