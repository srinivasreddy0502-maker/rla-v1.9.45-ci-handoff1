'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const { createEvidenceRecord, verifyEvidenceRecord, verifyEvidenceFiles, verifyEvidenceChain } = require('../../app/audit-evidence-chain');
const KEY = 'unit-test-audit-evidence-key-do-not-use-1234567890';
async function fixture(t) {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'rla-audit-chain-'));
  await fs.chmod(root, 0o700);
  await fs.mkdir(path.join(root, 'evidence'), { mode: 0o700 });
  t.after(() => fs.rm(root, { recursive: true, force: true }));
  await fs.writeFile(path.join(root, 'evidence', 'event.json'), '{"event":"backup-completed"}\n', { mode: 0o600 });
  return root;
}
async function rec(root, sequence, previousRecordDigest = null, overrides = {}) {
  return createEvidenceRecord({ evidenceRoot: path.join(root, 'evidence'), evidenceNames: ['event.json'], sequence,
    previousRecordDigest, key: KEY, actorId: 'operator-12', eventType: 'BACKUP_VERIFIED', changeRef: 'CHG-2026-1001',
    now: new Date(`2026-10-12T12:00:0${sequence}.000Z`), ...overrides });
}
test('creates and verifies a signed evidence record', async t => {
  const root = await fixture(t); const record = await rec(root, 1);
  assert.equal(verifyEvidenceRecord(record, KEY).valid, true);
  assert.equal(await verifyEvidenceFiles(record, path.join(root, 'evidence')), true);
});
test('rejects modified signed payload', async t => {
  const root = await fixture(t); const record = await rec(root, 1); record.eventType = 'RESTORE_FAILED';
  assert.throws(() => verifyEvidenceRecord(record, KEY), /HMAC verification failed/);
});
test('rejects evidence file tampering', async t => {
  const root = await fixture(t); const record = await rec(root, 1);
  await fs.writeFile(path.join(root, 'evidence', 'event.json'), 'changed');
  await assert.rejects(verifyEvidenceFiles(record, path.join(root, 'evidence')), /digest mismatch/);
});
test('verifies contiguous linked records', async t => {
  const root = await fixture(t); const first = await rec(root, 1);
  const digest = verifyEvidenceRecord(first, KEY).recordDigest;
  const second = await rec(root, 2, digest);
  assert.equal(verifyEvidenceChain([first, second], KEY).recordCount, 2);
});
test('rejects reordered or missing chain sequence', async t => {
  const root = await fixture(t); const first = await rec(root, 1);
  const second = await rec(root, 2, verifyEvidenceRecord(first, KEY).recordDigest);
  assert.throws(() => verifyEvidenceChain([second, first], KEY), /sequence is not contiguous/);
});
test('rejects path traversal and symlink evidence', async t => {
  const root = await fixture(t);
  await assert.rejects(rec(root, 1, null, { evidenceNames: ['../outside'] }), /safe relative path/);
  await fs.symlink(path.join(root, 'evidence', 'event.json'), path.join(root, 'evidence', 'link.json'));
  await assert.rejects(rec(root, 1, null, { evidenceNames: ['link.json'] }), /regular non-symlink/);
});
test('rejects weak key and broken previous-record digest', async t => {
  const root = await fixture(t);
  await assert.rejects(rec(root, 1, null, { key: 'short' }), /at least 32/);
  await assert.rejects(rec(root, 2, 'broken'), /require previousRecordDigest/);
});

test('rejects evidence-root symlinks and nested directory symlinks', async t => {
  const root = await fixture(t);
  const outside = path.join(root, 'outside');
  await fs.mkdir(outside, { mode: 0o700 });
  await fs.writeFile(path.join(outside, 'external.json'), '{\"outside\":true}\n', { mode: 0o600 });
  const rootAlias = path.join(root, 'evidence-alias');
  await fs.symlink(path.join(root, 'evidence'), rootAlias, 'dir');
  await assert.rejects(createEvidenceRecord({ evidenceRoot: rootAlias, evidenceNames: ['event.json'], sequence: 1,
    previousRecordDigest: null, key: KEY, actorId: 'operator-12', eventType: 'TEST', changeRef: 'TEST-ROOT',
    now: new Date('2026-10-13T00:00:00.000Z') }), /Evidence root must be a regular directory/);

  await fs.symlink(outside, path.join(root, 'evidence', 'nested'), 'dir');
  await assert.rejects(createEvidenceRecord({ evidenceRoot: path.join(root, 'evidence'), evidenceNames: ['nested/external.json'], sequence: 1,
    previousRecordDigest: null, key: KEY, actorId: 'operator-12', eventType: 'TEST', changeRef: 'TEST-NESTED',
    now: new Date('2026-10-13T00:00:01.000Z') }), /Evidence path components must not be symlinks/);
});
