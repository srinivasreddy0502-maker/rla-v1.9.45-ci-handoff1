'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const { createManifest, verifyManifest, stageVerifiedBackup } = require('../../app/backup-manifest');

const KEY = 'test-only-manifest-key-32-bytes-minimum';

test('authenticated backup manifest verifies intact artifact and is written privately', async t => {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'rla-backup-integrity-'));
  t.after(() => fs.rm(dir, { recursive: true, force: true }));
  const backup = path.join(dir, 'backup.sqlite');
  const manifestPath = path.join(dir, 'backup.manifest.json');
  await fs.writeFile(backup, Buffer.from('test database backup bytes'));
  const manifest = await createManifest(backup, manifestPath, KEY);
  assert.equal(manifest.artifact, 'backup.sqlite');
  assert.equal((await verifyManifest(backup, manifestPath, KEY)).ok, true);
  if (process.platform !== 'win32') assert.equal((await fs.stat(manifestPath)).mode & 0o777, 0o600);
});

test('tampered backup bytes are rejected before restore verification', async t => {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'rla-backup-tamper-'));
  t.after(() => fs.rm(dir, { recursive: true, force: true }));
  const backup = path.join(dir, 'backup.sqlite');
  const manifestPath = path.join(dir, 'backup.manifest.json');
  await fs.writeFile(backup, Buffer.from('trusted backup'));
  await createManifest(backup, manifestPath, KEY);
  await fs.writeFile(backup, Buffer.from('tampered backup'));
  await assert.rejects(() => verifyManifest(backup, manifestPath, KEY), /size does not match|SHA-256 does not match/);
});

test('manifest tampering and incorrect keys are rejected', async t => {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'rla-backup-manifest-tamper-'));
  t.after(() => fs.rm(dir, { recursive: true, force: true }));
  const backup = path.join(dir, 'backup.sqlite');
  const manifestPath = path.join(dir, 'backup.manifest.json');
  await fs.writeFile(backup, Buffer.from('trusted backup'));
  await createManifest(backup, manifestPath, KEY);
  await assert.rejects(() => verifyManifest(backup, manifestPath, 'wrong-key-at-least-32-bytes-long'), /authentication failed/);
  const manifest = JSON.parse(await fs.readFile(manifestPath, 'utf8'));
  manifest.sizeBytes += 1;
  await fs.writeFile(manifestPath, JSON.stringify(manifest));
  await assert.rejects(() => verifyManifest(backup, manifestPath, KEY), /authentication failed/);
});

test('weak keys and empty backup artifacts are rejected', async t => {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'rla-backup-invalid-'));
  t.after(() => fs.rm(dir, { recursive: true, force: true }));
  const backup = path.join(dir, 'empty.sqlite');
  const manifestPath = path.join(dir, 'backup.manifest.json');
  await fs.writeFile(backup, '');
  await assert.rejects(() => createManifest(backup, manifestPath, 'short'), /at least 32/);
  await assert.rejects(() => createManifest(backup, manifestPath, KEY), /non-empty/);
});


test('verified backup is staged privately and the staged snapshot is independent', async t => {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'rla-backup-stage-'));
  t.after(() => fs.rm(dir, { recursive: true, force: true }));
  const backup = path.join(dir, 'backup.sqlite');
  const manifestPath = path.join(dir, 'backup.manifest.json');
  const stagingRoot = path.join(dir, 'private-staging');
  await fs.mkdir(stagingRoot, { mode: 0o700 });
  await fs.writeFile(backup, Buffer.from('verified database backup bytes'));
  await createManifest(backup, manifestPath, KEY);
  const staged = await stageVerifiedBackup(backup, manifestPath, stagingRoot, KEY);
  assert.equal(staged.ok, true);
  assert.equal(path.basename(staged.stagedPath), 'backup.sqlite');
  assert.equal(await fs.readFile(staged.stagedPath, 'utf8'), 'verified database backup bytes');
  if (process.platform !== 'win32') {
    assert.equal((await fs.stat(staged.stagingDirectory)).mode & 0o777, 0o700);
    assert.equal((await fs.stat(staged.stagedPath)).mode & 0o777, 0o600);
  }
  await fs.writeFile(backup, 'source changed after staging');
  assert.equal(await fs.readFile(staged.stagedPath, 'utf8'), 'verified database backup bytes');
});

test('staging rejects public staging roots and cleans up after failed verification', async t => {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'rla-backup-stage-reject-'));
  t.after(() => fs.rm(dir, { recursive: true, force: true }));
  const backup = path.join(dir, 'backup.sqlite');
  const manifestPath = path.join(dir, 'backup.manifest.json');
  const publicRoot = path.join(dir, 'public-staging');
  await fs.mkdir(publicRoot, { mode: 0o700 });
  await fs.chmod(publicRoot, 0o755);
  await fs.writeFile(backup, 'trusted backup');
  await createManifest(backup, manifestPath, KEY);
  if (process.platform !== 'win32') {
    await assert.rejects(() => stageVerifiedBackup(backup, manifestPath, publicRoot, KEY), /group or other permissions/);
  }
  await fs.chmod(publicRoot, 0o700);
  await fs.writeFile(backup, 'tampered');
  await assert.rejects(() => stageVerifiedBackup(backup, manifestPath, publicRoot, KEY), /size does not match|SHA-256 does not match/);
  assert.deepEqual(await fs.readdir(publicRoot), []);
});

test('symbolic-link backup inputs are rejected for staging', async t => {
  if (process.platform === 'win32') return t.skip('symbolic-link permissions vary on Windows');
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'rla-backup-stage-symlink-'));
  t.after(() => fs.rm(dir, { recursive: true, force: true }));
  const backup = path.join(dir, 'backup.sqlite');
  const linkedBackup = path.join(dir, 'linked.sqlite');
  const manifestPath = path.join(dir, 'backup.manifest.json');
  const stagingRoot = path.join(dir, 'staging');
  await fs.mkdir(stagingRoot, { mode: 0o700 });
  await fs.writeFile(backup, 'trusted backup');
  await createManifest(backup, manifestPath, KEY);
  await fs.symlink(backup, linkedBackup);
  await assert.rejects(() => stageVerifiedBackup(linkedBackup, manifestPath, stagingRoot, KEY), /symbolic link/);
});


test('symbolic-link staging roots are rejected', async t => {
  if (process.platform === 'win32') return t.skip('symbolic-link permissions vary on Windows');
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'rla-backup-root-symlink-'));
  t.after(() => fs.rm(dir, { recursive: true, force: true }));
  const backup = path.join(dir, 'backup.sqlite');
  const manifestPath = path.join(dir, 'backup.manifest.json');
  const realRoot = path.join(dir, 'real-staging');
  const linkedRoot = path.join(dir, 'linked-staging');
  await fs.mkdir(realRoot, { mode: 0o700 });
  await fs.writeFile(backup, 'trusted backup');
  await createManifest(backup, manifestPath, KEY);
  await fs.symlink(realRoot, linkedRoot, 'dir');
  await assert.rejects(() => stageVerifiedBackup(backup, manifestPath, linkedRoot, KEY), /not a symbolic link/);
});
