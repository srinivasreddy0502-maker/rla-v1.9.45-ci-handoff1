'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const { acquireSchedulerLock, releaseSchedulerLock } = require('../../app/scheduler-lock');

async function fixture(t) {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'rla-scheduler-lock-'));
  await fs.chmod(root, 0o700);
  t.after(() => fs.rm(root, { recursive: true, force: true }));
  return root;
}

test('acquires lock atomically and releases only its own lock', async t => {
  const root = await fixture(t);
  const lockPath = path.join(root, 'backup.lock');
  const lock = await acquireSchedulerLock(lockPath);
  assert.equal((await fs.stat(lockPath)).isDirectory(), true);
  const meta = JSON.parse(await fs.readFile(path.join(lockPath, 'owner.json'), 'utf8'));
  assert.equal(meta.pid, process.pid);
  assert.equal(meta.token, lock.token);
  if (process.platform !== 'win32') assert.equal((await fs.stat(path.join(lockPath, 'owner.json'))).mode & 0o777, 0o600);
  await releaseSchedulerLock(lock);
  await assert.rejects(fs.lstat(lockPath), { code: 'ENOENT' });
});

test('second scheduler refuses an existing lock', async t => {
  const root = await fixture(t);
  const lockPath = path.join(root, 'backup.lock');
  const first = await acquireSchedulerLock(lockPath);
  await assert.rejects(acquireSchedulerLock(lockPath), { code: 'EEXIST' });
  await releaseSchedulerLock(first);
});

test('wrong owner token cannot release lock', async t => {
  const root = await fixture(t);
  const lock = await acquireSchedulerLock(path.join(root, 'backup.lock'));
  await assert.rejects(releaseSchedulerLock({ ...lock, token: 'f'.repeat(64) }), /ownership mismatch/);
  await releaseSchedulerLock(lock);
});

test('lock parent with broad permissions is rejected on POSIX', async t => {
  const root = await fixture(t);
  const broad = path.join(root, 'broad');
  await fs.mkdir(broad, { mode: 0o777 });
  await fs.chmod(broad, 0o755);
  if (process.platform !== 'win32') await assert.rejects(acquireSchedulerLock(path.join(broad, 'backup.lock')), /must not grant group or other permissions/);
});

test('lock release fails closed if metadata is missing or replaced', async t => {
  const root = await fixture(t);
  const lock = await acquireSchedulerLock(path.join(root, 'backup.lock'));
  await fs.unlink(path.join(lock.lockPath, 'owner.json'));
  await assert.rejects(releaseSchedulerLock(lock));
  // Deliberately leave a malformed lock for operator-reviewed cleanup.
  assert.equal((await fs.stat(lock.lockPath)).isDirectory(), true);
});
