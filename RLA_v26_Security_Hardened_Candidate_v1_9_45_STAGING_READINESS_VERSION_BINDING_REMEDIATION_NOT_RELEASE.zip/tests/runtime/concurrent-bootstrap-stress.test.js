'use strict';
// Offline stress test only: repeats simultaneous first-time bootstrap against fresh SQLite files.
// Uses Node's built-in node:sqlite compatibility adapter, not the native npm sqlite3 driver.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawn } = require('node:child_process');
const stopChildProcess = require('./test-support/stop-child');
const net = require('node:net');
const http = require('node:http');
const root = path.resolve(__dirname, '../..');
const adapterNodeModules = path.join(__dirname, 'test-support', 'node_modules');
const token = 'offline-bootstrap-stress-token-0123456789';
const policy = JSON.stringify({ ADMIN: ['applications:create', 'applications:read', 'audit:read'] });
function freePort() {
  return new Promise((resolve, reject) => {
    const srv = net.createServer(); srv.once('error', reject);
    srv.listen(0, '127.0.0.1', () => { const port = srv.address().port; srv.close(err => err ? reject(err) : resolve(port)); });
  });
}
// Use one-shot HTTP requests and fully drain response bodies. Undici's pooled fetch
// connections can keep the test runner alive after all TAP tests finish in this stress loop.
function requestStatus(port, pathname, headers = {}, timeoutMs = 3000) {
  return new Promise((resolve, reject) => {
    const req = http.request({ hostname: '127.0.0.1', port, path: pathname, method: 'GET', headers, agent: false, timeout: timeoutMs }, res => {
      res.resume();
      res.once('end', () => resolve(res.statusCode));
      res.once('error', reject);
    });
    req.once('timeout', () => req.destroy(new Error(`HTTP_TIMEOUT_${pathname}`)));
    req.once('error', reject);
    req.end();
  });
}
function startServer(port, dbPath) {
  return spawn(process.execPath, ['app/server.js'], { cwd: root, env: {
    ...process.env,
    NODE_PATH: adapterNodeModules + (process.env.NODE_PATH ? path.delimiter + process.env.NODE_PATH : ''),
    PORT: String(port), RLA_DB_PATH: dbPath, RLA_BOOTSTRAP_ADMIN_TOKEN: token,
    RLA_BOOTSTRAP_ADMIN_JURISDICTION: 'TEST-JURISDICTION', RLA_AUTHZ_POLICY_JSON: policy, NODE_ENV: 'test'
  }, stdio: ['ignore', 'pipe', 'pipe'] });
}
async function waitReady(proc, port) {
  // Under a full offline chain, SQLite startup contention can outlast the single-race probe. Keep a bounded 30s deadline and retain fail-closed behavior.
  const deadline = Date.now() + 30000; let output = '';
  proc.stdout.on('data', d => { output += d.toString(); }); proc.stderr.on('data', d => { output += d.toString(); });
  while (Date.now() < deadline) {
    if (proc.exitCode !== null) throw new Error(`server exited early: ${output}`);
    try { const status = await requestStatus(port, '/api/health', {}, 1000); if (status >= 200 && status < 300) return; } catch (_) {}
    await new Promise(r => setTimeout(r, 25));
  }
  throw new Error(`server readiness timeout: ${output}`);
}
async function stopServer(proc) {
  return stopChildProcess(proc, { gracefulTimeoutMs: 1500, forceTimeoutMs: 1500 });
}
async function oneIteration(iteration) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), `rla-bootstrap-stress-${iteration}-`));
  const dbPath = path.join(dir, 'fresh.sqlite');
  let first, second;
  try {
    const ports = await Promise.all([freePort(), freePort()]);
    assert.notEqual(ports[0], ports[1]);
    first = startServer(ports[0], dbPath);
    second = startServer(ports[1], dbPath);
    const outcomes = await Promise.allSettled([waitReady(first, ports[0]), waitReady(second, ports[1])]);
    assert.deepEqual(outcomes.map(x => x.status), ['fulfilled', 'fulfilled'], `iteration ${iteration}: ${JSON.stringify(outcomes.map(x => x.status === 'rejected' ? String(x.reason) : 'ready'))}`);
    const statuses = await Promise.all(ports.map(port => requestStatus(port, '/api/applications', { authorization: `Bearer ${token}` })));
    assert.deepEqual(statuses, [200, 200], `iteration ${iteration}: both processes should serve authenticated requests`);
    const { DatabaseSync } = require('node:sqlite');
    const db = new DatabaseSync(dbPath);
    try {
      const count = Number(db.prepare("SELECT COUNT(*) AS n FROM users WHERE id='U_BOOTSTRAP_ADMIN'").get().n);
      assert.equal(count, 1, `iteration ${iteration}: bootstrap administrator must exist exactly once`);
    } finally { db.close(); }
  } finally {
    await stopServer(second); await stopServer(first);
    fs.rmSync(dir, { recursive: true, force: true });
  }
}
test('concurrent first-time bootstrap stress: 10 fresh databases, two processes each', async t => {
  for (let i = 1; i <= 10; i++) {
    await t.test(`bootstrap race iteration ${i}/10`, async () => oneIteration(i));
  }
});
