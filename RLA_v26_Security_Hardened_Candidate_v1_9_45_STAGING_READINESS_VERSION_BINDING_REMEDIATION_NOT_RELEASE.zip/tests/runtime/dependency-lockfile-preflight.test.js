'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { checkDependencyLockfile, parseApprovedHosts } = require('../../app/dependency-lockfile-preflight');

const VALID_INTEGRITY = `sha512-${Buffer.alloc(64, 1).toString('base64')}`;

function fixture({ version = '5.1.7', lockVersion = 3, resolved = 'https://registry.npmjs.org/sqlite3/-/sqlite3-5.1.7.tgz', integrity = VALID_INTEGRITY, rootVersion = version, includeLock = true } = {}) {
  const rootDir = fs.mkdtempSync(path.join(os.tmpdir(), 'rla-lock-preflight-'));
  fs.writeFileSync(path.join(rootDir, 'package.json'), JSON.stringify({ name: 'fixture', version: '1.0.0', dependencies: { sqlite3: version } }));
  fs.mkdirSync(path.join(rootDir, 'config'), { recursive: true });
  fs.writeFileSync(path.join(rootDir, 'config', 'dependency-install-script-policy.json'), JSON.stringify({ schemaVersion: 1, policyStatus: 'UNAPPROVED_TEMPLATE', policyOwner: null, approvedScripts: [] }));
  if (includeLock) fs.writeFileSync(path.join(rootDir, 'package-lock.json'), JSON.stringify({
    name: 'fixture', version: '1.0.0', lockfileVersion: lockVersion, requires: true,
    packages: { '': { name: 'fixture', version: '1.0.0', dependencies: { sqlite3: rootVersion } }, 'node_modules/sqlite3': { version: '5.1.7', resolved, ...(integrity === null ? {} : { integrity }) } }
  }));
  return rootDir;
}

test('exact, lockfile-pinned direct dependency from approved HTTPS registry passes', () => {
  const rootDir = fixture();
  const r = checkDependencyLockfile({ rootDir });
  assert.equal(r.status, 'PASS');
  assert.equal(r.installAllowed, true);
  assert.equal(r.productionUseAuthorized, false);
});
test('oversized package metadata is rejected before JSON parsing', () => {
  const rootDir = fixture();
  fs.writeFileSync(path.join(rootDir, 'package.json'), JSON.stringify({ name: 'fixture', version: '1.0.0', dependencies: { sqlite3: '5.1.7' } }) + ' '.repeat(1024 * 1024));
  const report = checkDependencyLockfile({ rootDir });
  assert.equal(report.status, 'BLOCKED');
  assert.ok(report.blockers.includes('PACKAGE_JSON_TOO_LARGE'));
  assert.equal(report.installAllowed, false);
});

test('oversized lockfile is rejected with bounded read before JSON parsing', () => {
  const rootDir = fixture();
  const lockPath = path.join(rootDir, 'package-lock.json');
  const fd = fs.openSync(lockPath, 'w');
  try { fs.ftruncateSync(fd, 32 * 1024 * 1024 + 1); } finally { fs.closeSync(fd); }
  const report = checkDependencyLockfile({ rootDir });
  assert.equal(report.status, 'BLOCKED');
  assert.ok(report.blockers.includes('PACKAGE_LOCK_JSON_TOO_LARGE'));
  assert.equal(report.installAllowed, false);
});

test('oversized install-script policy is rejected before JSON parsing', () => {
  const rootDir = fixture();
  const policyPath = path.join(rootDir, 'config', 'dependency-install-script-policy.json');
  fs.writeFileSync(policyPath, JSON.stringify({ schemaVersion: 1, policyStatus: 'UNAPPROVED_TEMPLATE', policyOwner: null, approvedScripts: [] }) + ' '.repeat(1024 * 1024));
  const report = checkDependencyLockfile({ rootDir });
  assert.equal(report.status, 'BLOCKED');
  assert.ok(report.blockers.includes('INSTALL_SCRIPT_POLICY_TOO_LARGE'));
  assert.equal(report.installAllowed, false);
});


test('preflight rejects group/world-writable package metadata', () => {
  const rootDir = fixture();
  const packagePath = path.join(rootDir, 'package.json');
  fs.chmodSync(packagePath, 0o666);
  const report = checkDependencyLockfile({ rootDir });
  assert.equal(report.status, 'BLOCKED');
  assert.ok(report.blockers.includes('PACKAGE_JSON_PATH_UNSAFE'));
  assert.equal(report.installAllowed, false);
});

test('preflight rejects group/world-writable lockfile', () => {
  const rootDir = fixture();
  fs.chmodSync(path.join(rootDir, 'package-lock.json'), 0o666);
  const report = checkDependencyLockfile({ rootDir });
  assert.equal(report.status, 'BLOCKED');
  assert.ok(report.blockers.includes('PACKAGE_LOCK_PATH_UNSAFE'));
  assert.equal(report.installAllowed, false);
});

test('preflight rejects group/world-writable config directory', () => {
  const rootDir = fixture();
  fs.chmodSync(path.join(rootDir, 'config'), 0o777);
  const report = checkDependencyLockfile({ rootDir });
  assert.equal(report.status, 'BLOCKED');
  assert.ok(report.blockers.includes('INSTALL_SCRIPT_POLICY_DIRECTORY_UNSAFE'));
  assert.equal(report.installAllowed, false);
});

test('preflight rejects hard-linked package metadata', t => {
  const rootDir = fixture();
  const packagePath = path.join(rootDir, 'package.json');
  const aliasPath = path.join(rootDir, 'package-copy.json');
  try { fs.linkSync(packagePath, aliasPath); }
  catch (error) { t.skip(`hard links unavailable: ${error.code}`); fs.rmSync(rootDir, { recursive: true, force: true }); return; }
  const report = checkDependencyLockfile({ rootDir });
  assert.equal(report.status, 'BLOCKED');
  assert.ok(report.blockers.includes('PACKAGE_JSON_PATH_UNSAFE'));
  assert.equal(report.installAllowed, false);
});

test('missing package lock blocks installation', () => {
  const r = checkDependencyLockfile({ rootDir: fixture({ includeLock: false }) });
  assert.equal(r.status, 'BLOCKED');
  assert.ok(r.blockers.includes('PACKAGE_LOCK_JSON_MISSING'));
  assert.equal(r.installAllowed, false);
});
test('range dependency is rejected even if a lockfile exists', () => {
  const r = checkDependencyLockfile({ rootDir: fixture({ version: '^5.1.7', rootVersion: '^5.1.7' }) });
  assert.ok(r.blockers.includes('DIRECT_DEPENDENCY_NOT_EXACTLY_PINNED:sqlite3'));
});
test('root dependency mismatch is rejected', () => {
  const r = checkDependencyLockfile({ rootDir: fixture({ rootVersion: '5.1.8' }) });
  assert.ok(r.blockers.includes('ROOT_DEPENDENCY_MISMATCH:sqlite3'));
});
test('lockfile package identity mismatch is rejected', () => {
  const rootDir = fixture();
  const lockPath = path.join(rootDir, 'package-lock.json');
  const lock = JSON.parse(fs.readFileSync(lockPath, 'utf8'));
  lock.version = '2.0.0';
  fs.writeFileSync(lockPath, JSON.stringify(lock));
  assert.ok(checkDependencyLockfile({ rootDir }).blockers.includes('LOCKFILE_PACKAGE_VERSION_MISMATCH'));
});
test('old lockfile format is rejected', () => {
  const r = checkDependencyLockfile({ rootDir: fixture({ lockVersion: 2 }) });
  assert.ok(r.blockers.includes('LOCKFILE_VERSION_MUST_BE_3_OR_NEWER'));
});
test('unapproved, non-HTTPS, or credential-bearing tarball origins are rejected', () => {
  for (const resolved of ['https://evil.example/pkg.tgz', 'http://registry.npmjs.org/pkg.tgz', 'https://user:secret@registry.npmjs.org/pkg.tgz']) {
    const r = checkDependencyLockfile({ rootDir: fixture({ resolved }) });
    assert.ok(r.blockers.some(x => x.startsWith('RESOLVED_TARBALL_ORIGIN_NOT_APPROVED:')));
  }
});
test('non-standard HTTPS ports, query strings, and fragments are rejected for tarball URLs', () => {
  for (const resolved of [
    'https://registry.npmjs.org:8443/sqlite3/-/sqlite3-5.1.7.tgz',
    'https://registry.npmjs.org/sqlite3/-/sqlite3-5.1.7.tgz?redirect=1',
    'https://registry.npmjs.org/sqlite3/-/sqlite3-5.1.7.tgz#fragment'
  ]) {
    const report = checkDependencyLockfile({ rootDir: fixture({ resolved }) });
    assert.ok(report.blockers.includes('RESOLVED_TARBALL_ORIGIN_NOT_APPROVED:node_modules/sqlite3'), `${resolved}: ${report.blockers}`);
    assert.equal(report.installAllowed, false);
  }
});

test('self-declared bundled dependency cannot bypass registry and integrity checks', () => {
  const rootDir = fixture();
  const lockPath = path.join(rootDir, 'package-lock.json');
  const lock = JSON.parse(fs.readFileSync(lockPath, 'utf8'));
  lock.packages['node_modules/sqlite3'] = { version: '5.1.7', inBundle: true };
  fs.writeFileSync(lockPath, JSON.stringify(lock));
  const report = checkDependencyLockfile({ rootDir });
  assert.ok(report.blockers.includes('BUNDLED_DEPENDENCY_NOT_APPROVED:node_modules/sqlite3'));
  assert.equal(report.installAllowed, false);
});

test('missing or malformed integrity is rejected', () => {
  assert.ok(checkDependencyLockfile({ rootDir: fixture({ integrity: null }) }).blockers.includes('LOCK_ENTRY_INTEGRITY_MISSING:node_modules/sqlite3'));
  assert.ok(checkDependencyLockfile({ rootDir: fixture({ integrity: 'not-a-valid-integrity' }) }).blockers.includes('LOCK_ENTRY_INTEGRITY_INVALID:node_modules/sqlite3'));
  assert.ok(checkDependencyLockfile({ rootDir: fixture({ integrity: 'sha512-YWJjZA==' }) }).blockers.includes('LOCK_ENTRY_INTEGRITY_INVALID:node_modules/sqlite3'));
});
test('weak SRI algorithms are rejected even when the encoding is valid', () => {
  const weak = `sha256-${Buffer.alloc(32, 2).toString('base64')}`;
  assert.ok(checkDependencyLockfile({ rootDir: fixture({ integrity: weak }) }).blockers.includes('LOCK_ENTRY_INTEGRITY_ALGORITHM_NOT_SHA512:node_modules/sqlite3'));
});
test('non-canonical base64 integrity is rejected', () => {
  const invalid = `sha512-${Buffer.alloc(64, 1).toString('base64').replace(/=$/, 'A')}`;
  assert.ok(checkDependencyLockfile({ rootDir: fixture({ integrity: invalid }) }).blockers.includes('LOCK_ENTRY_INTEGRITY_INVALID:node_modules/sqlite3'));
});
test('registry allowlist accepts canonical DNS hostnames and normalizes case', () => {
  assert.deepEqual(parseApprovedHosts('MIRROR.Example,registry.npmjs.org'), ['mirror.example', 'registry.npmjs.org']);
  assert.deepEqual(parseApprovedHosts('xn--bcher-kva.example'), ['xn--bcher-kva.example']);
});

test('registry allowlist rejects URLs, malformed DNS labels, IP literals, and empty entries', () => {
  for (const value of [
    'https://registry.npmjs.org',
    ',registry.npmjs.org',
    'registry.npmjs.org,',
    'registry.npmjs.org,,mirror.example',
    'registry..npmjs.org',
    '.registry.npmjs.org',
    'registry.npmjs.org.',
    'reg_istry.npmjs.org',
    '-registry.npmjs.org',
    'registry-.npmjs.org',
    'localhost',
    '127.0.0.1',
    '127.1',
    '0177.0.0.1',
    '999.999.999.999',
    '2001:db8::1',
    'mïrror.example',
    `${'a'.repeat(64)}.example`,
    `${'a'.repeat(250)}.example`
  ]) assert.throws(() => parseApprovedHosts(value), undefined, `should reject ${value}`);
});
test('malformed package metadata blocks', () => {
  const rootDir = fs.mkdtempSync(path.join(os.tmpdir(), 'rla-lock-invalid-'));
  fs.writeFileSync(path.join(rootDir, 'package.json'), '{bad');
  const r = checkDependencyLockfile({ rootDir });
  assert.equal(r.status, 'BLOCKED');
  assert.deepEqual(r.blockers, ['PACKAGE_JSON_MISSING_OR_INVALID']);
});

test('dangling transitive dependency references block installation', () => {
  const rootDir = fixture();
  const lockPath = path.join(rootDir, 'package-lock.json');
  const lock = JSON.parse(fs.readFileSync(lockPath, 'utf8'));
  lock.packages['node_modules/sqlite3'].dependencies = { 'node-addon-api': '^7.0.0' };
  fs.writeFileSync(lockPath, JSON.stringify(lock));
  const report = checkDependencyLockfile({ rootDir });
  assert.ok(report.blockers.includes('LOCK_DEPENDENCY_TARGET_MISSING:node_modules/sqlite3:node-addon-api'));
  assert.equal(report.installAllowed, false);
});

test('transitive dependency resolves to the nearest valid node_modules ancestor', () => {
  const rootDir = fixture();
  const lockPath = path.join(rootDir, 'package-lock.json');
  const lock = JSON.parse(fs.readFileSync(lockPath, 'utf8'));
  lock.packages['node_modules/sqlite3'].dependencies = { 'node-addon-api': '^7.0.0' };
  lock.packages['node_modules/node-addon-api'] = {
    version: '7.1.0',
    resolved: 'https://registry.npmjs.org/node-addon-api/-/node-addon-api-7.1.0.tgz',
    integrity: VALID_INTEGRITY
  };
  fs.writeFileSync(lockPath, JSON.stringify(lock));
  const report = checkDependencyLockfile({ rootDir });
  assert.equal(report.status, 'PASS', JSON.stringify(report.blockers));
});

test('nested dependency references resolve through ancestor package scopes', () => {
  const rootDir = fixture();
  const lockPath = path.join(rootDir, 'package-lock.json');
  const lock = JSON.parse(fs.readFileSync(lockPath, 'utf8'));
  lock.packages['node_modules/sqlite3'].dependencies = { 'node-addon-api': '^7.0.0' };
  lock.packages['node_modules/sqlite3/node_modules/node-addon-api'] = {
    version: '7.1.0',
    resolved: 'https://registry.npmjs.org/node-addon-api/-/node-addon-api-7.1.0.tgz',
    integrity: VALID_INTEGRITY
  };
  fs.writeFileSync(lockPath, JSON.stringify(lock));
  const report = checkDependencyLockfile({ rootDir });
  assert.equal(report.status, 'PASS', JSON.stringify(report.blockers));
});

test('malformed transitive dependency declarations are rejected', () => {
  const rootDir = fixture();
  const lockPath = path.join(rootDir, 'package-lock.json');
  const lock = JSON.parse(fs.readFileSync(lockPath, 'utf8'));
  lock.packages['node_modules/sqlite3'].dependencies = [];
  fs.writeFileSync(lockPath, JSON.stringify(lock));
  assert.ok(checkDependencyLockfile({ rootDir }).blockers.includes('LOCK_ENTRY_DEPENDENCIES_INVALID:node_modules/sqlite3'));
});


test('transitive lock entries require an exact version', () => {
  const rootDir = fixture();
  const lockPath = path.join(rootDir, 'package-lock.json');
  const lock = JSON.parse(fs.readFileSync(lockPath, 'utf8'));
  lock.packages['node_modules/sqlite3'].dependencies = { 'node-addon-api': '^7.0.0' };
  lock.packages['node_modules/node-addon-api'] = {
    resolved: 'https://registry.npmjs.org/node-addon-api/-/node-addon-api-7.1.0.tgz',
    integrity: VALID_INTEGRITY
  };
  fs.writeFileSync(lockPath, JSON.stringify(lock));
  const report = checkDependencyLockfile({ rootDir });
  assert.ok(report.blockers.includes('LOCK_ENTRY_VERSION_INVALID:node_modules/node-addon-api'));
  assert.equal(report.installAllowed, false);
});

test('lock entry package identity must agree with its node_modules path', () => {
  const rootDir = fixture();
  const lockPath = path.join(rootDir, 'package-lock.json');
  const lock = JSON.parse(fs.readFileSync(lockPath, 'utf8'));
  lock.packages['node_modules/sqlite3'].name = 'not-sqlite3';
  fs.writeFileSync(lockPath, JSON.stringify(lock));
  const report = checkDependencyLockfile({ rootDir });
  assert.ok(report.blockers.includes('LOCK_ENTRY_PACKAGE_NAME_MISMATCH:node_modules/sqlite3'));
  assert.equal(report.installAllowed, false);
});

test('scoped package identity is parsed as a complete scope/name pair', () => {
  const { expectedPackageNameFromKey } = require('../../app/dependency-lockfile-preflight');
  assert.equal(expectedPackageNameFromKey('node_modules/@scope/pkg'), '@scope/pkg');
  assert.equal(expectedPackageNameFromKey('node_modules/parent/node_modules/@scope/pkg'), '@scope/pkg');
  assert.equal(expectedPackageNameFromKey('node_modules/@scope'), null);
});


test('package lock keys reject traversal, backslashes, empty segments, and non-canonical paths', () => {
  const { parseCanonicalPackageKey } = require('../../app/dependency-lockfile-preflight');
  for (const key of [
    'node_modules/../sqlite3',
    'node_modules/foo/../../bar',
    'node_modules//sqlite3',
    'node_modules/foo/bar',
    'node_modules/foo\\node_modules\\bar',
    'node_modules/.hidden',
    'node_modules/@scope',
    'node_modules/@scope/',
    'node_modules/@scope/../pkg',
    'node_modules/foo/node_modules'
  ]) assert.equal(parseCanonicalPackageKey(key), null, key);
});

test('canonical nested and scoped package lock keys resolve to their complete package identity', () => {
  const { parseCanonicalPackageKey } = require('../../app/dependency-lockfile-preflight');
  assert.equal(parseCanonicalPackageKey('node_modules/sqlite3'), 'sqlite3');
  assert.equal(parseCanonicalPackageKey('node_modules/@scope/pkg'), '@scope/pkg');
  assert.equal(parseCanonicalPackageKey('node_modules/parent/node_modules/@scope/pkg'), '@scope/pkg');
  assert.equal(parseCanonicalPackageKey('node_modules/@scope/parent/node_modules/child'), 'child');
});

test('non-canonical lockfile package keys block dependency installation', () => {
  const rootDir = fixture();
  const lockPath = path.join(rootDir, 'package-lock.json');
  const lock = JSON.parse(fs.readFileSync(lockPath, 'utf8'));
  lock.packages['node_modules/../sqlite3'] = { version: '5.1.7', resolved: 'https://registry.npmjs.org/sqlite3/-/sqlite3-5.1.7.tgz', integrity: VALID_INTEGRITY };
  fs.writeFileSync(lockPath, JSON.stringify(lock));
  const report = checkDependencyLockfile({ rootDir });
  assert.ok(report.blockers.includes('LOCK_PACKAGE_KEY_NON_CANONICAL:node_modules/../sqlite3'));
  assert.equal(report.installAllowed, false);
});

test('non-canonical package keys are rejected by the exported graph validator', () => {
  const { validateDependencyGraph } = require('../../app/dependency-lockfile-preflight');
  const blockers = validateDependencyGraph({
    'node_modules/../../escape': { version: '1.0.0' }
  });
  assert.ok(blockers.includes('LOCK_PACKAGE_KEY_NON_CANONICAL:node_modules/../../escape'));
});

test('lifecycle install scripts block unless an exact reviewed policy entry exists', () => {
  const rootDir = fixture();
  const lockPath = path.join(rootDir, 'package-lock.json');
  const lock = JSON.parse(fs.readFileSync(lockPath, 'utf8'));
  lock.packages['node_modules/sqlite3'].hasInstallScript = true;
  fs.writeFileSync(lockPath, JSON.stringify(lock));
  const report = checkDependencyLockfile({ rootDir });
  assert.ok(report.blockers.includes('INSTALL_SCRIPT_NOT_APPROVED:node_modules/sqlite3'));
  assert.equal(report.installAllowed, false);
});

test('locked transitive package version must satisfy its declared semver range', () => {
  const rootDir = fixture();
  const lockPath = path.join(rootDir, 'package-lock.json');
  const lock = JSON.parse(fs.readFileSync(lockPath, 'utf8'));
  lock.packages['node_modules/sqlite3'].dependencies = { 'node-addon-api': '^7.0.0' };
  lock.packages['node_modules/node-addon-api'] = {
    version: '8.0.0',
    resolved: 'https://registry.npmjs.org/node-addon-api/-/node-addon-api-8.0.0.tgz',
    integrity: VALID_INTEGRITY
  };
  fs.writeFileSync(lockPath, JSON.stringify(lock));
  const report = checkDependencyLockfile({ rootDir });
  assert.ok(report.blockers.includes('LOCK_DEPENDENCY_VERSION_OUT_OF_RANGE:node_modules/sqlite3:node-addon-api:node_modules/node-addon-api'));
  assert.equal(report.installAllowed, false);
});

test('supported semver range forms accept in-range locked versions', () => {
  const { versionSatisfiesSpec } = require('../../app/dependency-lockfile-preflight');
  assert.equal(versionSatisfiesSpec('7.1.0', '^7.0.0'), true);
  assert.equal(versionSatisfiesSpec('7.9.9', '~7.9.0'), true);
  assert.equal(versionSatisfiesSpec('8.0.0', '>=7.0.0 <9.0.0'), true);
  assert.equal(versionSatisfiesSpec('2.4.1', '1.2.3 || ^2.0.0'), true);
  assert.equal(versionSatisfiesSpec('7.1.0', '^8.0.0'), false);
});

test('unsupported semver range syntax fails closed instead of being assumed valid', () => {
  const { versionSatisfiesSpec } = require('../../app/dependency-lockfile-preflight');
  assert.equal(versionSatisfiesSpec('7.1.0', 'git+https://example.invalid/repo.git'), null);
});


test('prerelease dependency pins fail closed until full npm-semver semantics are available', () => {
  const { versionSatisfiesSpec } = require('../../app/dependency-lockfile-preflight');
  // These pairs would be mishandled by a simplistic lexical prerelease comparison.
  assert.equal(versionSatisfiesSpec('1.0.0-alpha.10', '>=1.0.0-alpha.2'), null);
  assert.equal(versionSatisfiesSpec('1.0.0-alpha.2', '1.0.0-alpha.10'), null);
  assert.equal(versionSatisfiesSpec('1.0.0', '>=1.0.0-alpha.1'), null);
});


test('SemVer build metadata requires non-empty canonical identifiers', () => {
  const { EXACT_VERSION, versionSatisfiesSpec } = require('../../app/dependency-lockfile-preflight');
  assert.equal(EXACT_VERSION.test('1.2.3+build.17'), true);
  for (const version of ['1.2.3+', '1.2.3+..', '1.2.3+.build', '1.2.3+build.', '1.2.3+build..17']) {
    assert.equal(EXACT_VERSION.test(version), false, version);
  }
  assert.equal(versionSatisfiesSpec('1.2.3+build.17', '1.2.3+other.4'), true);
});

test('malformed prerelease identifiers fail closed instead of being parsed as SemVer', () => {
  const { versionSatisfiesSpec } = require('../../app/dependency-lockfile-preflight');
  assert.equal(versionSatisfiesSpec('1.2.3', '>=1.2.3-alpha..1'), null);
  assert.equal(versionSatisfiesSpec('1.2.3', '>=1.2.3-01'), null);
  assert.equal(versionSatisfiesSpec('1.2.3', '>=1.2.3-alpha+'), null);
});

test('non-canonical and prerelease direct dependency pins are rejected', () => {
  for (const version of ['01.0.0', '1.0.0-alpha.1']) {
    const rootDir = fixture({ version, rootVersion: version });
    const report = checkDependencyLockfile({ rootDir });
    assert.ok(report.blockers.includes('DIRECT_DEPENDENCY_NOT_EXACTLY_PINNED:sqlite3'), `${version}: ${report.blockers}`);
    assert.equal(report.installAllowed, false);
  }
});


test('unsafe SemVer core integers fail closed rather than being rounded by JavaScript Number', () => {
  const { isSafeExactVersion, versionSatisfiesSpec } = require('../../app/dependency-lockfile-preflight');
  assert.equal(isSafeExactVersion('9007199254740992.0.0'), false);
  assert.equal(isSafeExactVersion('1.9007199254740992.0'), false);
  assert.equal(isSafeExactVersion('1.0.9007199254740992'), false);
  assert.equal(isSafeExactVersion('9007199254740991.0.0'), true);
  assert.equal(versionSatisfiesSpec('9007199254740992.0.0', '^9007199254740991.0.0'), null);
});

test('direct dependency pins with unsafe SemVer integers are rejected', () => {
  const version = '9007199254740992.0.0';
  const rootDir = fixture({ version, rootVersion: version });
  const report = checkDependencyLockfile({ rootDir });
  assert.ok(report.blockers.includes('DIRECT_DEPENDENCY_NOT_EXACTLY_PINNED:sqlite3'));
  assert.equal(report.installAllowed, false);
});



test('preflight rejects a symlinked candidate root directory', t => {
  const rootDir = fixture();
  const parentDir = path.dirname(rootDir);
  const realDir = `${rootDir}-real`;
  fs.renameSync(rootDir, realDir);
  try { fs.symlinkSync(realDir, rootDir, 'dir'); }
  catch (error) { t.skip(`directory symlinks unavailable: ${error.code}`); fs.rmSync(realDir, { recursive: true, force: true }); return; }
  t.after(() => { fs.rmSync(rootDir, { recursive: true, force: true }); fs.rmSync(realDir, { recursive: true, force: true }); });
  const report = checkDependencyLockfile({ rootDir });
  assert.deepEqual(report.blockers, ['ROOT_DIRECTORY_PATH_UNSAFE']);
  assert.equal(report.installAllowed, false);
});

test('preflight rejects a symlinked config directory', t => {
  const rootDir = fixture();
  const configPath = path.join(rootDir, 'config');
  const realConfigPath = path.join(rootDir, 'config-real');
  fs.renameSync(configPath, realConfigPath);
  try { fs.symlinkSync(realConfigPath, configPath, 'dir'); }
  catch (error) { t.skip(`directory symlinks unavailable: ${error.code}`); fs.rmSync(rootDir, { recursive: true, force: true }); return; }
  t.after(() => fs.rmSync(rootDir, { recursive: true, force: true }));
  const report = checkDependencyLockfile({ rootDir });
  assert.ok(report.blockers.includes('INSTALL_SCRIPT_POLICY_DIRECTORY_UNSAFE'));
  assert.equal(report.installAllowed, false);
});

test('preflight blocks package.json symlink before parsing its target', t => {
  const rootDir = fixture();
  const target = path.join(rootDir, 'package-real.json');
  fs.renameSync(path.join(rootDir, 'package.json'), target);
  try { fs.symlinkSync(target, path.join(rootDir, 'package.json')); }
  catch (error) { t.skip(`file symlinks unavailable: ${error.code}`); fs.rmSync(rootDir, { recursive: true, force: true }); return; }
  t.after(() => fs.rmSync(rootDir, { recursive: true, force: true }));
  const report = checkDependencyLockfile({ rootDir });
  assert.deepEqual(report.blockers, ['PACKAGE_JSON_PATH_UNSAFE']);
  assert.equal(report.installAllowed, false);
});

test('preflight blocks package-lock.json symlink before parsing its target', t => {
  const rootDir = fixture();
  const target = path.join(rootDir, 'package-lock-real.json');
  fs.renameSync(path.join(rootDir, 'package-lock.json'), target);
  try { fs.symlinkSync(target, path.join(rootDir, 'package-lock.json')); }
  catch (error) { t.skip(`file symlinks unavailable: ${error.code}`); fs.rmSync(rootDir, { recursive: true, force: true }); return; }
  t.after(() => fs.rmSync(rootDir, { recursive: true, force: true }));
  const report = checkDependencyLockfile({ rootDir });
  assert.ok(report.blockers.includes('PACKAGE_LOCK_PATH_UNSAFE'));
  assert.equal(report.installAllowed, false);
});

test('preflight blocks install-script policy symlink instead of following it', t => {
  const rootDir = fixture();
  const policyPath = path.join(rootDir, 'config', 'dependency-install-script-policy.json');
  const target = path.join(rootDir, 'config', 'policy-real.json');
  fs.renameSync(policyPath, target);
  try { fs.symlinkSync(target, policyPath); }
  catch (error) { t.skip(`file symlinks unavailable: ${error.code}`); fs.rmSync(rootDir, { recursive: true, force: true }); return; }
  t.after(() => fs.rmSync(rootDir, { recursive: true, force: true }));
  const report = checkDependencyLockfile({ rootDir });
  assert.ok(report.blockers.includes('INSTALL_SCRIPT_POLICY_PATH_UNSAFE'));
  assert.equal(report.installAllowed, false);
});
