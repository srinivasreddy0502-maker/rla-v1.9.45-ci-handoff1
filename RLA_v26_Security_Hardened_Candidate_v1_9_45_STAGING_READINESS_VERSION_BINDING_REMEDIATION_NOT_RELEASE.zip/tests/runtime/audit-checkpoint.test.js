'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const { appendEvidenceRecord } = require('../../app/audit-evidence-chain');
const { createAuditCheckpoint, verifyAuditCheckpoint } = require('../../app/audit-evidence-checkpoint');
const KEY = 'test-only-checkpoint-key-keep-out-of-production-2026';
async function fixture(t) {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'rla-checkpoint-'));
  await fs.chmod(root, 0o700);
  const recordsDir = path.join(root, 'records');
  const evidenceRoot = path.join(root, 'evidence');
  await fs.mkdir(recordsDir, { mode: 0o700 });
  await fs.mkdir(evidenceRoot, { mode: 0o700 });
  await fs.writeFile(path.join(evidenceRoot, 'event.json'), '{"event":"test"}\n', { mode: 0o600 });
  await appendEvidenceRecord({ recordsDir, evidenceRoot, evidenceNames: ['event.json'], key: KEY,
    actorId: 'test-operator', eventType: 'TEST_EVENT', changeRef: 'TEST-100',
    now: new Date('2026-10-12T12:00:00.000Z') });
  const checkpointPath = path.join(root, 'checkpoint.json');
  t.after(() => fs.rm(root, { recursive: true, force: true }));
  return { root, recordsDir, evidenceRoot, checkpointPath };
}
test('creates a signed checkpoint and verifies unchanged chain', async t => {
  const f = await fixture(t);
  const created = await createAuditCheckpoint({ recordsDir: f.recordsDir, checkpointPath: f.checkpointPath, key: KEY, now: new Date('2026-10-12T12:30:00.000Z') });
  assert.equal(created.recordCount, 1);
  assert.equal((await verifyAuditCheckpoint({ recordsDir: f.recordsDir, checkpointPath: f.checkpointPath, key: KEY })).valid, true);
  if (process.platform !== 'win32') assert.equal((await fs.stat(f.checkpointPath)).mode & 0o777, 0o600);
});
test('rejects overwrite of an existing checkpoint', async t => {
  const f = await fixture(t);
  await createAuditCheckpoint({ recordsDir: f.recordsDir, checkpointPath: f.checkpointPath, key: KEY });
  await assert.rejects(createAuditCheckpoint({ recordsDir: f.recordsDir, checkpointPath: f.checkpointPath, key: KEY }), /EEXIST|already exists/);
});
test('detects chain changes after checkpoint creation', async t => {
  const f = await fixture(t);
  await createAuditCheckpoint({ recordsDir: f.recordsDir, checkpointPath: f.checkpointPath, key: KEY });
  await appendEvidenceRecord({ recordsDir: f.recordsDir, evidenceRoot: f.evidenceRoot, evidenceNames: ['event.json'], key: KEY,
    actorId: 'test-operator', eventType: 'SECOND_EVENT', changeRef: 'TEST-101' });
  await assert.rejects(verifyAuditCheckpoint({ recordsDir: f.recordsDir, checkpointPath: f.checkpointPath, key: KEY }), /does not match signed checkpoint/);
});
test('rejects tampered checkpoint HMAC', async t => {
  const f = await fixture(t);
  await createAuditCheckpoint({ recordsDir: f.recordsDir, checkpointPath: f.checkpointPath, key: KEY });
  const data = JSON.parse(await fs.readFile(f.checkpointPath, 'utf8'));
  data.recordCount = 99;
  await fs.writeFile(f.checkpointPath, JSON.stringify(data));
  await assert.rejects(verifyAuditCheckpoint({ recordsDir: f.recordsDir, checkpointPath: f.checkpointPath, key: KEY }), /HMAC verification failed/);
});
test('rejects wrong key', async t => {
  const f = await fixture(t);
  await createAuditCheckpoint({ recordsDir: f.recordsDir, checkpointPath: f.checkpointPath, key: KEY });
  await assert.rejects(verifyAuditCheckpoint({ recordsDir: f.recordsDir, checkpointPath: f.checkpointPath, key: 'wrong-key-at-least-32-bytes-xxxxxxxx' }), /HMAC verification failed/);
});
test('refuses a symlink checkpoint', async t => {
  const f = await fixture(t);
  await createAuditCheckpoint({ recordsDir: f.recordsDir, checkpointPath: f.checkpointPath, key: KEY });
  const link = path.join(f.root, 'checkpoint-link.json');
  await fs.symlink(f.checkpointPath, link);
  await assert.rejects(verifyAuditCheckpoint({ recordsDir: f.recordsDir, checkpointPath: link, key: KEY }), /regular non-symlink/);
});
test('refuses public checkpoint directory on POSIX', async t => {
  const f = await fixture(t);
  if (process.platform === 'win32') return;
  const publicDir = path.join(f.root, 'public');
  await fs.mkdir(publicDir, { mode: 0o755 });
  await assert.rejects(createAuditCheckpoint({ recordsDir: f.recordsDir, checkpointPath: path.join(publicDir, 'checkpoint.json'), key: KEY }), /must be private/);
});
