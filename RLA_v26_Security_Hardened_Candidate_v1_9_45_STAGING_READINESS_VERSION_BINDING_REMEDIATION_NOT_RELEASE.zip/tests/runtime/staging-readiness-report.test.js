'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { BLOCKERS, MAX_DIAGNOSTIC_CHARS, buildStagingReadinessReport } = require('../../app/staging-readiness-report');
const at = '2026-10-12T10:00:00.000Z';
const good = { status: 'DRIVER_SMOKE_PASS', nativeDriver: true, npmPackage: 'sqlite3', packageVersion: '5.1.7', nodeVersion: 'v22.16.0', nodeModuleAbi: '127', platform: 'linux', architecture: 'x64', sqliteLibraryVersion: '3.50.0', databaseBackupApi: true };
function make(overrides = {}) { return buildStagingReadinessReport({ exitCode: 0, stdout: JSON.stringify(good), stderr: '', generatedAt: at, ...overrides }); }

test('readiness report binds its candidate version to current package metadata', () => {
  const r = make();
  assert.equal(r.candidateVersion, require('../../package.json').version);
  assert.notEqual(r.candidateVersion, '1.9.5-candidate');
  assert.equal(r.releaseAuthorityGranted, false);
});

test('native driver smoke pass still cannot grant release authority', () => {
  const r = make();
  assert.equal(r.preflightStatus, 'DRIVER_SMOKE_PASS');
  assert.equal(r.releaseStatus, 'RELEASE_BLOCKED');
  assert.equal(r.releaseAuthorityGranted, false);
  assert.equal(r.productionUseAuthorized, false);
  assert.equal(r.realFileBackupRestore, 'NOT_VERIFIED');
  assert.ok(BLOCKERS.every(x => r.requiredFollowUp.includes(x)));
});
test('nonzero preflight exit blocks even when stdout claims smoke pass', () => {
  const r = make({ exitCode: 2 });
  assert.equal(r.preflightStatus, 'BLOCKED');
  assert.ok(r.requiredFollowUp.includes('NATIVE_SQLITE_DRIVER_SMOKE_NOT_PASSED'));
});
test('missing native backup API blocks smoke pass', () => {
  const r = make({ stdout: JSON.stringify({ ...good, databaseBackupApi: false }) });
  assert.equal(r.preflightStatus, 'BLOCKED');
});
test('malformed or non-object stdout is captured as blocked evidence', () => {
  for (const stdout of ['not-json', 'null', '[]']) {
    const r = make({ exitCode: 2, stdout, stderr: 'preflight unavailable' });
    assert.equal(r.preflightStatus, 'BLOCKED');
    assert.equal(r.releaseAuthorityGranted, false);
    assert.ok(r.diagnostic.length > 0);
  }
});

test('native preflight JSON written to stderr is parsed and its blocker is preserved', () => {
  const r = make({ exitCode: 2, stdout: '', stderr: JSON.stringify({ status: 'BLOCKED', code: 'NATIVE_SQLITE3_DRIVER_UNAVAILABLE', message: 'sqlite3 missing', nativeDriver: false }) });
  assert.equal(r.preflightStatus, 'BLOCKED');
  assert.equal(r.preflight.code, 'NATIVE_SQLITE3_DRIVER_UNAVAILABLE');
  assert.equal(r.diagnostic, 'sqlite3 missing');
});

test('diagnostic text is bounded and control characters are removed', () => {
  const r = make({ exitCode: 2, stdout: '', stderr: 'x\u0000'.repeat(MAX_DIAGNOSTIC_CHARS * 2) });
  assert.ok(r.diagnostic.length <= MAX_DIAGNOSTIC_CHARS);
  assert.ok(!r.diagnostic.includes('\u0000'));
});
test('invalid timestamps and input types are rejected', () => {
  assert.throws(() => make({ generatedAt: 'not-a-date' }), /canonical UTC ISO timestamp/);
  assert.throws(() => buildStagingReadinessReport({ exitCode: '0', stdout: '{}', stderr: '', generatedAt: at }), /exitCode must be an integer/);
  assert.throws(() => buildStagingReadinessReport({ exitCode: 0, stdout: Buffer.from('{}'), stderr: '', generatedAt: at }), /stdout and stderr must be strings/);
});
