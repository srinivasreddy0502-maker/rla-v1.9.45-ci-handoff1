'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { assertIntegrityCheckRow } = require('../../scripts/native-sqlite-preflight');

test('native SQLite preflight accepts only integrity_check=ok', () => {
  assert.equal(assertIntegrityCheckRow({ integrity_check: 'ok' }), 'ok');
});

test('native SQLite preflight blocks integrity_check error rows', () => {
  assert.throws(() => assertIntegrityCheckRow({ integrity_check: 'database disk image is malformed' }), /did not return ok/);
});

test('native SQLite preflight blocks missing or malformed integrity rows', () => {
  for (const row of [null, undefined, {}, { integrity_check: null }, { integrity_check: ['ok'] }]) {
    assert.throws(() => assertIntegrityCheckRow(row), /did not return ok/);
  }
});
