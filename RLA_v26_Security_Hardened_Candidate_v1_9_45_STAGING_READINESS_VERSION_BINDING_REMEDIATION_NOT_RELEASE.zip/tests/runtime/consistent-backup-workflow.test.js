'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const { createConsistentBackup } = require('../../scripts/create-consistent-backup');
const { verifyManifest } = require('../../app/backup-manifest');

const KEY = 'test-only-consistent-backup-key-minimum-32-bytes';

function fakeSqlite3({ failBackup = false } = {}) {
  return {
    OPEN_READONLY: 1,
    Database: class {
      constructor(source, flags, callback) { this.source = source; setImmediate(() => callback(null)); }
      backup(destination, callback) {
        setImmediate(async () => {
          if (failBackup) return callback(new Error('injected online backup failure'));
          try { await fs.writeFile(destination, 'test-only-sqlite-backup-payload'); callback(null); }
          catch (error) { callback(error); }
        });
      }
      close(callback) { setImmediate(() => callback(null)); }
    }
  };
}

async function fixture(t) {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'rla-consistent-backup-'));
  await fs.chmod(root, 0o700);
  t.after(() => fs.rm(root, { recursive: true, force: true }));
  const source = path.join(root, 'live.sqlite');
  const backup = path.join(root, 'nightly.sqlite');
  const manifest = path.join(root, 'nightly.manifest.json');
  await fs.writeFile(source, 'source-db-placeholder');
  return { root, source, backup, manifest, sourcePath: source, backupPath: backup, manifestPath: manifest };
}

test('consistent backup uses online-backup adapter, writes manifest, and verifies artifact', async t => {
  const f = await fixture(t);
  const result = await createConsistentBackup({ ...f, key: KEY, sqlite3: fakeSqlite3() });
  assert.equal(result.ok, true);
  assert.equal(result.method, 'sqlite3-online-backup-api');
  assert.equal(result.manifestVerified, true);
  assert.equal((await verifyManifest(f.backup, f.manifest, KEY)).sha256, result.sha256);
  assert.equal((await fs.stat(f.backup)).mode & 0o777, 0o600);
});

test('refuses to overwrite existing backup or manifest artifacts', async t => {
  const f = await fixture(t);
  await fs.writeFile(f.backup, 'keep-me');
  await assert.rejects(() => createConsistentBackup({ ...f, key: KEY, sqlite3: fakeSqlite3() }), /Backup destination already exists/);
  assert.equal(await fs.readFile(f.backup, 'utf8'), 'keep-me');
});

test('failed SQLite backup leaves no final backup or manifest', async t => {
  const f = await fixture(t);
  await assert.rejects(() => createConsistentBackup({ ...f, key: KEY, sqlite3: fakeSqlite3({ failBackup: true }) }), /injected online backup failure/);
  await assert.rejects(() => fs.lstat(f.backup), { code: 'ENOENT' });
  await assert.rejects(() => fs.lstat(f.manifest), { code: 'ENOENT' });
  const files = await fs.readdir(f.root);
  assert.deepEqual(files.sort(), ['live.sqlite']);
});

test('rejects missing/weak key and non-regular source', async t => {
  const f = await fixture(t);
  await assert.rejects(() => createConsistentBackup({ ...f, key: 'short', sqlite3: fakeSqlite3() }), /at least 32/);
  const link = path.join(f.root, 'source-link.sqlite');
  await fs.symlink(f.source, link);
  await assert.rejects(() => createConsistentBackup({ sourcePath: link, backupPath: f.backup, manifestPath: f.manifest, key: KEY, sqlite3: fakeSqlite3() }), /symbolic link/);
});

test('rejects overlapping source, backup, and manifest paths', async t => {
  const f = await fixture(t);
  await assert.rejects(() => createConsistentBackup({ sourcePath: f.source, backupPath: f.source, manifestPath: f.manifest, key: KEY, sqlite3: fakeSqlite3() }), /distinct paths/);
});
