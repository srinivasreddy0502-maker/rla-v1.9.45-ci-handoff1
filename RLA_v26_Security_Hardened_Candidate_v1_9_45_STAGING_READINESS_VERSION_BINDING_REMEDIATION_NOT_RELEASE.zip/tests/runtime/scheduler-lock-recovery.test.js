'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const { acquireSchedulerLock, releaseSchedulerLock } = require('../../app/scheduler-lock');
const { REQUIRED_ATTESTATIONS, createSchedulerRecoveryAuthorization, verifySchedulerRecoveryAuthorization } = require('../../app/scheduler-lock-recovery');
const KEY = 'unit-test-only-key-do-not-use-in-production-123456789';
const attestations = Object.fromEntries(REQUIRED_ATTESTATIONS.map(name => [name, true]));
async function fixture(t) {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'rla-lock-recovery-'));
  await fs.chmod(root, 0o700);
  t.after(() => fs.rm(root, { recursive: true, force: true }));
  return root;
}
async function recordFor(lockPath, overrides = {}) {
  return createSchedulerRecoveryAuthorization({
    lockPath, operatorId: 'operator-17', approverId: 'approver-42', incidentRef: 'CHG-2026-1042',
    reason: 'Controlled recovery after service shutdown and backup verification', attestations,
    key: KEY, processExists: async () => false, now: new Date('2026-10-12T12:00:00.000Z'), ...overrides
  });
}
test('creates authenticated authorization with dual control and no deletion permission', async t => {
  const root = await fixture(t); const lock = await acquireSchedulerLock(path.join(root, 'backup.lock'));
  const record = await recordFor(lock.lockPath);
  assert.equal(verifySchedulerRecoveryAuthorization(record, KEY).valid, true);
  assert.equal(record.automaticCleanup, false);
  assert.equal(record.permittedAction, 'manual-review-only-no-automatic-lock-removal');
  assert.notEqual(record.operatorId, record.independentApproverId);
  await releaseSchedulerLock(lock);
});
test('rejects same operator and approver', async t => {
  const root = await fixture(t); const lock = await acquireSchedulerLock(path.join(root, 'backup.lock'));
  await assert.rejects(recordFor(lock.lockPath, { approverId: 'operator-17' }), /different people/);
  await releaseSchedulerLock(lock);
});
test('rejects missing recovery attestations', async t => {
  const root = await fixture(t); const lock = await acquireSchedulerLock(path.join(root, 'backup.lock'));
  await assert.rejects(recordFor(lock.lockPath, { attestations: { ...attestations, allWritersStopped: false } }), /All required recovery attestations/);
  await releaseSchedulerLock(lock);
});
test('tampered authorization record fails HMAC verification', async t => {
  const root = await fixture(t); const lock = await acquireSchedulerLock(path.join(root, 'backup.lock'));
  const record = await recordFor(lock.lockPath); record.reason = 'changed after approval';
  assert.throws(() => verifySchedulerRecoveryAuthorization(record, KEY), /HMAC verification failed/);
  await releaseSchedulerLock(lock);
});
test('wrong key fails verification and lock remains present', async t => {
  const root = await fixture(t); const lock = await acquireSchedulerLock(path.join(root, 'backup.lock'));
  const record = await recordFor(lock.lockPath);
  assert.throws(() => verifySchedulerRecoveryAuthorization(record, 'another-test-key-that-is-long-enough-123456789'), /HMAC verification failed/);
  assert.equal((await fs.stat(lock.lockPath)).isDirectory(), true);
  await releaseSchedulerLock(lock);
});
test('rejects malformed incident reference', async t => {
  const root = await fixture(t); const lock = await acquireSchedulerLock(path.join(root, 'backup.lock'));
  await assert.rejects(recordFor(lock.lockPath, { incidentRef: 'bad ref with spaces' }), /safe characters/);
  await releaseSchedulerLock(lock);
});
