'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { MAX_EVIDENCE_BYTES, readEvidenceFileNoFollow, validateStagingEvidenceIntake } = require('../../app/staging-evidence-intake');

const at = '2026-10-13T06:00:00.000Z';
function completeEvidence() {
  return {
    schemaVersion: 1, candidateVersion: require('../../package.json').version, generatedAt: at,
    staging: { approved: true, isolated: true, environmentId: 'synthetic-staging-01' },
    dependencyLockfile: { present: true, sha256: 'a'.repeat(64), generatedInApprovedStaging: true, dependencyReviewStatus: 'PASS', provenanceReviewed: true },
    nativeSqlite: { smokeTestStatus: 'PASS', driverVersion: '5.1.7', nodeVersion: 'v22.16.0', platform: 'linux', architecture: 'x64' },
    recovery: { backupRestore: 'PASS', integrityCheck: 'PASS', foreignKeyCheck: 'PASS', walCrashRecovery: 'PASS', cleanHostRestore: 'PASS' },
    assurance: { independentSecurityReview: 'PASS', authorizedPenetrationTest: 'PASS', uat: 'PASS', auditEvidenceReview: 'PASS', formalGovernanceApproval: 'PASS' },
    evidenceReferences: [{ id: 'synthetic-report-01', sha256: 'b'.repeat(64), capturedAt: at, reviewerId: 'reviewer-test' }]
  };
}
function tempDir(t) { const d = fs.mkdtempSync(path.join(os.tmpdir(), 'rla-evidence-intake-')); t.after(() => fs.rmSync(d, { recursive: true, force: true })); return d; }

test('complete evidence can only reach intake-complete; it never grants release authority', () => {
  const report = validateStagingEvidenceIntake(completeEvidence());
  assert.equal(report.intakeStatus, 'EVIDENCE_COMPLETE_PENDING_INDEPENDENT_VERIFICATION');
  assert.equal(report.releaseStatus, 'RELEASE_BLOCKED');
  assert.equal(report.releaseAuthorityGranted, false);
  assert.equal(report.productionUseAuthorized, false);
});

test('missing lockfile provenance and recovery proof are explicit blockers', () => {
  const input = completeEvidence();
  input.dependencyLockfile.provenanceReviewed = false;
  input.recovery.cleanHostRestore = 'NOT_RUN';
  const report = validateStagingEvidenceIntake(input);
  assert.equal(report.intakeStatus, 'BLOCKED');
  assert.ok(report.blockers.includes('DEPENDENCY_LOCKFILE_EVIDENCE_INCOMPLETE'));
  assert.ok(report.blockers.includes('RECOVERY_CLEAN_HOST_RESTORE_NOT_PASSED'));
  assert.equal(report.productionUseAuthorized, false);
});

test('rejects wrong candidate version, invalid timestamp, and malformed evidence hash', () => {
  const input = completeEvidence();
  input.candidateVersion = '1.9.32-candidate';
  input.generatedAt = 'not-a-time';
  input.evidenceReferences[0].sha256 = 'xyz';
  const report = validateStagingEvidenceIntake(input);
  assert.ok(report.blockers.includes('CANDIDATE_VERSION_MISMATCH'));
  assert.ok(report.blockers.includes('GENERATED_AT_INVALID'));
  assert.ok(report.blockers.includes('EVIDENCE_REFERENCE_1_INVALID'));
});


test('rejects duplicate evidence IDs and references captured after the intake was generated', () => {
  const input = completeEvidence();
  input.evidenceReferences.push({ ...input.evidenceReferences[0], capturedAt: '2026-10-13T06:01:00.000Z' });
  const report = validateStagingEvidenceIntake(input);
  assert.ok(report.blockers.includes('EVIDENCE_REFERENCE_2_DUPLICATE_ID'));
  assert.ok(report.blockers.includes('EVIDENCE_REFERENCE_2_CAPTURED_AFTER_GENERATION'));
  assert.equal(report.releaseAuthorityGranted, false);
});

test('report digest binds the complete report fields', () => {
  const reportA = validateStagingEvidenceIntake(completeEvidence());
  const changed = completeEvidence();
  changed.evidenceReferences[0].id = 'synthetic-report-02';
  const reportB = validateStagingEvidenceIntake(changed);
  assert.notEqual(reportA.reportDigestSha256, reportB.reportDigestSha256);
  const { reportDigestSha256, ...withoutDigest } = reportA;
  const crypto = require('node:crypto');
  assert.equal(reportDigestSha256, crypto.createHash('sha256').update(JSON.stringify(withoutDigest)).digest('hex'));
});

test('rejects non-object evidence roots', () => {
  assert.deepEqual(validateStagingEvidenceIntake([]).blockers, ['EVIDENCE_ROOT_NOT_OBJECT']);
  assert.equal(validateStagingEvidenceIntake(null).releaseStatus, 'RELEASE_BLOCKED');
});

test('secure reader reads a private regular evidence file', t => {
  const dir = tempDir(t); const file = path.join(dir, 'evidence.json');
  fs.writeFileSync(file, JSON.stringify(completeEvidence()), { mode: 0o600 }); fs.chmodSync(file, 0o600);
  assert.equal(JSON.parse(readEvidenceFileNoFollow(file)).candidateVersion, require('../../package.json').version);
});

test('secure reader rejects symbolic links and hard links', t => {
  const dir = tempDir(t); const file = path.join(dir, 'evidence.json');
  fs.writeFileSync(file, '{}', { mode: 0o600 }); fs.chmodSync(file, 0o600);
  const sym = path.join(dir, 'evidence-link.json'); fs.symlinkSync(file, sym);
  assert.throws(() => readEvidenceFileNoFollow(sym));
  const hard = path.join(dir, 'evidence-hardlink.json'); fs.linkSync(file, hard);
  assert.throws(() => readEvidenceFileNoFollow(file), /hard link/i);
});

test('secure reader rejects writable modes and oversized files', t => {
  const dir = tempDir(t); const writable = path.join(dir, 'writable.json');
  fs.writeFileSync(writable, '{}', { mode: 0o600 }); fs.chmodSync(writable, 0o622);
  assert.throws(() => readEvidenceFileNoFollow(writable), /writable/i);
  const large = path.join(dir, 'large.json');
  fs.writeFileSync(large, Buffer.alloc(MAX_EVIDENCE_BYTES + 1, 0x20), { mode: 0o600 }); fs.chmodSync(large, 0o600);
  assert.throws(() => readEvidenceFileNoFollow(large), /size/i);
});


test('rejects unknown fields at root and in nested evidence objects', () => {
  const rootExtra = completeEvidence();
  rootExtra.releaseApproved = true;
  const rootReport = validateStagingEvidenceIntake(rootExtra);
  assert.ok(rootReport.blockers.includes('UNEXPECTED_FIELD_ROOT:releaseApproved'));
  assert.equal(rootReport.releaseAuthorityGranted, false);

  const nestedExtra = completeEvidence();
  nestedExtra.dependencyLockfile.trustedByAI = true;
  const nestedReport = validateStagingEvidenceIntake(nestedExtra);
  assert.ok(nestedReport.blockers.includes('UNEXPECTED_FIELD_DEPENDENCY_LOCKFILE:trustedByAI'));
});

test('secure reader rejects malformed UTF-8 bytes explicitly', t => {
  const dir = tempDir(t); const file = path.join(dir, 'invalid-utf8.json');
  fs.writeFileSync(file, Buffer.from([0x7b, 0x22, 0x78, 0x22, 0x3a, 0x22, 0xc3, 0x28, 0x22, 0x7d]));
  fs.chmodSync(file, 0o600);
  assert.throws(() => readEvidenceFileNoFollow(file), error => error.code === 'EVIDENCE_UTF8_INVALID');
});


test('rejects duplicate evidence hashes even when IDs differ or hash case differs', () => {
  const input = completeEvidence();
  input.evidenceReferences.push({
    id: 'synthetic-report-02',
    sha256: 'B'.repeat(64),
    capturedAt: at,
    reviewerId: 'reviewer-test-2'
  });
  const report = validateStagingEvidenceIntake(input);
  assert.ok(report.blockers.includes('EVIDENCE_REFERENCE_2_DUPLICATE_SHA256'));
  assert.equal(report.intakeStatus, 'BLOCKED');
  assert.equal(report.releaseAuthorityGranted, false);
  assert.equal(report.productionUseAuthorized, false);
});
