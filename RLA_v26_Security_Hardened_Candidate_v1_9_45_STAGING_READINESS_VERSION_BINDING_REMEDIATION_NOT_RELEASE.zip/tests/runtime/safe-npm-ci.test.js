'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const fs = require('node:fs');
const os = require('node:os');
const { spawnSync } = require('node:child_process');
const { buildSafeNpmCiArgs, buildSafeNpmEnvironment, evaluateSafeInstall, resolveSafeInstallConfig } = require('../../app/safe-npm-ci');

const rootDir = path.resolve(__dirname, '../..');

test('safe npm ci always suppresses lifecycle scripts and audit network side effects', () => {
  assert.deepEqual(buildSafeNpmCiArgs(), ['ci', '--ignore-scripts', '--no-audit', '--no-fund']);
});
test('safe install preflight fails closed when lockfile is absent', () => {
  const report = evaluateSafeInstall({ rootDir, approvedHosts: ['registry.npmjs.org'] });
  assert.equal(report.status, 'BLOCKED');
  assert.equal(report.installAllowed, false);
  assert.ok(report.blockers.includes('PACKAGE_LOCK_JSON_MISSING'));
  assert.equal(report.lifecycleScriptsSuppressed, true);
  assert.equal(report.nativeBuildReady, false);
  assert.equal(report.productionUseAuthorized, false);
});
test('invalid approved registry configuration blocks before invoking npm', () => {
  const report = resolveSafeInstallConfig(rootDir, 'https://evil.example/path');
  assert.equal(report.status, 'BLOCKED');
  assert.deepEqual(report.blockers, ['APPROVED_REGISTRY_CONFIGURATION_INVALID']);
  assert.equal(report.installAllowed, false);
});
test('safe install report never implies native build or production readiness', () => {
  const report = evaluateSafeInstall({ rootDir, approvedHosts: ['registry.npmjs.org'] });
  assert.equal(report.nativeBuildReady, false);
  assert.equal(report.productionUseAuthorized, false);
  assert.match(report.nextStep, /FIX_PREFLIGHT_BLOCKERS/);
});
test('safe install command cannot be overridden with user supplied arguments', () => {
  assert.deepEqual(buildSafeNpmCiArgs(), ['ci', '--ignore-scripts', '--no-audit', '--no-fund']);
});
test('preflight result explicitly distinguishes lifecycle suppression from approval', () => {
  const report = evaluateSafeInstall({ rootDir, approvedHosts: ['registry.npmjs.org'] });
  assert.equal(report.lifecycleScriptsSuppressed, true);
  assert.equal(report.commandArgs.includes('--ignore-scripts'), true);
  assert.equal(report.nextStep, 'FIX_PREFLIGHT_BLOCKERS_BEFORE_INSTALL');
});


test('safe npm environment strips inherited registry and runtime injection overrides', () => {
  const env = buildSafeNpmEnvironment({
    PATH: '/usr/bin',
    npm_config_registry: 'https://evil.example/',
    NPM_CONFIG_USERCONFIG: '/tmp/attacker.npmrc',
    NODE_OPTIONS: '--require=/tmp/inject.js',
    NODE_PATH: '/tmp/injected-modules',
    NODE_TLS_REJECT_UNAUTHORIZED: '0',
    NODE_EXTRA_CA_CERTS: '/tmp/attacker-ca.pem',
    NODE_USE_ENV_PROXY: '1',
    npm_execpath: '/tmp/fake/npm-cli.js',
    RLA_APPROVED_NPM_REGISTRIES: 'registry.npmjs.org'
  }, ['registry.npmjs.org']);
  assert.equal(env.npm_config_registry, 'https://registry.npmjs.org/');
  assert.equal(env.npm_config_ignore_scripts, 'true');
  assert.equal(env.npm_config_audit, 'false');
  assert.equal(env.npm_config_fund, 'false');
  assert.equal(env.NODE_OPTIONS, undefined);
  assert.equal(env.NODE_PATH, undefined);
  assert.equal(env.NODE_TLS_REJECT_UNAUTHORIZED, undefined);
  assert.equal(env.NODE_EXTRA_CA_CERTS, undefined);
  assert.equal(env.NODE_USE_ENV_PROXY, undefined);
  assert.equal(env.npm_config_strict_ssl, 'true');
  assert.equal(env.npm_execpath, undefined);
  assert.equal(env.NPM_CONFIG_USERCONFIG, undefined);
  assert.equal(env.RLA_APPROVED_NPM_REGISTRIES, 'registry.npmjs.org');
});

test('safe npm environment requires an approved registry host', () => {
  assert.throws(() => buildSafeNpmEnvironment({ PATH: '/usr/bin' }, []), /required/);
});

test('safe install report exposes environment isolation without granting release authority', () => {
  const report = evaluateSafeInstall({ rootDir, approvedHosts: ['registry.npmjs.org'] });
  assert.equal(report.inheritedNpmConfigStripped, true);
  assert.equal(report.nodeRuntimeInjectionVariablesStripped, true);
  assert.equal(report.registryPinnedToApprovedHost, 'registry.npmjs.org');
  assert.equal(report.productionUseAuthorized, false);
  assert.equal(report.nativeBuildReady, false);
});


test('safe npm environment forces TLS verification and strips Node TLS bypass variables', () => {
  const env = buildSafeNpmEnvironment({
    PATH: '/usr/bin',
    NODE_TLS_REJECT_UNAUTHORIZED: '0',
    NODE_EXTRA_CA_CERTS: '/unreviewed/custom-ca.pem',
    NODE_USE_ENV_PROXY: '1',
    npm_config_strict_ssl: 'false'
  }, ['registry.npmjs.org']);
  assert.equal(env.NODE_TLS_REJECT_UNAUTHORIZED, undefined);
  assert.equal(env.NODE_EXTRA_CA_CERTS, undefined);
  assert.equal(env.NODE_USE_ENV_PROXY, undefined);
  assert.equal(env.npm_config_strict_ssl, 'true');
});

test('safe install report states TLS verification is enforced without granting release authority', () => {
  const report = evaluateSafeInstall({ rootDir, approvedHosts: ['registry.npmjs.org'] });
  assert.equal(report.tlsVerificationEnforced, true);
  assert.equal(report.nativeBuildReady, false);
  assert.equal(report.productionUseAuthorized, false);
});


test('safe npm wrapper does not invoke npm when lockfile preflight blocks', { skip: process.platform === 'win32' }, () => {
  const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'rla-safe-npm-preflight-'));
  const fakeBin = path.join(tempDir, 'bin');
  const sentinel = path.join(tempDir, 'npm-was-invoked');
  fs.mkdirSync(fakeBin, { recursive: true });
  const fakeNpm = path.join(fakeBin, 'npm');
  fs.writeFileSync(fakeNpm, `#!/bin/sh\nprintf invoked > '${sentinel.replace(/'/g, "'\\''")}'\nexit 99\n`, { mode: 0o700 });
  fs.chmodSync(fakeNpm, 0o700);
  try {
    const result = spawnSync(process.execPath, [path.join(rootDir, 'scripts', 'safe-npm-ci.js')], {
      cwd: rootDir,
      env: {
        PATH: fakeBin,
        RLA_APPROVED_NPM_REGISTRIES: 'registry.npmjs.org',
        npm_execpath: fakeNpm,
        NODE_TLS_REJECT_UNAUTHORIZED: '0'
      },
      encoding: 'utf8',
      timeout: 5000
    });
    assert.equal(result.error, undefined, result.error && result.error.message);
    assert.equal(result.status, 2, result.stdout + result.stderr);
    assert.match(result.stdout, /PACKAGE_LOCK_JSON_MISSING/);
    assert.equal(fs.existsSync(sentinel), false, 'npm must not execute when preflight is blocked');
  } finally {
    fs.rmSync(tempDir, { recursive: true, force: true });
  }
});
