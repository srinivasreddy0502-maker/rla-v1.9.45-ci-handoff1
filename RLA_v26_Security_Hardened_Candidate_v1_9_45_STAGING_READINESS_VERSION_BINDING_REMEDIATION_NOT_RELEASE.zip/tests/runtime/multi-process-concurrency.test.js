'use strict';
// Offline multi-process smoke test using the test-only node:sqlite adapter.
// This validates SQLite file-lock behavior in this test environment, not the native npm driver.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawn } = require('node:child_process');
const stopChildProcess = require('./test-support/stop-child');

const root = path.resolve(__dirname, '../..');
const adapterNodeModules = path.join(__dirname, 'test-support', 'node_modules');
const token = 'offline-multiprocess-bootstrap-token-0123456789';
const policy = JSON.stringify({
  ADMIN: ['applications:create', 'applications:read', 'audit:read']
});

function freePort() {
  const net = require('node:net');
  return new Promise((resolve, reject) => {
    const srv = net.createServer();
    srv.once('error', reject);
    srv.listen(0, '127.0.0.1', () => {
      const port = srv.address().port;
      srv.close(err => err ? reject(err) : resolve(port));
    });
  });
}

async function waitReady(proc, port) {
  const deadline = Date.now() + 8000;
  let output = '';
  proc.stdout.on('data', d => { output += d.toString(); });
  proc.stderr.on('data', d => { output += d.toString(); });
  while (Date.now() < deadline) {
    if (proc.exitCode !== null) throw new Error(`server exited early: ${output}`);
    try {
      const res = await fetch(`http://127.0.0.1:${port}/api/health`, { signal: AbortSignal.timeout(1000) });
      if (res.ok) return;
    } catch (_) {}
    await new Promise(r => setTimeout(r, 100));
  }
  throw new Error(`server readiness timeout: ${output}`);
}

function startServer(port, dbPath) {
  return spawn(process.execPath, ['app/server.js'], {
    cwd: root,
    env: {
      ...process.env,
      NODE_PATH: adapterNodeModules + (process.env.NODE_PATH ? path.delimiter + process.env.NODE_PATH : ''),
      PORT: String(port), RLA_DB_PATH: dbPath,
      RLA_BOOTSTRAP_ADMIN_TOKEN: token,
      RLA_BOOTSTRAP_ADMIN_JURISDICTION: 'TEST-JURISDICTION',
      RLA_AUTHZ_POLICY_JSON: policy,
      NODE_ENV: 'test'
    },
    stdio: ['ignore', 'pipe', 'pipe']
  });
}

async function stopServer(proc) {
  return stopChildProcess(proc, { gracefulTimeoutMs: 2000, forceTimeoutMs: 2000 });
}

async function createApplication(port, index) {
  const res = await fetch(`http://127.0.0.1:${port}/api/applications`, {
    method: 'POST',
    headers: { authorization: `Bearer ${token}`, 'content-type': 'application/json' },
    body: JSON.stringify({ service_type: `MP-${index}`, parcel_reference: `SURVEY-${index}` })
  });
  const body = await res.json();
  return { status: res.status, body };
}

test('two server processes sharing one SQLite file handle concurrent creates without lost writes', async t => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rla-multiprocess-'));
  const dbPath = path.join(dir, 'shared.sqlite');
  const port1 = await freePort();
  let port2 = await freePort();
  while (port2 === port1) port2 = await freePort();
  const first = startServer(port1, dbPath);
  let second;
  t.after(async () => {
    if (second) await stopServer(second);
    await stopServer(first);
    fs.rmSync(dir, { recursive: true, force: true });
  });
  await waitReady(first, port1);
  // Start the second instance after schema/bootstrap exists to focus this test on write locking.
  second = startServer(port2, dbPath);
  await waitReady(second, port2);
  const requests = Array.from({ length: 20 }, (_, i) =>
    createApplication(i % 2 ? port1 : port2, i));
  const results = await Promise.all(requests);
  assert.equal(results.filter(r => r.status === 201).length, 20,
    `expected 20 successful writes; statuses=${results.map(r => r.status).join(',')}`);
  const ids = results.map(r => r.body.id);
  assert.equal(new Set(ids).size, 20, 'application IDs must be unique across processes');
  const [list1, list2] = await Promise.all([
    fetch(`http://127.0.0.1:${port1}/api/applications`, { headers: { authorization: `Bearer ${token}` } }),
    fetch(`http://127.0.0.1:${port2}/api/applications`, { headers: { authorization: `Bearer ${token}` } })
  ]);
  assert.equal(list1.status, 200);
  assert.equal(list2.status, 200);
  assert.equal((await list1.json()).length, 20);
  assert.equal((await list2.json()).length, 20);
});
