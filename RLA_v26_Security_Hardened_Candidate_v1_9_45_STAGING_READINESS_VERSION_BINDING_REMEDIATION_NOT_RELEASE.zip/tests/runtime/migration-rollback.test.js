'use strict';
// Test-only offline migration rollback check. Uses node:sqlite compatibility adapter,
// not the native npm sqlite3 driver. A malformed legacy applications table forces a
// migration/index failure after earlier schema changes have begun.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawn } = require('node:child_process');
const stopChildProcess = require('./test-support/stop-child');
const { DatabaseSync } = require('node:sqlite');

const root = path.resolve(__dirname, '../..');
const adapterNodeModules = path.join(__dirname, 'test-support', 'node_modules');
const policy = JSON.stringify({ ADMIN: ['applications:create', 'applications:read', 'audit:read'] });
function freePort() {
  const net = require('node:net');
  return new Promise((resolve, reject) => {
    const srv = net.createServer(); srv.once('error', reject);
    srv.listen(0, '127.0.0.1', () => { const port = srv.address().port; srv.close(err => err ? reject(err) : resolve(port)); });
  });
}

test('failed legacy migration rolls back all schema mutations in the initialization transaction', async t => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rla-migration-rollback-'));
  const dbPath = path.join(dir, 'malformed-legacy.sqlite');
  const seed = new DatabaseSync(dbPath);
  seed.exec('CREATE TABLE applications(id TEXT PRIMARY KEY);');
  seed.close();
  const port = await freePort();
  const proc = spawn(process.execPath, ['app/server.js'], { cwd: root, env: {
    ...process.env,
    NODE_PATH: adapterNodeModules + (process.env.NODE_PATH ? path.delimiter + process.env.NODE_PATH : ''),
    PORT: String(port), RLA_DB_PATH: dbPath,
    RLA_BOOTSTRAP_ADMIN_TOKEN: 'migration-rollback-token-0123456789-ABCDE',
    RLA_BOOTSTRAP_ADMIN_JURISDICTION: 'TEST-JURISDICTION',
    RLA_AUTHZ_POLICY_JSON: policy, NODE_ENV: 'test'
  }, stdio: ['ignore', 'pipe', 'pipe'] });
  let output = '';
  proc.stdout.on('data', d => { output += d.toString(); });
  proc.stderr.on('data', d => { output += d.toString(); });
  t.after(async () => {
    try { await stopChildProcess(proc, { gracefulTimeoutMs: 1000, forceTimeoutMs: 1000 }); }
    finally { fs.rmSync(dir, { recursive: true, force: true }); }
  });
  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`server did not fail migration promptly: ${output}`)), 5000);
    proc.once('exit', code => { clearTimeout(timer); resolve(code); });
    proc.once('error', err => { clearTimeout(timer); reject(err); });
  }).then(code => assert.equal(code, 1, `expected fail-closed startup exit; output=${output}`));
  assert.match(output, /RLA startup blocked:/);

  const check = new DatabaseSync(dbPath);
  try {
    const tables = check.prepare("SELECT name FROM sqlite_master WHERE type='table'").all().map(r => r.name);
    assert.deepEqual(tables.sort(), ['applications'], 'new tables created during failed migration must roll back');
    const columns = check.prepare('PRAGMA table_info(applications)').all().map(r => r.name);
    assert.deepEqual(columns, ['id'], 'ALTER TABLE changes from failed migration must roll back');
    const indexes = check.prepare("SELECT name FROM sqlite_master WHERE type='index' AND name LIKE 'idx_%'").all();
    assert.equal(indexes.length, 0, 'migration indexes must not survive failed initialization');
  } finally { check.close(); }
});
