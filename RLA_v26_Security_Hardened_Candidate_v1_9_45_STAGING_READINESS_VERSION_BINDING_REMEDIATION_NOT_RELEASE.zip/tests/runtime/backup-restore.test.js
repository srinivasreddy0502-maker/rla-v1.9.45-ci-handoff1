'use strict';
// Test-only SQLite backup/restore smoke test using Node's built-in SQLite adapter.
// This does not validate a production backup job or the native npm sqlite3 driver.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');

test('offline SQLite backup/restore preserves records and passes integrity checks', t => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rla-backup-restore-'));
  const sourcePath = path.join(dir, 'source.sqlite');
  const backupPath = path.join(dir, 'backup.sqlite');
  const restoredPath = path.join(dir, 'restored.sqlite');
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));

  const source = new DatabaseSync(sourcePath);
  try {
    source.exec(`PRAGMA journal_mode=WAL;
      PRAGMA foreign_keys=ON;
      CREATE TABLE users(id TEXT PRIMARY KEY, role TEXT NOT NULL, jurisdiction TEXT NOT NULL);
      CREATE TABLE applications(id TEXT PRIMARY KEY, created_by TEXT NOT NULL REFERENCES users(id), jurisdiction TEXT NOT NULL);
      CREATE TABLE audit(id TEXT PRIMARY KEY, actor TEXT NOT NULL, object_id TEXT NOT NULL, jurisdiction TEXT NOT NULL);
      INSERT INTO users VALUES ('u1','ADMIN','TEST-A');
      INSERT INTO applications VALUES ('a1','u1','TEST-A');
      INSERT INTO audit VALUES ('e1','u1','a1','TEST-A');`);
    const checkpoint = source.prepare('PRAGMA wal_checkpoint(TRUNCATE)').get();
    assert.equal(Number(checkpoint.busy), 0, 'WAL checkpoint must not report busy');
    source.exec(`VACUUM INTO '${backupPath.replace(/'/g, "''")}'`);
  } finally { source.close(); }

  assert.ok(fs.statSync(backupPath).size > 0, 'backup artifact must exist and be non-empty');
  fs.copyFileSync(backupPath, restoredPath);
  const restored = new DatabaseSync(restoredPath);
  try {
    assert.equal(restored.prepare('PRAGMA integrity_check').get().integrity_check, 'ok');
    assert.equal(restored.prepare('SELECT COUNT(*) AS n FROM users').get().n, 1);
    assert.equal(restored.prepare('SELECT COUNT(*) AS n FROM applications').get().n, 1);
    assert.equal(restored.prepare('SELECT COUNT(*) AS n FROM audit').get().n, 1);
    assert.equal(restored.prepare('SELECT jurisdiction FROM audit WHERE id=?').get('e1').jurisdiction, 'TEST-A');
  } finally { restored.close(); }
});
