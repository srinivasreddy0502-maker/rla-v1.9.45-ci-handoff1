'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const { createAuditCheckpoint } = require('../../app/audit-evidence-checkpoint');
const { publishCheckpoint, verifyStoredCheckpoint } = require('../../app/audit-evidence-checkpoint-store');
const auditKey = 'audit-evidence-key-for-tests-minimum-32-bytes-long';
const storeKey1 = 'store-key-generation-one-at-least-32-bytes';
const storeKey2 = 'store-key-generation-two-at-least-32-bytes';

async function fixture(t) {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'rla-checkpoint-store-'));
  t.after(() => fs.rm(root, { recursive: true, force: true }));
  const recordsDir = path.join(root, 'records');
  const stageDir = path.join(root, 'stage');
  const storeDir = path.join(root, 'independent-store');
  for (const dir of [recordsDir, stageDir, storeDir]) await fs.mkdir(dir, { mode: 0o700 });
  const evidenceRoot = path.join(root, 'evidence');
  await fs.mkdir(evidenceRoot, { mode: 0o700 });
  await fs.writeFile(path.join(evidenceRoot, 'proof.txt'), 'test evidence', { mode: 0o600 });
  const { createEvidenceRecord } = require('../../app/audit-evidence-chain');
  const r = await createEvidenceRecord({ evidenceRoot, evidenceNames: ['proof.txt'], sequence: 1, actorId: 'test-operator', eventType: 'CHECKPOINT_TEST', changeRef: 'test-case-001', key: auditKey, now: new Date('2026-10-12T00:00:00.000Z') });
  await fs.writeFile(path.join(recordsDir, 'record-000001.json'), JSON.stringify(r)+'\n', { mode: 0o600 });
  const staged = path.join(stageDir, 'source.checkpoint.json');
  await createAuditCheckpoint({ recordsDir, checkpointPath: staged, key: auditKey, now: new Date('2026-10-12T00:01:00.000Z') });
  return { recordsDir, stageDir, storeDir, staged };
}
test('publishes checkpoint to separate store and independently verifies receipt and chain', async t => {
  const f = await fixture(t);
  const published = await publishCheckpoint({ checkpointPath: f.staged, storageDir: f.storeDir, checkpointId: 'checkpoint-0001', storeKey: storeKey1, storeKeyId: 'store-2026-q4' });
  const result = await verifyStoredCheckpoint({ storageDir: f.storeDir, checkpointId: 'checkpoint-0001', storeKeys: { 'store-2026-q4': storeKey1 }, checkpointKey: auditKey, recordsDir: f.recordsDir });
  assert.equal(result.valid, true);
  assert.equal(result.storeKeyId, 'store-2026-q4');
  assert.match(published.checkpointSha256, /^[a-f0-9]{64}$/);
});
test('supports key rotation by verifying receipts with the key id in the configured keyring', async t => {
  const f = await fixture(t);
  await publishCheckpoint({ checkpointPath: f.staged, storageDir: f.storeDir, checkpointId: 'rotated-0001', storeKey: storeKey1, storeKeyId: 'old-key' });
  assert.equal((await verifyStoredCheckpoint({ storageDir: f.storeDir, checkpointId: 'rotated-0001', storeKeys: { 'old-key': storeKey1, 'new-key': storeKey2 }, checkpointKey: auditKey, recordsDir: f.recordsDir })).valid, true);
  await assert.rejects(() => verifyStoredCheckpoint({ storageDir: f.storeDir, checkpointId: 'rotated-0001', storeKeys: { 'old-key': storeKey2 }, checkpointKey: auditKey, recordsDir: f.recordsDir }), /HMAC verification failed/);
});
test('refuses overwrite of an existing checkpoint identifier', async t => {
  const f = await fixture(t);
  const args = { checkpointPath: f.staged, storageDir: f.storeDir, checkpointId: 'no-overwrite', storeKey: storeKey1, storeKeyId: 'key-1' };
  await publishCheckpoint(args);
  await assert.rejects(() => publishCheckpoint(args), /EEXIST/);
});
test('rejects malformed ids and weak store keys', async t => {
  const f = await fixture(t);
  await assert.rejects(() => publishCheckpoint({ checkpointPath: f.staged, storageDir: f.storeDir, checkpointId: '../bad', storeKey: storeKey1, storeKeyId: 'key-1' }), /checkpointId/);
  await assert.rejects(() => publishCheckpoint({ checkpointPath: f.staged, storageDir: f.storeDir, checkpointId: 'weak-key', storeKey: 'tiny', storeKeyId: 'key-1' }), /32 UTF-8 bytes/);
});
test('detects checkpoint tampering after publication', async t => {
  const f = await fixture(t);
  await publishCheckpoint({ checkpointPath: f.staged, storageDir: f.storeDir, checkpointId: 'tamper-0001', storeKey: storeKey1, storeKeyId: 'key-1' });
  await fs.chmod(path.join(f.storeDir, 'tamper-0001.checkpoint.json'), 0o600);
  await fs.appendFile(path.join(f.storeDir, 'tamper-0001.checkpoint.json'), ' ');
  await assert.rejects(() => verifyStoredCheckpoint({ storageDir: f.storeDir, checkpointId: 'tamper-0001', storeKeys: { 'key-1': storeKey1 }, checkpointKey: auditKey, recordsDir: f.recordsDir }), /digest does not match/);
});
