'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createPackageIntegrityManifest, verifyPackageIntegrityManifest, validateManifest } = require('../../app/package-integrity-manifest');

function fixture() {
  const rootDir = fs.mkdtempSync(path.join(os.tmpdir(), 'rla-package-integrity-'));
  fs.mkdirSync(path.join(rootDir, 'app'));
  fs.writeFileSync(path.join(rootDir, 'package.json'), JSON.stringify({ name: 'fixture', version: '1.0.0' }));
  fs.writeFileSync(path.join(rootDir, 'app', 'main.js'), "'use strict';\nmodule.exports = 1;\n");
  const manifestPath = path.join(rootDir, 'integrity-manifest.json');
  const manifest = createPackageIntegrityManifest({ rootDir, manifestPath, generatedAt: '2026-01-01T00:00:00.000Z' });
  fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2));
  return { rootDir, manifestPath, manifest };
}

test('creates and verifies a complete SHA-256 manifest', () => {
  const f = fixture();
  const r = verifyPackageIntegrityManifest({ rootDir: f.rootDir, manifestPath: f.manifestPath });
  assert.equal(r.status, 'PASS');
  assert.equal(r.verifiedCount, 2);
  assert.equal(r.productionUseAuthorized, false);
});
test('detects content tampering', () => {
  const f = fixture();
  fs.appendFileSync(path.join(f.rootDir, 'app', 'main.js'), '// tampered\n');
  const r = verifyPackageIntegrityManifest({ rootDir: f.rootDir, manifestPath: f.manifestPath });
  assert.equal(r.status, 'BLOCKED');
  assert.ok(r.blockers.includes('PACKAGE_FILE_SIZE_MISMATCH:app/main.js') || r.blockers.includes('PACKAGE_FILE_HASH_MISMATCH:app/main.js'));
});
test('detects a missing packaged file', () => {
  const f = fixture();
  fs.unlinkSync(path.join(f.rootDir, 'app', 'main.js'));
  const r = verifyPackageIntegrityManifest({ rootDir: f.rootDir, manifestPath: f.manifestPath });
  assert.ok(r.blockers.includes('PACKAGE_FILE_MISSING:app/main.js'));
});
test('detects files added after manifest generation', () => {
  const f = fixture();
  fs.writeFileSync(path.join(f.rootDir, 'extra.txt'), 'untracked');
  const r = verifyPackageIntegrityManifest({ rootDir: f.rootDir, manifestPath: f.manifestPath });
  assert.ok(r.blockers.includes('UNMANIFESTED_PACKAGE_FILE:extra.txt'));
});
test('rejects duplicate and unsafe manifest paths', () => {
  const f = fixture();
  const bad = structuredClone(f.manifest);
  bad.entries.push({ ...bad.entries[0] });
  bad.entryCount++;
  assert.ok(validateManifest(bad).some(x => x.startsWith('MANIFEST_DUPLICATE_PATH:')));
  const unsafe = structuredClone(f.manifest);
  unsafe.entries[0].path = '../escape';
  assert.ok(validateManifest(unsafe).includes('MANIFEST_ENTRY_INVALID'));
});
test('rejects malformed digest, size and schema', () => {
  const f = fixture();
  const bad = structuredClone(f.manifest);
  bad.entries[0].sha256 = 'xyz';
  bad.entries[0].sizeBytes = -1;
  assert.ok(validateManifest(bad).includes('MANIFEST_ENTRY_INVALID'));
  assert.ok(validateManifest({ schemaVersion: 99 }).includes('MANIFEST_SCHEMA_INVALID'));
});
test('rejects symbolic links rather than following them', t => {
  const f = fixture();
  const target = path.join(f.rootDir, 'app', 'main.js');
  const link = path.join(f.rootDir, 'app', 'linked.js');
  try { fs.symlinkSync(target, link); }
  catch (error) { if (['EPERM', 'EACCES', 'ENOTSUP'].includes(error.code)) { t.skip(`symlink unavailable: ${error.code}`); return; } throw error; }
  assert.throws(() => createPackageIntegrityManifest({ rootDir: f.rootDir, manifestPath: f.manifestPath }), /SYMLINK_NOT_ALLOWED/);
});
test('missing manifest fails closed', () => {
  const rootDir = fs.mkdtempSync(path.join(os.tmpdir(), 'rla-package-integrity-missing-'));
  const r = verifyPackageIntegrityManifest({ rootDir, manifestPath: path.join(rootDir, 'missing.json') });
  assert.equal(r.status, 'BLOCKED');
  assert.ok(r.blockers.includes('MANIFEST_MISSING_OR_INVALID_JSON'));
});
test('manifest output must remain inside package root', () => {
  const rootDir = fs.mkdtempSync(path.join(os.tmpdir(), 'rla-package-integrity-path-'));
  assert.throws(() => createPackageIntegrityManifest({ rootDir, manifestPath: path.join(os.tmpdir(), 'outside.json') }), /MANIFEST_PATH_MUST_BE_INSIDE_PACKAGE_ROOT/);
});
