'use strict';
// Authored runtime integration tests. These require sqlite3 to be installed and are NOT
// evidence of a pass until executed in an environment that can install native dependencies.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const net = require('node:net');
const { spawn } = require('node:child_process');
const sqlite3 = require('sqlite3');
const stopChildProcess = require('./test-support/stop-child');

const ROOT = path.resolve(__dirname, '../..');
const TOKEN = 'rla-test-bootstrap-token-0123456789-ABCDEF';
const POLICY = JSON.stringify({
  ADMIN: ['applications:read', 'applications:create', 'applications:transition_request', 'applications:approve_transition', 'audit:read'],
  READER: ['applications:read', 'audit:read'],
  MAKER: ['applications:read', 'applications:create', 'applications:transition_request', 'applications:approve_transition'],
  CHECKER: ['applications:read', 'applications:approve_transition', 'audit:read']
});
let tmp, dbPath, port, child, output = '', errors = '';

function freePort() {
  return new Promise((resolve, reject) => {
    const s = net.createServer();
    s.once('error', reject);
    s.listen(0, '127.0.0.1', () => {
      const p = s.address().port;
      s.close(err => err ? reject(err) : resolve(p));
    });
  });
}
function openDb(filename) {
  return new Promise((resolve, reject) => {
    const d = new sqlite3.Database(filename, err => err ? reject(err) : resolve(d));
  });
}
function runDb(d, sql, params = []) {
  return new Promise((resolve, reject) => d.run(sql, params, function (err) {
    if (err) reject(err); else resolve({ changes: this.changes, lastID: this.lastID });
  }));
}
function getDb(d, sql, params = []) {
  return new Promise((resolve, reject) => d.get(sql, params, (err, row) => err ? reject(err) : resolve(row)));
}
async function startServer(extraEnv = {}) {
  port = await freePort();
  output = ''; errors = '';
  child = spawn(process.execPath, ['app/server.js'], {
    cwd: ROOT,
    env: { ...process.env, PORT: String(port), NODE_ENV: 'test', RLA_DB_PATH: dbPath,
      RLA_AUTHZ_POLICY_JSON: POLICY, RLA_BOOTSTRAP_ADMIN_TOKEN: TOKEN,
      RLA_BOOTSTRAP_ADMIN_JURISDICTION: 'KRM-AREPALLI', ...extraEnv },
    stdio: ['ignore', 'pipe', 'pipe']
  });
  child.stdout.on('data', b => { output += b.toString(); });
  child.stderr.on('data', b => { errors += b.toString(); });
  const deadline = Date.now() + 8000;
  while (Date.now() < deadline) {
    if (child.exitCode !== null) throw new Error(`Server exited early: ${errors || output}`);
    try {
      const r = await fetch(`http://127.0.0.1:${port}/api/health`, { signal: AbortSignal.timeout(1000) });
      if (r.ok) return;
    } catch (_) {}
    await new Promise(r => setTimeout(r, 100));
  }
  throw new Error(`Server did not become ready: ${errors || output}`);
}
async function stopServer() {
  return stopChildProcess(child, { gracefulTimeoutMs: 3000, forceTimeoutMs: 2000 });
}
async function request(route, { method = 'GET', token = TOKEN, body } = {}) {
  const headers = {};
  if (token) headers.authorization = `Bearer ${token}`;
  if (body !== undefined) headers['content-type'] = 'application/json';
  const response = await fetch(`http://127.0.0.1:${port}${route}`, {
    method, headers, body: body === undefined ? undefined : JSON.stringify(body)
  });
  let data;
  try { data = await response.json(); } catch (_) { data = null; }
  return { status: response.status, data };
}

test('runtime integration: bootstrap, authorization, jurisdiction, concurrency, rollback and restart', async t => {
  tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'rla-v14-runtime-'));
  dbPath = path.join(tmp, 'rla-test.sqlite');
  await startServer();
  t.after(async () => {
    await stopServer();
    fs.rmSync(tmp, { recursive: true, force: true });
  });

  await t.test('health and authenticated application creation', async () => {
    const health = await request('/api/health', { token: null });
    assert.equal(health.status, 200);
    assert.equal(health.data.readiness, 'configured');
    assert.equal((await request('/api/applications', { token: null })).status, 401);
    const created = await request('/api/applications', {
      method: 'POST', body: { service_type: 'LAND_RECORD_REVIEW', parcel_reference: 'SY-101' }
    });
    assert.equal(created.status, 201, JSON.stringify(created.data));
    assert.equal(created.data.state, 'INTAKE');
    assert.equal(created.data.version, 1);
  });

  await t.test('transaction queue preserves all concurrent application writes', async () => {
    const requests = Array.from({ length: 12 }, (_, i) => request('/api/applications', {
      method: 'POST', body: { service_type: 'CONCURRENCY_REGRESSION', parcel_reference: `SY-CON-${i}` }
    }));
    const results = await Promise.all(requests);
    assert.equal(results.filter(r => r.status === 201).length, 12,
      JSON.stringify(results.map(r => ({ status: r.status, data: r.data }))));
    assert.equal(new Set(results.map(r => r.data.id)).size, 12, 'application IDs must be unique');
  });

  await t.test('maker-checker: direct transition blocked, self-approval denied, checker approval is single-use', async () => {
    const db = await openDb(dbPath);
    const crypto = require('node:crypto');
    const makerToken = 'rla-maker-token-0123456789-ABCDEF';
    const checkerToken = 'rla-checker-token-0123456789-ABCDEF';
    try {
      await runDb(db, 'INSERT INTO users(id,name,role,token_hash,jurisdiction) VALUES(?,?,?,?,?)',
        ['U_MAKER', 'Maker', 'MAKER', crypto.createHash('sha256').update(makerToken).digest('hex'), 'KRM-AREPALLI']);
      await runDb(db, 'INSERT INTO users(id,name,role,token_hash,jurisdiction) VALUES(?,?,?,?,?)',
        ['U_CHECKER', 'Checker', 'CHECKER', crypto.createHash('sha256').update(checkerToken).digest('hex'), 'KRM-AREPALLI']);
      const foreignCheckerToken = 'rla-foreign-checker-token-0123456789';
      await runDb(db, 'INSERT INTO users(id,name,role,token_hash,jurisdiction) VALUES(?,?,?,?,?)',
        ['U_FOREIGN_CHECKER', 'Foreign Checker', 'CHECKER', crypto.createHash('sha256').update(foreignCheckerToken).digest('hex'), 'PDP-OTHER']);
    } finally { await new Promise(resolve => db.close(resolve)); }

    const made = await request('/api/applications', { method: 'POST', token: makerToken,
      body: { service_type: 'MAKER_CHECKER_TEST', parcel_reference: 'SY-MC-102' } });
    assert.equal(made.status, 201, JSON.stringify(made.data));
    const direct = await request(`/api/applications/${made.data.id}/transition`, { method: 'POST', token: makerToken,
      body: { expected_version: 1, to_state: 'EVIDENCE' } });
    assert.equal(direct.status, 410);
    assert.equal(direct.data.error, 'MAKER_CHECKER_REQUIRED');

    const submitted = await request(`/api/applications/${made.data.id}/transition-requests`, { method: 'POST', token: makerToken,
      body: { expected_version: 1, to_state: 'EVIDENCE' } });
    assert.equal(submitted.status, 202, JSON.stringify(submitted.data));
    const decisionPath = `/api/applications/${made.data.id}/transition-requests/${submitted.data.request_id}/decision`;
    const selfApproval = await request(decisionPath, { method: 'POST', token: makerToken, body: { decision: 'APPROVE' } });
    assert.equal(selfApproval.status, 403);
    assert.equal(selfApproval.data.error, 'MAKER_CANNOT_APPROVE_OWN_REQUEST');

    const foreign = await request(decisionPath, { method: 'POST', token: 'rla-foreign-checker-token-0123456789', body: { decision: 'APPROVE' } });
    assert.equal(foreign.status, 403, JSON.stringify(foreign.data));

    const results = await Promise.all([
      request(decisionPath, { method: 'POST', token: checkerToken, body: { decision: 'APPROVE', reason: 'Reviewed evidence' } }),
      request(decisionPath, { method: 'POST', token: checkerToken, body: { decision: 'APPROVE', reason: 'Duplicate attempt' } })
    ]);
    assert.equal(results.filter(r => r.status === 200).length, 1, JSON.stringify(results));
    assert.equal(results.filter(r => r.status === 409).length, 1, JSON.stringify(results));
    const rows = await request('/api/applications', { token: makerToken });
    assert.equal(rows.data.find(a => a.id === made.data.id).state, 'EVIDENCE');
    assert.equal(rows.data.find(a => a.id === made.data.id).version, 2);

    const rejectApp = await request('/api/applications', { method: 'POST', token: makerToken,
      body: { service_type: 'REJECTION_TEST', parcel_reference: 'SY-MC-REJECT' } });
    const rejectRequest = await request(`/api/applications/${rejectApp.data.id}/transition-requests`, { method: 'POST', token: makerToken,
      body: { expected_version: 1, to_state: 'EVIDENCE' } });
    const rejected = await request(`/api/applications/${rejectApp.data.id}/transition-requests/${rejectRequest.data.request_id}/decision`,
      { method: 'POST', token: checkerToken, body: { decision: 'REJECT', reason: 'Insufficient evidence' } });
    assert.equal(rejected.status, 200, JSON.stringify(rejected.data));
    assert.equal(rejected.data.status, 'REJECTED');
    const afterReject = await request('/api/applications', { token: makerToken });
    assert.equal(afterReject.data.find(a => a.id === rejectApp.data.id).state, 'INTAKE', 'rejection must not mutate workflow state');
  });

  await t.test('application and audit reads are jurisdiction-scoped', async () => {
    const db = await openDb(dbPath);
    try {
      const crypto = require('node:crypto');
      const otherToken = 'rla-reader-token-0123456789-ABCDEF';
      const hash = crypto.createHash('sha256').update(otherToken).digest('hex');
      await runDb(db, 'INSERT INTO users(id,name,role,token_hash,jurisdiction) VALUES(?,?,?,?,?)',
        ['U_OTHER', 'Other Jurisdiction Reader', 'READER', hash, 'PDP-OTHER']);
      await runDb(db, `INSERT INTO applications(id,service_type,parcel_reference,state,version,created_at,created_by,jurisdiction)
        VALUES(?,?,?,?,?,?,?,?)`, ['APP-OTHER-01', 'TEST', 'SY-999', 'INTAKE', 1, new Date().toISOString(), 'U_OTHER', 'PDP-OTHER']);
      await runDb(db, `INSERT INTO audit(id,actor,action,object_id,from_state,to_state,created_at,jurisdiction)
        VALUES(?,?,?,?,?,?,?,?)`, ['AUD-OTHER-01', 'U_OTHER', 'TEST_EVENT', 'APP-OTHER-01', null, null, new Date().toISOString(), 'PDP-OTHER']);
      const own = await request('/api/applications');
      assert.equal(own.status, 200);
      assert.equal(own.data.some(a => a.jurisdiction === 'PDP-OTHER'), false);
      const other = await request('/api/applications', { token: otherToken });
      assert.equal(other.status, 200);
      assert.equal(other.data.some(a => a.jurisdiction === 'KRM-AREPALLI'), false);
      const ownAudit = await request('/api/audit');
      assert.equal(ownAudit.status, 200, JSON.stringify(ownAudit.data));
      assert.equal(ownAudit.data.some(a => a.jurisdiction === 'PDP-OTHER' || a.id === 'AUD-OTHER-01'), false);
      const otherAudit = await request('/api/audit', { token: otherToken });
      assert.equal(otherAudit.status, 200, JSON.stringify(otherAudit.data));
      assert.equal(otherAudit.data.some(a => a.id === 'AUD-OTHER-01'), true);
      assert.equal(otherAudit.data.some(a => a.object_id !== 'APP-OTHER-01'), false);
    } finally { await new Promise(resolve => db.close(resolve)); }
  });

  await t.test('audit insert failure rolls back application creation', async () => {
    const db = await openDb(dbPath);
    try {
      await runDb(db, `CREATE TRIGGER fail_audit_insert BEFORE INSERT ON audit
        BEGIN SELECT RAISE(ABORT, 'injected audit failure'); END;`);
    } finally { await new Promise(resolve => db.close(resolve)); }
    const failed = await request('/api/applications', {
      method: 'POST', body: { service_type: 'ROLLBACK_TEST', parcel_reference: 'SY-ROLLBACK' }
    });
    assert.equal(failed.status, 500, JSON.stringify(failed.data));
    const db2 = await openDb(dbPath);
    try {
      const row = await getDb(db2, "SELECT COUNT(*) AS n FROM applications WHERE parcel_reference='SY-ROLLBACK'");
      assert.equal(row.n, 0, 'application row must roll back when audit write fails');
    } finally { await new Promise(resolve => db2.close(resolve)); }
  });

  await t.test('existing bootstrap account survives restart without resupplying bootstrap token', async () => {
    await stopServer();
    await startServer({ RLA_BOOTSTRAP_ADMIN_TOKEN: '' });
    const health = await request('/api/health', { token: null });
    assert.equal(health.status, 200);
    const rows = await request('/api/applications');
    assert.equal(rows.status, 200);
  });
});


test('legacy audit schema migrates without exposing unscoped historical rows', async t => {
  tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'rla-v144-migration-'));
  dbPath = path.join(tmp, 'legacy.sqlite');
  const legacy = await openDb(dbPath);
  try {
    await new Promise((resolve, reject) => legacy.exec(`
      CREATE TABLE audit(
        id TEXT PRIMARY KEY, actor TEXT NOT NULL, action TEXT NOT NULL,
        object_id TEXT, from_state TEXT, to_state TEXT, created_at TEXT NOT NULL
      );
      INSERT INTO audit(id,actor,action,object_id,from_state,to_state,created_at)
      VALUES('AUD-LEGACY-UNSCOPED','U_OLD','LEGACY_EVENT',NULL,NULL,NULL,'2025-01-01T00:00:00.000Z');
    `, err => err ? reject(err) : resolve()));
  } finally { await new Promise(resolve => legacy.close(resolve)); }

  await startServer();
  t.after(async () => {
    await stopServer();
    fs.rmSync(tmp, { recursive: true, force: true });
  });
  const created = await request('/api/applications', {
    method: 'POST', body: { service_type: 'MIGRATION_TEST', parcel_reference: 'SY-MIG-01' }
  });
  assert.equal(created.status, 201, JSON.stringify(created.data));
  const audit = await request('/api/audit');
  assert.equal(audit.status, 200, JSON.stringify(audit.data));
  assert.equal(audit.data.some(row => row.id === 'AUD-LEGACY-UNSCOPED'), false,
    'legacy rows with unknown jurisdiction must remain excluded');
  assert.equal(audit.data.some(row => row.action === 'APPLICATION_CREATED'), true,
    'new scoped audit rows must be visible to their jurisdiction');
});

// v1.4.7 regression tests: approval transaction rollback, permission separation, stale request.
test('maker-checker hardening: permission denial, approval rollback, and stale-request invalidation', async t => {
  tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'rla-v147-maker-checker-'));
  dbPath = path.join(tmp, 'rla-maker-checker.sqlite');
  await startServer();
  t.after(async () => {
    await stopServer();
    fs.rmSync(tmp, { recursive: true, force: true });
  });

  const crypto = require('node:crypto');
  const makerToken = 'rla-v147-maker-token-0123456789-ABCDEF';
  const checkerToken = 'rla-v147-checker-token-0123456789-ABCDEF';
  const readerToken = 'rla-v147-reader-token-0123456789-ABCDEF';
  const db = await openDb(dbPath);
  try {
    for (const [id, name, role, token] of [
      ['U_V147_MAKER', 'Maker v147', 'MAKER', makerToken],
      ['U_V147_CHECKER', 'Checker v147', 'CHECKER', checkerToken],
      ['U_V147_READER', 'Reader v147', 'READER', readerToken]
    ]) {
      await runDb(db, 'INSERT INTO users(id,name,role,token_hash,jurisdiction) VALUES(?,?,?,?,?)',
        [id, name, role, crypto.createHash('sha256').update(token).digest('hex'), 'KRM-AREPALLI']);
    }
  } finally { await new Promise(resolve => db.close(resolve)); }

  const created = await request('/api/applications', { method: 'POST', token: makerToken,
    body: { service_type: 'MC_ROLLBACK_TEST', parcel_reference: 'SY-V147-01' } });
  assert.equal(created.status, 201, JSON.stringify(created.data));
  const submitted = await request(`/api/applications/${created.data.id}/transition-requests`, {
    method: 'POST', token: makerToken, body: { expected_version: 1, to_state: 'EVIDENCE' }
  });
  assert.equal(submitted.status, 202, JSON.stringify(submitted.data));
  const decisionPath = `/api/applications/${created.data.id}/transition-requests/${submitted.data.request_id}/decision`;

  await t.test('role without approve permission is denied', async () => {
    const denied = await request(decisionPath, { method: 'POST', token: readerToken, body: { decision: 'APPROVE' } });
    assert.equal(denied.status, 403);
    assert.equal(denied.data.error, 'FORBIDDEN');
  });

  await t.test('approval audit failure rolls back state and request consumption', async () => {
    const d = await openDb(dbPath);
    try {
      await runDb(d, `CREATE TRIGGER fail_transition_approved_audit BEFORE INSERT ON audit
        WHEN NEW.action='TRANSITION_APPROVED'
        BEGIN SELECT RAISE(ABORT, 'injected approval audit failure'); END;`);
    } finally { await new Promise(resolve => d.close(resolve)); }

    const failed = await request(decisionPath, { method: 'POST', token: checkerToken,
      body: { decision: 'APPROVE', reason: 'Reviewed for rollback test' } });
    assert.equal(failed.status, 500, JSON.stringify(failed.data));

    const check = await openDb(dbPath);
    try {
      const app = await getDb(check, 'SELECT state,version FROM applications WHERE id=?', [created.data.id]);
      const tr = await getDb(check, 'SELECT status FROM transition_requests WHERE id=?', [submitted.data.request_id]);
      const audit = await getDb(check, "SELECT COUNT(*) AS n FROM audit WHERE object_id=? AND action='TRANSITION_APPROVED'", [created.data.id]);
      assert.equal(app.state, 'INTAKE', 'application mutation must roll back');
      assert.equal(app.version, 1, 'version increment must roll back');
      assert.equal(tr.status, 'PENDING', 'request consumption must roll back');
      assert.equal(audit.n, 0, 'failed approval audit must not be present');
      await runDb(check, 'DROP TRIGGER fail_transition_approved_audit');
    } finally { await new Promise(resolve => check.close(resolve)); }
  });

  await t.test('request becomes stale when application version/state changes', async () => {
    const d = await openDb(dbPath);
    try {
      await runDb(d, "UPDATE applications SET state='EVIDENCE',version=2 WHERE id=?", [created.data.id]);
    } finally { await new Promise(resolve => d.close(resolve)); }
    const stale = await request(decisionPath, { method: 'POST', token: checkerToken,
      body: { decision: 'APPROVE', reason: 'Must be rejected as stale' } });
    assert.equal(stale.status, 409, JSON.stringify(stale.data));
    assert.equal(stale.data.error, 'STALE_REQUEST');
    const d2 = await openDb(dbPath);
    try {
      const tr = await getDb(d2, 'SELECT status FROM transition_requests WHERE id=?', [submitted.data.request_id]);
      assert.equal(tr.status, 'STALE');
    } finally { await new Promise(resolve => d2.close(resolve)); }
  });
});
