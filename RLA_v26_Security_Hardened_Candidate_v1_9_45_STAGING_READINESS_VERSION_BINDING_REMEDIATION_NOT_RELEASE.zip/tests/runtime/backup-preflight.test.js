'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const { backupPreflight, validateNativeDriver } = require('../../scripts/backup-preflight');

const KEY = 'test-only-backup-preflight-key-at-least-32-bytes';
function fakeDriver() {
  class Database {}
  Database.prototype.backup = function backup() {};
  return { Database, OPEN_READONLY: 1 };
}
async function fixture(t) {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'rla-backup-preflight-'));
  await fs.chmod(root, 0o700);
  const sourceDir = path.join(root, 'source');
  const backupDir = path.join(root, 'backups');
  const manifestDir = path.join(root, 'manifests');
  for (const dir of [sourceDir, backupDir, manifestDir]) {
    await fs.mkdir(dir, { mode: 0o700 });
    await fs.chmod(dir, 0o700);
  }
  const sourcePath = path.join(sourceDir, 'live.sqlite');
  const backupPath = path.join(backupDir, 'nightly.sqlite');
  const manifestPath = path.join(manifestDir, 'nightly.manifest.json');
  await fs.writeFile(sourcePath, 'test-only-source-db');
  t.after(() => fs.rm(root, { recursive: true, force: true }));
  return { root, sourcePath, backupPath, manifestPath };
}

test('preflight passes with private directories, absent destinations, strong key and backup-capable driver', async t => {
  const f = await fixture(t);
  const result = await backupPreflight({ ...f, key: KEY, sqlite3: fakeDriver() });
  assert.equal(result.ok, true);
  assert.equal(result.overwrite, false);
  assert.equal(result.secretValueLogged, false);
  assert.equal(result.driver, 'sqlite3-online-backup-api-available');
});

test('preflight fails closed when native backup API is unavailable', async () => {
  assert.throws(() => validateNativeDriver({ Database: function Database() {}, OPEN_READONLY: 1 }), /unavailable/);
});

test('preflight refuses weak key and does not create artifacts', async t => {
  const f = await fixture(t);
  await assert.rejects(() => backupPreflight({ ...f, key: 'weak', sqlite3: fakeDriver() }), /at least 32/);
  await assert.rejects(() => fs.lstat(f.backupPath), { code: 'ENOENT' });
  await assert.rejects(() => fs.lstat(f.manifestPath), { code: 'ENOENT' });
});

test('preflight refuses existing backup or manifest destinations', async t => {
  const f = await fixture(t);
  await fs.writeFile(f.backupPath, 'preserve');
  await assert.rejects(() => backupPreflight({ ...f, key: KEY, sqlite3: fakeDriver() }), /already exists/);
  assert.equal(await fs.readFile(f.backupPath, 'utf8'), 'preserve');
});

test('preflight rejects symlinked source and non-private backup directories', async t => {
  const f = await fixture(t);
  const link = path.join(path.dirname(f.sourcePath), 'source-link.sqlite');
  await fs.symlink(f.sourcePath, link);
  await assert.rejects(() => backupPreflight({ ...f, sourcePath: link, key: KEY, sqlite3: fakeDriver() }), /symbolic link/);
  if (process.platform !== 'win32') {
    await fs.chmod(path.dirname(f.backupPath), 0o755);
    await assert.rejects(() => backupPreflight({ ...f, key: KEY, sqlite3: fakeDriver() }), /group or other permissions/);
  }
});
