'use strict';
// Runs runtime integration tests with a test-only adapter backed by node:sqlite.
// It does not replace or modify the production dependency declaration.
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const adapterNodeModules = path.join(__dirname, 'test-support', 'node_modules');
const existing = process.env.NODE_PATH ? path.delimiter + process.env.NODE_PATH : '';
const env = { ...process.env, NODE_PATH: adapterNodeModules + existing };
const result = spawnSync(process.execPath, ['--test', path.join(__dirname, 'runtime-integration.test.js')], {
  cwd: path.resolve(__dirname, '../..'), env, stdio: 'inherit'
});
if (result.error) {
  process.stderr.write(`Offline runtime runner failed: ${result.error.message}\n`);
  process.exit(1);
}
process.exit(result.status === null ? 1 : result.status);
