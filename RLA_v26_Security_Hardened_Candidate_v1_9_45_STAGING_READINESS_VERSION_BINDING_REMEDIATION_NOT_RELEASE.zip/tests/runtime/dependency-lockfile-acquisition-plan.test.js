'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { parseExplicitRegistry, readRegularFileNoFollow, buildLockfileAcquisitionPlan, resolveLockfileAcquisitionPlan } = require('../../app/dependency-lockfile-acquisition-plan');

function fixture({ lock = false, version = '5.1.7' } = {}) {
  const rootDir = fs.mkdtempSync(path.join(os.tmpdir(), 'rla-lock-capture-plan-'));
  fs.writeFileSync(path.join(rootDir, 'package.json'), JSON.stringify({ name: 'rla-fixture', version: '1.0.0', dependencies: { sqlite3: version } }));
  if (lock) fs.writeFileSync(path.join(rootDir, 'package-lock.json'), '{}');
  return rootDir;
}

test('requires an explicit approved HTTPS registry origin', () => {
  assert.equal(parseExplicitRegistry('https://registry.npmjs.org'), 'https://registry.npmjs.org/');
  for (const value of ['', 'http://registry.npmjs.org/', 'https://evil.example/', 'https://user:pass@registry.npmjs.org/', 'https://registry.npmjs.org/path', 'https://registry.npmjs.org/?x=1', 'https://registry.npmjs.org:8443/']) {
    assert.throws(() => parseExplicitRegistry(value));
  }
});

test('produces an isolated lockfile-capture plan without creating a lockfile', () => {
  const rootDir = fixture();
  const plan = buildLockfileAcquisitionPlan({ rootDir, registryValue: 'https://registry.npmjs.org/' });
  assert.equal(plan.status, 'PLAN_READY');
  assert.deepEqual(plan.command.slice(0, 3), ['npm', 'install', '--package-lock-only']);
  assert.ok(plan.command.includes('--ignore-scripts'));
  assert.ok(plan.command.includes('--lockfile-version=3'));
  assert.equal(plan.networkTestPerformed, false);
  assert.equal(plan.lockfileCreated, false);
  assert.equal(fs.existsSync(path.join(rootDir, 'package-lock.json')), false);
});

test('blocks when lockfile already exists rather than overwriting it', () => {
  const rootDir = fixture({ lock: true });
  const plan = buildLockfileAcquisitionPlan({ rootDir, registryValue: 'https://registry.npmjs.org/' });
  assert.equal(plan.status, 'BLOCKED');
  assert.ok(plan.blockers.includes('PACKAGE_LOCK_ALREADY_EXISTS_REQUIRES_REVIEW'));
});

test('blocks ranges and unpinned direct dependency versions', () => {
  const rootDir = fixture({ version: '^5.1.7' });
  const plan = buildLockfileAcquisitionPlan({ rootDir, registryValue: 'https://registry.npmjs.org/' });
  assert.ok(plan.blockers.includes('DIRECT_DEPENDENCY_NOT_EXACTLY_PINNED:sqlite3'));
});

test('requires explicit registry configuration in the environment resolver', () => {
  const rootDir = fixture();
  const report = resolveLockfileAcquisitionPlan(rootDir, {});
  assert.equal(report.status, 'BLOCKED');
  assert.ok(report.blockers.some(x => x.startsWith('APPROVED_REGISTRY_INVALID:')));
  assert.equal(report.lockfileCreated, false);
  assert.equal(report.npmCiExecuted, false);
});


test('blocks a candidate root that is itself a symbolic link', t => {
  const actual = fixture();
  const alias = path.join(os.tmpdir(), `rla-lock-capture-root-link-${process.pid}-${Date.now()}`);
  try { fs.symlinkSync(actual, alias, 'dir'); }
  catch (error) { t.skip(`directory symlinks unavailable: ${error.code}`); return; }
  t.after(() => { try { fs.rmSync(alias, { force: true }); } catch {} fs.rmSync(actual, { recursive: true, force: true }); });
  const plan = buildLockfileAcquisitionPlan({ rootDir: alias, registryValue: 'https://registry.npmjs.org/' });
  assert.equal(plan.status, 'BLOCKED');
  assert.ok(plan.blockers.includes('CANDIDATE_ROOT_MUST_BE_REAL_DIRECTORY'));
  assert.equal(plan.candidateRoot, null);
  assert.equal(plan.lockfileCreated, false);
});

test('blocks a package.json symbolic link without reading its target', t => {
  const rootDir = fixture();
  const realPackage = path.join(rootDir, 'package.json');
  const target = path.join(rootDir, 'package-real.json');
  fs.renameSync(realPackage, target);
  fs.symlinkSync(target, realPackage);
  t.after(() => fs.rmSync(rootDir, { recursive: true, force: true }));
  const plan = buildLockfileAcquisitionPlan({ rootDir, registryValue: 'https://registry.npmjs.org/' });
  assert.equal(plan.status, 'BLOCKED');
  assert.ok(plan.blockers.includes('PACKAGE_JSON_PATH_UNSAFE'));
  assert.equal(plan.lockfileCreated, false);
});

test('blocks a package-lock.json symbolic link rather than treating it as an existing regular lockfile', t => {
  const rootDir = fixture();
  const target = path.join(rootDir, 'outside-lock-target.json');
  fs.writeFileSync(target, '{}');
  fs.symlinkSync(target, path.join(rootDir, 'package-lock.json'));
  t.after(() => fs.rmSync(rootDir, { recursive: true, force: true }));
  const plan = buildLockfileAcquisitionPlan({ rootDir, registryValue: 'https://registry.npmjs.org/' });
  assert.equal(plan.status, 'BLOCKED');
  assert.ok(plan.blockers.includes('PACKAGE_LOCK_PATH_UNSAFE'));
  assert.equal(plan.lockfileCreated, false);
});


test('reads a regular package manifest through a no-follow file descriptor', t => {
  const rootDir = fixture();
  const packagePath = path.join(rootDir, 'package.json');
  t.after(() => fs.rmSync(rootDir, { recursive: true, force: true }));
  const result = readRegularFileNoFollow(packagePath);
  if (fs.constants.O_NOFOLLOW === undefined || fs.constants.O_NOFOLLOW === 0) {
    assert.equal(result.ok, false);
    assert.equal(result.code, 'PACKAGE_JSON_NOFOLLOW_UNAVAILABLE');
    return;
  }
  assert.equal(result.ok, true);
  assert.equal(JSON.parse(result.content).dependencies.sqlite3, '5.1.7');
});

test('no-follow reader rejects a symlink even when called directly', t => {
  const rootDir = fixture();
  const packagePath = path.join(rootDir, 'package.json');
  const target = path.join(rootDir, 'package-real.json');
  fs.renameSync(packagePath, target);
  fs.symlinkSync(target, packagePath);
  t.after(() => fs.rmSync(rootDir, { recursive: true, force: true }));
  const result = readRegularFileNoFollow(packagePath);
  assert.equal(result.ok, false);
  assert.equal(result.code, 'PACKAGE_JSON_PATH_UNSAFE');
});
