'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const { createConsistentBackup } = require('../../scripts/create-consistent-backup');
const { restoreVerifiedBackup } = require('../../scripts/restore-verified-backup');

const KEY = 'test-only-end-to-end-pipeline-key-at-least-32-bytes';
const ENV = {
  RLA_BACKUP_MANIFEST_KEY: KEY,
  RLA_RESTORE_CONFIRM: 'YES',
  RLA_RESTORE_MAINTENANCE_MODE: 'STOPPED'
};

function fakeSqlite3({ backupFailure = false, integrityFailure = false } = {}) {
  return {
    OPEN_READONLY: 1,
    Database: class {
      constructor(filename, flags, callback) {
        this.filename = filename;
        setImmediate(() => callback(null));
      }
      backup(destination, callback) {
        setImmediate(async () => {
          if (backupFailure) return callback(new Error('injected backup failure'));
          try {
            await fs.writeFile(destination, 'test-only-database-image-v1');
            callback(null);
          } catch (error) { callback(error); }
        });
      }
      get(sql, callback) {
        setImmediate(() => {
          if (integrityFailure) callback(new Error('injected integrity failure'));
          else callback(null, { integrity_check: 'ok' });
        });
      }
      all(sql, callback) { setImmediate(() => callback(null, [])); }
      close(callback) { setImmediate(() => callback(null)); }
    }
  };
}

async function fixture(t) {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'rla-pipeline-'));
  await fs.chmod(root, 0o700);
  const backupDir = path.join(root, 'backups');
  const stagingDir = path.join(root, 'staging');
  const databaseDir = path.join(root, 'database');
  for (const dir of [backupDir, stagingDir, databaseDir]) {
    await fs.mkdir(dir, { mode: 0o700 });
    await fs.chmod(dir, 0o700);
  }
  const source = path.join(databaseDir, 'source.sqlite');
  const backup = path.join(backupDir, 'nightly.sqlite');
  const manifest = path.join(backupDir, 'nightly.manifest.json');
  const target = path.join(databaseDir, 'restored.sqlite');
  await fs.writeFile(source, 'test-only-source-placeholder');
  t.after(() => fs.rm(root, { recursive: true, force: true }));
  return { root, source, backup, manifest, stagingDir, target, backupDir, databaseDir };
}

test('end-to-end offline pipeline creates, authenticates, stages, and installs a backup', async t => {
  const f = await fixture(t);
  const driver = fakeSqlite3();
  const backupResult = await createConsistentBackup({
    sourcePath: f.source, backupPath: f.backup, manifestPath: f.manifest, key: KEY, sqlite3: driver
  });
  assert.equal(backupResult.manifestVerified, true);
  const restoreResult = await restoreVerifiedBackup({
    backupPath: f.backup, manifestPath: f.manifest, stagingRoot: f.stagingDir,
    targetPath: f.target, env: ENV, sqlite3: driver
  });
  assert.equal(restoreResult.ok, true);
  assert.equal(restoreResult.stagedIntegrity.integrity, 'ok');
  assert.equal(restoreResult.installedIntegrity.integrity, 'ok');
  assert.equal(await fs.readFile(f.target, 'utf8'), 'test-only-database-image-v1');
  assert.equal((await fs.stat(f.target)).mode & 0o777, 0o600);
  assert.ok(restoreResult.stagedPath.startsWith(f.stagingDir + path.sep));
});

test('pipeline retains previous target file after successful replacement', async t => {
  const f = await fixture(t);
  await fs.writeFile(f.target, 'previous-db');
  const driver = fakeSqlite3();
  await createConsistentBackup({ sourcePath: f.source, backupPath: f.backup, manifestPath: f.manifest, key: KEY, sqlite3: driver });
  const result = await restoreVerifiedBackup({ backupPath: f.backup, manifestPath: f.manifest, stagingRoot: f.stagingDir, targetPath: f.target, env: ENV, sqlite3: driver });
  assert.ok(result.previousDatabasePath);
  assert.equal(await fs.readFile(result.previousDatabasePath, 'utf8'), 'previous-db');
  assert.equal(await fs.readFile(f.target, 'utf8'), 'test-only-database-image-v1');
});

test('tampered manifest fails closed and leaves existing target unchanged', async t => {
  const f = await fixture(t);
  await fs.writeFile(f.target, 'keep-existing-db');
  const driver = fakeSqlite3();
  await createConsistentBackup({ sourcePath: f.source, backupPath: f.backup, manifestPath: f.manifest, key: KEY, sqlite3: driver });
  const manifest = JSON.parse(await fs.readFile(f.manifest, 'utf8'));
  manifest.sha256 = '0'.repeat(64);
  await fs.writeFile(f.manifest, JSON.stringify(manifest));
  await assert.rejects(() => restoreVerifiedBackup({ backupPath: f.backup, manifestPath: f.manifest, stagingRoot: f.stagingDir, targetPath: f.target, env: ENV, sqlite3: driver }), /authentication failed/);
  assert.equal(await fs.readFile(f.target, 'utf8'), 'keep-existing-db');
});

test('restore blocks when SQLite WAL sidecar exists', async t => {
  const f = await fixture(t);
  const driver = fakeSqlite3();
  await createConsistentBackup({ sourcePath: f.source, backupPath: f.backup, manifestPath: f.manifest, key: KEY, sqlite3: driver });
  await fs.writeFile(`${f.target}-wal`, 'sidecar');
  await assert.rejects(() => restoreVerifiedBackup({ backupPath: f.backup, manifestPath: f.manifest, stagingRoot: f.stagingDir, targetPath: f.target, env: ENV, sqlite3: driver }), /sidecar/);
  await assert.rejects(() => fs.lstat(f.target), { code: 'ENOENT' });
});

test('restore fails closed when operator attestations are missing', async t => {
  const f = await fixture(t);
  await assert.rejects(() => restoreVerifiedBackup({
    backupPath: f.backup, manifestPath: f.manifest, stagingRoot: f.stagingDir, targetPath: f.target,
    env: {}
  }), /RLA_RESTORE_CONFIRM=YES/);
  await assert.rejects(() => fs.lstat(f.target), { code: 'ENOENT' });
});
