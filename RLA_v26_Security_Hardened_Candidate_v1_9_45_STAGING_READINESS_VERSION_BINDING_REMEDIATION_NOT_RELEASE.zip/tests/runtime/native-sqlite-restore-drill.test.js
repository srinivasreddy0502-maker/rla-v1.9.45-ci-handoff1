'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const { safeRunId, loadNativeSqlite3, runNativeRestoreDrill, validateDrillConsistency, preflightRestoreDrill, acquireRestoreDrillLock, enforcePrivateArtifact } = require('../../app/native-sqlite-restore-drill');
const crypto = require('node:crypto');
const digest = value => crypto.createHash('sha256').update(value).digest('hex');
const valid = { integrity: 'ok', foreignKeyViolations: 0, userTableCount: 2, userTables: ['cases','parcels'] };
function consistencyArgs(overrides={}) {
  return { sourceHashBefore:digest('source'), sourceHashAfter:digest('source'), backupHash:digest('backup'), restoredHash:digest('backup'), sourceValidation:valid, backupValidation:valid, restoredValidation:valid, ...overrides };
}
test('restore evidence consistency accepts stable source, matching backup hashes and matching table inventories', () => {
  assert.deepEqual(validateDrillConsistency(consistencyArgs()), { consistent:true, sourceStable:true, backupMatchesRestored:true, tableInventoryMatches:true });
});
test('restore evidence consistency blocks source changes during the drill', () => {
  assert.throws(() => validateDrillConsistency(consistencyArgs({ sourceHashAfter:digest('changed source') })), /Source database changed/);
});
test('restore evidence consistency blocks backup/restored hash mismatch', () => {
  assert.throws(() => validateDrillConsistency(consistencyArgs({ restoredHash:digest('different') })), /hash differs/);
});
test('restore evidence consistency blocks schema/table inventory drift', () => {
  assert.throws(() => validateDrillConsistency(consistencyArgs({ restoredValidation:{...valid,userTables:['other','tables']} })), /table inventories differ/);
});
test('restore evidence consistency blocks invalid integrity and malformed hashes', () => {
  assert.throws(() => validateDrillConsistency(consistencyArgs({ backupValidation:{...valid,integrity:'corrupt'} })), /integrity or foreign-key/);
  assert.throws(() => validateDrillConsistency(consistencyArgs({ sourceHashBefore:'bad' })), /SHA-256 evidence/);
});

test('validates restore drill run IDs', () => {
  assert.equal(safeRunId('restore-2026-001'), 'restore-2026-001');
  assert.throws(() => safeRunId('../restore'), /safe filename/);
  assert.throws(() => safeRunId(''), /safe filename/);
});
test('native driver preflight reports a typed block when the package is unavailable', t => {
  try { loadNativeSqlite3(); }
  catch (err) {
    if (err.code === 'NATIVE_SQLITE3_DRIVER_UNAVAILABLE') return;
    throw err;
  }
  t.diagnostic('Native sqlite3 is installed in this environment; absence-path test not applicable.');
});
test('refuses missing source DB before attempting native driver load', async t => {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'rla-native-restore-'));
  t.after(() => fs.rm(root, { recursive: true, force: true }));
  await fs.mkdir(path.join(root, 'evidence'), { mode: 0o700 });
  await assert.rejects(() => runNativeRestoreDrill({ sourceDbPath: path.join(root, 'missing.db'), evidenceDir: path.join(root, 'evidence'), runId: 'run-1' }), /ENOENT/);
});
test('refuses unsafe run IDs before any filesystem writes', async t => {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'rla-native-restore-'));
  t.after(() => fs.rm(root, { recursive: true, force: true }));
  await fs.mkdir(path.join(root, 'evidence'), { mode: 0o700 });
  const source = path.join(root, 'source.db');
  await fs.writeFile(source, 'not-a-database');
  await assert.rejects(() => runNativeRestoreDrill({ sourceDbPath: source, evidenceDir: path.join(root, 'evidence'), runId: '../bad' }), /safe filename/);
  assert.deepEqual(await fs.readdir(path.join(root, 'evidence')), []);
});

test('restore drill preflight refuses SQLite WAL sidecars rather than hashing only the main file', async t => {
  const os = require('node:os');
  const fs = require('node:fs/promises');
  const path = require('node:path');
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'rla-wal-preflight-'));
  t.after(() => fs.rm(root, {recursive:true,force:true}));
  const source = path.join(root, 'source.db');
  const evidence = path.join(root, 'evidence');
  await fs.writeFile(source, 'placeholder');
  await fs.mkdir(evidence, {mode:0o700});
  await fs.writeFile(source + '-wal', 'wal-content');
  await assert.rejects(() => preflightRestoreDrill({sourceDbPath:source,evidenceDir:evidence,runId:'wal-case'}), /sidecar exists/);
});
test('restore drill preflight refuses output overwrite and symlink sidecars', async t => {
  const os = require('node:os');
  const fs = require('node:fs/promises');
  const path = require('node:path');
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'rla-output-preflight-'));
  t.after(() => fs.rm(root, {recursive:true,force:true}));
  const source = path.join(root, 'source.db');
  const evidence = path.join(root, 'evidence');
  await fs.writeFile(source, 'placeholder');
  await fs.mkdir(evidence, {mode:0o700});
  await fs.writeFile(path.join(evidence,'collision.sqlite-backup.db'), 'existing');
  await assert.rejects(() => preflightRestoreDrill({sourceDbPath:source,evidenceDir:evidence,runId:'collision'}), /already exists/);
  await fs.unlink(path.join(evidence,'collision.sqlite-backup.db'));
  const other = path.join(root,'other'); await fs.writeFile(other,'wal');
  await fs.symlink(other,source+'-shm');
  await assert.rejects(() => preflightRestoreDrill({sourceDbPath:source,evidenceDir:evidence,runId:'symlink'}), /sidecar .* not a regular file/);
});

test('sidecar inspection returns metadata for regular sidecars and rejects symlinks', async t => {
  const os = require('node:os');
  const fs = require('node:fs/promises');
  const path = require('node:path');
  const { inspectSqliteSidecars } = require('../../app/native-sqlite-restore-drill');
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'rla-sidecar-inspect-'));
  t.after(() => fs.rm(root, {recursive:true,force:true}));
  const source = path.join(root, 'source.db');
  await fs.writeFile(source, 'db');
  await fs.writeFile(source + '-wal', 'wal-data');
  const sidecars = await inspectSqliteSidecars(source);
  assert.equal(sidecars.length, 1);
  assert.equal(sidecars[0].size, 8);
  await fs.unlink(source + '-wal');
  const target = path.join(root,'external'); await fs.writeFile(target,'shm');
  await fs.symlink(target,source+'-shm');
  await assert.rejects(() => inspectSqliteSidecars(source), /not a regular file/);
});
test('output collision checker refuses any pre-existing output and accepts an empty private directory', async t => {
  const os = require('node:os');
  const fs = require('node:fs/promises');
  const path = require('node:path');
  const { checkOutputCollisions } = require('../../app/native-sqlite-restore-drill');
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'rla-collision-check-'));
  t.after(() => fs.rm(root, {recursive:true,force:true}));
  await fs.chmod(root,0o700);
  const outputs = await checkOutputCollisions(root,'clean-run');
  assert.equal(outputs.length,3);
  await fs.writeFile(path.join(root,'blocked.sqlite-restored.db'),'x');
  await assert.rejects(() => checkOutputCollisions(root,'blocked'), /already exists/);
});


test('restore drill lock serializes concurrent runs and releases only its own lock', async t => {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'rla-restore-lock-'));
  t.after(() => fs.rm(root, {recursive:true,force:true}));
  await fs.chmod(root, 0o700);
  const release = await acquireRestoreDrillLock(root, 'serial-run');
  assert.equal((await fs.readdir(root)).includes('serial-run.restore-drill.lock'), true);
  await assert.rejects(() => acquireRestoreDrillLock(root, 'serial-run'), /already running or stale lock/);
  await release();
  assert.equal((await fs.readdir(root)).includes('serial-run.restore-drill.lock'), false);
  const releaseAgain = await acquireRestoreDrillLock(root, 'serial-run');
  await releaseAgain();
});

test('restore drill lock fails closed on an existing stale lock without deleting it', async t => {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'rla-restore-stale-lock-'));
  t.after(() => fs.rm(root, {recursive:true,force:true}));
  await fs.chmod(root, 0o700);
  const lock = path.join(root, 'stale-run.restore-drill.lock');
  await fs.writeFile(lock, '{"type":"RLA_NATIVE_SQLITE_RESTORE_DRILL_LOCK"}', {mode:0o600});
  await assert.rejects(() => acquireRestoreDrillLock(root, 'stale-run'), /already running or stale lock/);
  assert.equal((await fs.readFile(lock, 'utf8')).includes('RLA_NATIVE_SQLITE_RESTORE_DRILL_LOCK'), true);
});

test('restore drill preflight canonicalizes ancestor symlinks before source/evidence containment checks', async t => {
  if (process.platform === 'win32') { t.skip('Symlink creation permissions vary on Windows'); return; }
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'rla-realpath-preflight-'));
  t.after(() => fs.rm(root, {recursive:true,force:true}));
  const actual = path.join(root, 'actual');
  const evidence = path.join(actual, 'evidence');
  await fs.mkdir(evidence, {recursive:true,mode:0o700});
  await fs.chmod(actual,0o700); await fs.chmod(evidence,0o700);
  const source = path.join(evidence, 'source.db');
  await fs.writeFile(source, 'placeholder');
  const alias = path.join(root, 'alias');
  await fs.symlink(actual, alias, 'dir');
  await assert.rejects(
    () => preflightRestoreDrill({sourceDbPath:path.join(alias,'evidence','source.db'),evidenceDir:evidence,runId:'alias-contained'}),
    /source database must be outside evidenceDir/
  );
});

test('restore drill preflight uses canonical evidence path when checking aliased source ancestry', async t => {
  if (process.platform === 'win32') { t.skip('Symlink creation permissions vary on Windows'); return; }
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'rla-realpath-evidence-'));
  t.after(() => fs.rm(root, {recursive:true,force:true}));
  const actual = path.join(root, 'actual');
  const evidence = path.join(actual, 'evidence');
  await fs.mkdir(evidence, {recursive:true,mode:0o700});
  await fs.chmod(actual,0o700); await fs.chmod(evidence,0o700);
  const source = path.join(root, 'source.db');
  await fs.writeFile(source, 'placeholder');
  const aliasParent = path.join(root, 'alias-parent');
  await fs.symlink(actual, aliasParent, 'dir');
  const result = await preflightRestoreDrill({sourceDbPath:source,evidenceDir:path.join(aliasParent,'evidence'),runId:'canonical-evidence'});
  assert.equal(result.evidence, await fs.realpath(evidence));
});


test('restore-drill artifacts are tightened to private permissions and symlinks are rejected', async t => {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'rla-private-artifact-'));
  t.after(() => fs.rm(root, {recursive:true,force:true}));
  const artifact = path.join(root, 'backup.db');
  await fs.writeFile(artifact, 'test artifact', {mode:0o644});
  await enforcePrivateArtifact(artifact, 'backup artifact');
  const st = await fs.stat(artifact);
  if (process.platform !== 'win32') assert.equal(st.mode & 0o777, 0o600);
  if (process.platform !== 'win32') {
    const external = path.join(root, 'external.db');
    await fs.writeFile(external, 'external');
    const link = path.join(root, 'link.db');
    await fs.symlink(external, link);
    await assert.rejects(() => enforcePrivateArtifact(link, 'backup artifact'), /regular non-symlink/);
  }
});
