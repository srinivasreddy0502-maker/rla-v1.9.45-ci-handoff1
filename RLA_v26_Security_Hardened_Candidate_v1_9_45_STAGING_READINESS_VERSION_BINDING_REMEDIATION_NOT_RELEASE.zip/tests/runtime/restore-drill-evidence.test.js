'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { verifyRestoreDrillEvidence } = require('../../app/restore-drill-evidence');
const hash = b => crypto.createHash('sha256').update(b).digest('hex');
async function fixture(t) {
 const root = await fs.mkdtemp(path.join(os.tmpdir(),'rla-restore-evidence-')); await fs.chmod(root,0o700); t.after(()=>fs.rm(root,{recursive:true,force:true}));
 const backup=Buffer.from('verified backup bytes'), restored=Buffer.from('verified backup bytes');
 await fs.writeFile(path.join(root,'backup.db'),backup,{mode:0o600}); await fs.writeFile(path.join(root,'restored.db'),restored,{mode:0o600});
 const v={integrity:'ok',foreignKeyViolations:0,userTableCount:2,userTables:['cases','parcels']};
 const m={schemaVersion:1,type:'RLA_NATIVE_SQLITE_RESTORE_DRILL',runId:'drill-001',driver:'npm sqlite3 native',result:'PASS',source:{sha256Before:hash('source'),validation:v},backup:{file:'backup.db',sha256:hash(backup),validation:v},restored:{file:'restored.db',sha256:hash(restored),validation:v}};
 const mp=path.join(root,'drill.json'); await fs.writeFile(mp,JSON.stringify(m),{mode:0o600});
 return {root,mp,m, args:{manifestPath:mp,evidenceDir:root,reviewer:'Independent Reviewer',reviewedAt:'2026-10-12T12:00:00Z',approvalReference:'SEC-REVIEW-001'}};
}
test('valid evidence is accepted for independent review but never grants release authority',async t=>{const f=await fixture(t);const r=await verifyRestoreDrillEvidence(f.args);assert.equal(r.status,'EVIDENCE_VALIDATED');assert.equal(r.releaseGate,'PENDING_INDEPENDENT_REVIEW');assert.equal(r.releaseAuthorityGranted,false);});
test('missing reviewer/approval metadata fails closed',async t=>{const f=await fixture(t);const r=await verifyRestoreDrillEvidence({...f.args,reviewer:'',approvalReference:''});assert.equal(r.status,'BLOCKED');assert.equal(r.releaseAuthorityGranted,false);});
test('blocked or adapter-based manifests cannot qualify as native restore evidence',async t=>{const f=await fixture(t);f.m.result='BLOCKED';await fs.writeFile(f.mp,JSON.stringify(f.m));assert.equal((await verifyRestoreDrillEvidence(f.args)).status,'BLOCKED');});
test('backup and restored hashes must match and artifacts must be real files',async t=>{const f=await fixture(t);f.m.restored.sha256=hash('other');await fs.writeFile(f.mp,JSON.stringify(f.m));assert.equal((await verifyRestoreDrillEvidence(f.args)).reason,'RESTORED_COPY_HASH_MISMATCH');});
test('symlink manifest is rejected',async t=>{const f=await fixture(t);await fs.rename(f.mp,f.mp+'.real');await fs.symlink(f.mp+'.real',f.mp);assert.equal((await verifyRestoreDrillEvidence(f.args)).reason,'MANIFEST_NOT_REGULAR_FILE');});
