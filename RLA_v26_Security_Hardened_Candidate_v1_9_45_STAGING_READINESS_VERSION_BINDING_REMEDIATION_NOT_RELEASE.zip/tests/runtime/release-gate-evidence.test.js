'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { REQUIRED_GATES, MAX_REVIEW_AGE_MS, MAX_MANIFEST_BYTES, MAX_JSON_DEPTH, MAX_JSON_NODES, evaluateReleaseGates, isValidReviewTimestamp, parseJsonNoDuplicateKeys } = require('../../app/release-gate-evidence');
const digest = b => crypto.createHash('sha256').update(b).digest('hex');
async function fixture(t) {
 const base = await fs.mkdtemp(path.join(os.tmpdir(),'rla-release-gates-')); t.after(()=>fs.rm(base,{recursive:true,force:true}));
 const evidenceRoot=path.join(base,'evidence'); await fs.mkdir(evidenceRoot,{mode:0o700});
 const manifestPath=path.join(base,'manifest.json');
 const manifest={schemaVersion:1,candidateVersion:'1.6.9',releaseTrack:'NOT_RELEASE',gates:REQUIRED_GATES.map(gateId=>({gateId,status:'BLOCKED',reason:'REAL_EVIDENCE_REQUIRED'}))};
 await fs.writeFile(manifestPath,JSON.stringify(manifest,null,2)+'\n',{mode:0o600});
 return {base,evidenceRoot,manifestPath,manifest};
}
test('default manifest fails closed and never grants release authority', async t=>{
 const f=await fixture(t); const r=await evaluateReleaseGates(f);
 assert.equal(r.releaseStatus,'RELEASE_BLOCKED'); assert.equal(r.releaseAuthorityGranted,false); assert.equal(r.blockedGateCount,8); assert.equal(r.passedGateCount,0);
});
test('requires real evidence file, digest, reviewer, timestamp and approval reference', async t=>{
 const f=await fixture(t); const bytes=Buffer.from('independent evidence sample\n'); await fs.writeFile(path.join(f.evidenceRoot,'gate.txt'),bytes,{mode:0o600});
 f.manifest.gates[0]={gateId:REQUIRED_GATES[0],status:'PASS',evidenceFile:'gate.txt',sha256:digest(bytes),reviewedBy:'Independent reviewer',reviewedAt:'2026-10-12T10:00:00Z',approvalRef:'TEST-APPROVAL-001'};
 await fs.writeFile(f.manifestPath,JSON.stringify(f.manifest)); const r=await evaluateReleaseGates(f);
 assert.equal(r.gates[0].status,'PASS'); assert.equal(r.releaseAuthorityGranted,false); assert.equal(r.releaseStatus,'RELEASE_BLOCKED');
});
test('blocks tampered evidence even if manifest claims PASS', async t=>{
 const f=await fixture(t); await fs.writeFile(path.join(f.evidenceRoot,'gate.txt'),'original',{mode:0o600});
 f.manifest.gates[0]={gateId:REQUIRED_GATES[0],status:'PASS',evidenceFile:'gate.txt',sha256:digest(Buffer.from('original')),reviewedBy:'Reviewer',reviewedAt:'2026-10-12T10:00:00Z',approvalRef:'APP-1'};
 await fs.writeFile(f.manifestPath,JSON.stringify(f.manifest)); await fs.writeFile(path.join(f.evidenceRoot,'gate.txt'),'tampered');
 const r=await evaluateReleaseGates(f); assert.equal(r.gates[0].status,'BLOCKED'); assert.equal(r.gates[0].reason,'EVIDENCE_DIGEST_MISMATCH');
});
test('rejects path traversal and malformed evidence metadata', async t=>{
 const f=await fixture(t); f.manifest.gates[0]={gateId:REQUIRED_GATES[0],status:'PASS',evidenceFile:'../outside',sha256:'a'.repeat(64),reviewedBy:'Reviewer',reviewedAt:'2026-10-12T10:00:00Z',approvalRef:'APP-1'};
 await fs.writeFile(f.manifestPath,JSON.stringify(f.manifest)); const r=await evaluateReleaseGates(f);
 assert.equal(r.gates[0].status,'BLOCKED'); assert.equal(r.gates[0].reason,'EVIDENCE_METADATA_INVALID');
});
test('blocks missing gate IDs and invalid manifest track', async t=>{
 const f=await fixture(t); f.manifest.gates=f.manifest.gates.slice(1); await fs.writeFile(f.manifestPath,JSON.stringify(f.manifest));
 let r=await evaluateReleaseGates(f); assert.equal(r.gates[0].reason,'REQUIRED_GATE_MISSING');
 f.manifest.releaseTrack='RELEASE'; await fs.writeFile(f.manifestPath,JSON.stringify(f.manifest));
 await assert.rejects(()=>evaluateReleaseGates(f),/schema\/track is invalid/);
});
test('blocks symlink evidence files even when the target digest matches', async t=>{
 const f=await fixture(t); const bytes=Buffer.from('evidence bytes'); const target=path.join(f.base,'outside.txt');
 await fs.writeFile(target,bytes,{mode:0o600}); await fs.symlink(target,path.join(f.evidenceRoot,'gate.txt'));
 f.manifest.gates[0]={gateId:REQUIRED_GATES[0],status:'PASS',evidenceFile:'gate.txt',sha256:digest(bytes),reviewedBy:'Reviewer',reviewedAt:'2026-10-12T10:00:00Z',approvalRef:'APP-SYMLINK'};
 await fs.writeFile(f.manifestPath,JSON.stringify(f.manifest)); const r=await evaluateReleaseGates(f);
 assert.equal(r.gates[0].status,'BLOCKED'); assert.equal(r.gates[0].reason,'EVIDENCE_SYMLINK_BLOCKED');
});
test('blocks symlinked intermediate evidence directories', async t=>{
 const f=await fixture(t); const external=path.join(f.base,'external'); await fs.mkdir(external,{mode:0o700});
 const bytes=Buffer.from('nested evidence'); await fs.writeFile(path.join(external,'gate.txt'),bytes,{mode:0o600}); await fs.symlink(external,path.join(f.evidenceRoot,'nested'));
 f.manifest.gates[0]={gateId:REQUIRED_GATES[0],status:'PASS',evidenceFile:'nested/gate.txt',sha256:digest(bytes),reviewedBy:'Reviewer',reviewedAt:'2026-10-12T10:00:00Z',approvalRef:'APP-NESTED-SYMLINK'};
 await fs.writeFile(f.manifestPath,JSON.stringify(f.manifest)); const r=await evaluateReleaseGates(f);
 assert.equal(r.gates[0].status,'BLOCKED'); assert.equal(r.gates[0].reason,'EVIDENCE_SYMLINK_BLOCKED');
});
test('rejects a symlinked release-gate manifest', async t=>{
 const f=await fixture(t); const real=path.join(f.base,'manifest.real.json'); await fs.rename(f.manifestPath,real); await fs.symlink(real,f.manifestPath);
 await assert.rejects(()=>evaluateReleaseGates(f),/manifestPath must be a regular non-symlink file/);
});


test('blocks evidence files with multiple hard links', async t=>{
 const f=await fixture(t); const bytes=Buffer.from('hardlinked evidence'); const file=path.join(f.evidenceRoot,'gate.txt');
 await fs.writeFile(file,bytes,{mode:0o600}); await fs.link(file,path.join(f.base,'external-hardlink.txt'));
 f.manifest.gates[0]={gateId:REQUIRED_GATES[0],status:'PASS',evidenceFile:'gate.txt',sha256:digest(bytes),reviewedBy:'Reviewer',reviewedAt:'2026-10-12T10:00:00Z',approvalRef:'APP-HARDLINK'};
 await fs.writeFile(f.manifestPath,JSON.stringify(f.manifest)); const r=await evaluateReleaseGates(f);
 assert.equal(r.gates[0].status,'BLOCKED'); assert.equal(r.gates[0].reason,'EVIDENCE_HARDLINK_BLOCKED');
});

test('blocks evidence files with non-private permissions on POSIX', async t=>{
 if(process.platform==='win32') return;
 const f=await fixture(t); const bytes=Buffer.from('permissive evidence'); const file=path.join(f.evidenceRoot,'gate.txt');
 await fs.writeFile(file,bytes,{mode:0o644}); await fs.chmod(file,0o644);
 f.manifest.gates[0]={gateId:REQUIRED_GATES[0],status:'PASS',evidenceFile:'gate.txt',sha256:digest(bytes),reviewedBy:'Reviewer',reviewedAt:'2026-10-12T10:00:00Z',approvalRef:'APP-PERMISSIVE'};
 await fs.writeFile(f.manifestPath,JSON.stringify(f.manifest)); const r=await evaluateReleaseGates(f);
 assert.equal(r.gates[0].status,'BLOCKED'); assert.equal(r.gates[0].reason,'EVIDENCE_PERMISSIONS_NOT_PRIVATE');
});

test('rejects unknown gate IDs instead of silently ignoring manifest entries', async t=>{
 const f=await fixture(t); f.manifest.gates.push({gateId:'unrecognized_gate',status:'PASS',evidenceFile:'ignored.txt',sha256:'a'.repeat(64),reviewedBy:'Reviewer',reviewedAt:'2026-10-12T10:00:00Z',approvalRef:'APP-UNKNOWN'});
 await fs.writeFile(f.manifestPath,JSON.stringify(f.manifest));
 await assert.rejects(()=>evaluateReleaseGates(f),/unknown gateId/);
});

test('rejects duplicate gate IDs even when duplicate entry claims PASS', async t=>{
 const f=await fixture(t); f.manifest.gates.push({...f.manifest.gates[0],status:'PASS'});
 await fs.writeFile(f.manifestPath,JSON.stringify(f.manifest));
 await assert.rejects(()=>evaluateReleaseGates(f),/invalid or duplicate gateId/);
});


test('blocks nested evidence directories with non-private permissions on POSIX', async t=>{
 if(process.platform==='win32') return;
 const f=await fixture(t); const nested=path.join(f.evidenceRoot,'nested'); await fs.mkdir(nested,{mode:0o700});
 await fs.chmod(nested,0o755);
 const bytes=Buffer.from('nested permissive evidence'); await fs.writeFile(path.join(nested,'gate.txt'),bytes,{mode:0o600});
 f.manifest.gates[0]={gateId:REQUIRED_GATES[0],status:'PASS',evidenceFile:'nested/gate.txt',sha256:digest(bytes),reviewedBy:'Reviewer',reviewedAt:'2026-10-12T10:00:00Z',approvalRef:'APP-DIR-PERM'};
 await fs.writeFile(f.manifestPath,JSON.stringify(f.manifest)); const r=await evaluateReleaseGates(f);
 assert.equal(r.gates[0].status,'BLOCKED'); assert.equal(r.gates[0].reason,'EVIDENCE_DIRECTORY_PERMISSIONS_NOT_PRIVATE');
});


test('rejects ambiguous or non-canonical review timestamps', async t=>{
 const f=await fixture(t); const bytes=Buffer.from('timestamp evidence'); await fs.writeFile(path.join(f.evidenceRoot,'gate.txt'),bytes,{mode:0o600});
 f.manifest.gates[0]={gateId:REQUIRED_GATES[0],status:'PASS',evidenceFile:'gate.txt',sha256:digest(bytes),reviewedBy:'Reviewer',reviewedAt:'2026-10-12 10:00:00',approvalRef:'APP-TIME-AMBIGUOUS'};
 await fs.writeFile(f.manifestPath,JSON.stringify(f.manifest)); const r=await evaluateReleaseGates(f);
 assert.equal(r.gates[0].status,'BLOCKED'); assert.equal(r.gates[0].reason,'EVIDENCE_METADATA_INVALID');
});

test('blocks review timestamps in the future', async t=>{
 const f=await fixture(t); const bytes=Buffer.from('future timestamp evidence'); await fs.writeFile(path.join(f.evidenceRoot,'gate.txt'),bytes,{mode:0o600});
 const future=new Date(Date.now()+60_000).toISOString().replace(/\.\d{3}Z$/,'Z');
 f.manifest.gates[0]={gateId:REQUIRED_GATES[0],status:'PASS',evidenceFile:'gate.txt',sha256:digest(bytes),reviewedBy:'Reviewer',reviewedAt:future,approvalRef:'APP-TIME-FUTURE'};
 await fs.writeFile(f.manifestPath,JSON.stringify(f.manifest)); const r=await evaluateReleaseGates(f);
 assert.equal(r.gates[0].status,'BLOCKED'); assert.equal(r.gates[0].reason,'EVIDENCE_REVIEW_TIMESTAMP_FUTURE');
});


test('blocks stale release-gate review evidence older than the 90-day policy window', async t=>{
 const f=await fixture(t); const bytes=Buffer.from('stale review evidence'); await fs.writeFile(path.join(f.evidenceRoot,'gate.txt'),bytes,{mode:0o600});
 const stale=new Date(Date.now()-MAX_REVIEW_AGE_MS-1000).toISOString().replace(/\.\d{3}Z$/,'Z');
 f.manifest.gates[0]={gateId:REQUIRED_GATES[0],status:'PASS',evidenceFile:'gate.txt',sha256:digest(bytes),reviewedBy:'Reviewer',reviewedAt:stale,approvalRef:'APP-TIME-STALE'};
 await fs.writeFile(f.manifestPath,JSON.stringify(f.manifest)); const r=await evaluateReleaseGates(f);
 assert.equal(r.gates[0].status,'BLOCKED'); assert.equal(r.gates[0].reason,'EVIDENCE_REVIEW_STALE'); assert.equal(r.releaseAuthorityGranted,false);
});

test('review timestamp freshness policy accepts a timestamp inside the age boundary',()=>{
 const now=Date.parse('2026-10-12T12:00:00Z');
 const recent=new Date(now-MAX_REVIEW_AGE_MS+1000).toISOString().replace(/\.\d{3}Z$/,'Z');
 assert.equal(isValidReviewTimestamp(recent,now),true);
});


test('rejects oversized release-gate manifests before parsing', async t=>{
 const f=await fixture(t); await fs.writeFile(f.manifestPath, Buffer.alloc(MAX_MANIFEST_BYTES + 1, 0x20), {mode:0o600});
 await assert.rejects(()=>evaluateReleaseGates(f), /RLA_FILE_TOO_LARGE/);
});



test('rejects duplicate JSON keys in the raw manifest instead of accepting last-key-wins parsing', async t=>{
 const f=await fixture(t);
 const raw=JSON.stringify(f.manifest).replace('\"schemaVersion\":1,','\"schemaVersion\":1,\"schemaVersion\":1,');
 assert.notEqual(raw,JSON.stringify(f.manifest));
 await fs.writeFile(f.manifestPath,raw,{mode:0o600});
 await assert.rejects(()=>evaluateReleaseGates(f),/duplicate object keys/);
});

test('rejects duplicate JSON keys nested inside a gate record', async t=>{
 const f=await fixture(t);
 const raw=JSON.stringify(f.manifest).replace('\"gateId\":\"native_sqlite3_backup_restore\",','\"gateId\":\"native_sqlite3_backup_restore\",\"gateId\":\"native_sqlite3_backup_restore\",');
 assert.notEqual(raw,JSON.stringify(f.manifest));
 await fs.writeFile(f.manifestPath,raw,{mode:0o600});
 await assert.rejects(()=>evaluateReleaseGates(f),/duplicate object keys/);
});


test('strict manifest parser rejects excessive JSON nesting before stack exhaustion', async t=>{
 const f=await fixture(t);
 const raw='['.repeat(MAX_JSON_DEPTH + 1)+'0'+']'.repeat(MAX_JSON_DEPTH + 1);
 await fs.writeFile(f.manifestPath,raw,{mode:0o600});
 await assert.rejects(()=>evaluateReleaseGates(f),/manifest JSON is invalid/);
});

test('strict manifest parser accepts JSON at the configured nesting boundary',()=>{
 const raw='['.repeat(MAX_JSON_DEPTH)+'0'+']'.repeat(MAX_JSON_DEPTH);
 assert.doesNotThrow(()=>parseJsonNoDuplicateKeys(raw));
});


test('strict manifest parser rejects excessive JSON node count before building an unbounded object graph',()=>{
 const raw='['+Array(MAX_JSON_NODES).fill('0').join(',')+']';
 assert.throws(()=>parseJsonNoDuplicateKeys(raw), err=>err && err.code==='RLA_JSON_MAX_NODES');
});

test('strict manifest parser accepts JSON at the configured node-count boundary',()=>{
 const raw='['+Array(MAX_JSON_NODES-1).fill('0').join(',')+']';
 assert.doesNotThrow(()=>parseJsonNoDuplicateKeys(raw));
});


test('strict manifest parser rejects UTF-8 BOM instead of silently normalizing bytes', async t=>{
 const f=await fixture(t);
 const raw=Buffer.concat([Buffer.from([0xef,0xbb,0xbf]),Buffer.from(JSON.stringify(f.manifest),'utf8')]);
 await fs.writeFile(f.manifestPath,raw,{mode:0o600});
 await assert.rejects(()=>evaluateReleaseGates(f),/manifest JSON is invalid/);
});

test('strict manifest parser rejects a string-leading BOM as well as byte-leading BOM',()=>{
 assert.throws(()=>parseJsonNoDuplicateKeys('\uFEFF{}'), err=>err && err.code==='RLA_JSON_BOM_NOT_ALLOWED');
});

test('strict manifest parser rejects lone high and low UTF-16 surrogates in JSON string values',()=>{
 assert.throws(()=>parseJsonNoDuplicateKeys('{"value":"\\uD800"}'), err=>err && err.code==='RLA_JSON_LONE_SURROGATE');
 assert.throws(()=>parseJsonNoDuplicateKeys('{"value":"\\uDC00"}'), err=>err && err.code==='RLA_JSON_LONE_SURROGATE');
});

test('strict manifest parser rejects lone surrogates in object keys but accepts valid surrogate pairs',()=>{
 assert.throws(()=>parseJsonNoDuplicateKeys('{"\\uD800":1}'), err=>err && err.code==='RLA_JSON_LONE_SURROGATE');
 assert.doesNotThrow(()=>parseJsonNoDuplicateKeys('{"value":"\\uD83D\\uDE80"}'));
});

test('strict manifest parser enforces the byte-size limit for direct string callers',()=>{
 const raw=' '.repeat(MAX_MANIFEST_BYTES+1);
 assert.throws(()=>parseJsonNoDuplicateKeys(raw), err=>err && err.code==='RLA_MANIFEST_TOO_LARGE');
});

test('strict manifest parser enforces the byte-size limit for direct Buffer callers',()=>{
 const raw=Buffer.alloc(MAX_MANIFEST_BYTES+1,0x20);
 assert.throws(()=>parseJsonNoDuplicateKeys(raw), err=>err && err.code==='RLA_MANIFEST_TOO_LARGE');
});

test('strict manifest parser rejects unsupported input types instead of coercing them',()=>{
 assert.throws(()=>parseJsonNoDuplicateKeys({toString(){return '{}';}}), err=>err && err.code==='RLA_JSON_INPUT_TYPE_INVALID');
});



test('strict manifest parser rejects numeric exponents that overflow to Infinity',()=>{
 assert.throws(()=>parseJsonNoDuplicateKeys('1e400'), err=>err && err.code==='RLA_JSON_NUMBER_NOT_FINITE');
 assert.throws(()=>parseJsonNoDuplicateKeys('{\"value\":-1e999}'), err=>err && err.code==='RLA_JSON_NUMBER_NOT_FINITE');
});

test('strict manifest parser accepts finite exponent values within safe integer range',()=>{
 assert.equal(parseJsonNoDuplicateKeys('1e5'),100000);
 assert.equal(parseJsonNoDuplicateKeys('{\"value\":-2.5e2}').value,-250);
});

test('strict manifest parser rejects unsafe integer precision loss',()=>{
 assert.throws(()=>parseJsonNoDuplicateKeys('9007199254740992'), err=>err && err.code==='RLA_JSON_INTEGER_NOT_SAFE');
 assert.throws(()=>parseJsonNoDuplicateKeys('9007199254740993e0'), err=>err && err.code==='RLA_JSON_INTEGER_NOT_SAFE');
 assert.throws(()=>parseJsonNoDuplicateKeys('1e300'), err=>err && err.code==='RLA_JSON_INTEGER_NOT_SAFE');
});

test('strict manifest parser accepts safe integer boundaries',()=>{
 assert.equal(parseJsonNoDuplicateKeys('9007199254740991'), Number.MAX_SAFE_INTEGER);
 assert.equal(parseJsonNoDuplicateKeys('-9007199254740991'), Number.MIN_SAFE_INTEGER);
});


test('strict manifest parser rejects non-zero numeric tokens that underflow to zero',()=>{
 assert.throws(()=>parseJsonNoDuplicateKeys('1e-400'), err=>err && err.code==='RLA_JSON_NUMBER_UNDERFLOW');
 assert.throws(()=>parseJsonNoDuplicateKeys('{"value":-1e-999}'), err=>err && err.code==='RLA_JSON_NUMBER_UNDERFLOW');
});

test('strict manifest parser preserves explicit zero values at extreme exponents',()=>{
 assert.equal(parseJsonNoDuplicateKeys('0e-999'), 0);
 assert.equal(parseJsonNoDuplicateKeys('-0'), -0);
});


test('strict manifest parser rejects finite decimal tokens that lose precision',()=>{
 assert.throws(()=>parseJsonNoDuplicateKeys('0.10000000000000001'), err=>err && err.code==='RLA_JSON_NUMBER_PRECISION_LOSS');
 assert.throws(()=>parseJsonNoDuplicateKeys('{\"value\":1.0000000000000001}'), err=>err && err.code==='RLA_JSON_NUMBER_PRECISION_LOSS');
 assert.throws(()=>parseJsonNoDuplicateKeys('4e-324'), err=>err && err.code==='RLA_JSON_NUMBER_PRECISION_LOSS');
});

test('strict manifest parser accepts decimal tokens that round-trip exactly',()=>{
 assert.equal(parseJsonNoDuplicateKeys('0.1'), 0.1);
 assert.equal(parseJsonNoDuplicateKeys('1.2300'), 1.23);
 assert.equal(parseJsonNoDuplicateKeys('1e-5'), 0.00001);
 assert.equal(parseJsonNoDuplicateKeys('5e-324'), Number.MIN_VALUE);
});
