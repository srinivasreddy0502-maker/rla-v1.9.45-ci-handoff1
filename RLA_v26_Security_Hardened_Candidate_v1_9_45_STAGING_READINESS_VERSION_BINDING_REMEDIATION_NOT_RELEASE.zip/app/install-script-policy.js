'use strict';

const EXACT_VERSION = /^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?$/;

function validateInstallScriptPolicy(packages, policy, now = new Date()) {
  const blockers = [];
  if (!packages || typeof packages !== 'object' || Array.isArray(packages)) {
    return ['INSTALL_SCRIPT_PACKAGE_MAP_INVALID'];
  }
  if (!policy || typeof policy !== 'object' || Array.isArray(policy) || policy.schemaVersion !== 1 || !Array.isArray(policy.approvedScripts)) {
    return ['INSTALL_SCRIPT_POLICY_INVALID'];
  }
  const approvals = new Map();
  for (const approval of policy.approvedScripts) {
    if (!approval || typeof approval !== 'object' || Array.isArray(approval)) {
      blockers.push('INSTALL_SCRIPT_APPROVAL_INVALID');
      continue;
    }
    const { packageKey, packageName, version, reason, approvedBy, reviewedAt, expiresAt, changeTicket } = approval;
    if ([packageKey, packageName, version, reason, approvedBy, reviewedAt, expiresAt, changeTicket].some(v => typeof v !== 'string' || !v.trim()) || !EXACT_VERSION.test(version || '')) {
      blockers.push('INSTALL_SCRIPT_APPROVAL_FIELDS_INVALID');
      continue;
    }
    const reviewTime = Date.parse(reviewedAt);
    const expiryTime = Date.parse(expiresAt);
    if (!Number.isFinite(reviewTime) || !Number.isFinite(expiryTime) || expiryTime <= reviewTime) {
      blockers.push(`INSTALL_SCRIPT_APPROVAL_DATES_INVALID:${packageKey}`);
      continue;
    }
    if (expiryTime <= now.getTime()) {
      blockers.push(`INSTALL_SCRIPT_APPROVAL_EXPIRED:${packageKey}`);
      continue;
    }
    if (approvals.has(packageKey)) blockers.push(`INSTALL_SCRIPT_APPROVAL_DUPLICATE:${packageKey}`);
    else approvals.set(packageKey, approval);
  }

  for (const [packageKey, entry] of Object.entries(packages)) {
    if (!packageKey || packageKey === '' || !entry || typeof entry !== 'object' || Array.isArray(entry)) continue;
    if (entry.hasInstallScript !== true) continue;
    const approval = approvals.get(packageKey);
    if (!approval) {
      blockers.push(`INSTALL_SCRIPT_NOT_APPROVED:${packageKey}`);
      continue;
    }
    if (approval.packageName !== entry.name || approval.version !== entry.version) {
      blockers.push(`INSTALL_SCRIPT_APPROVAL_IDENTITY_MISMATCH:${packageKey}`);
    }
    if (policy.policyStatus !== 'APPROVED' || typeof policy.policyOwner !== 'string' || !policy.policyOwner.trim()) {
      blockers.push(`INSTALL_SCRIPT_POLICY_NOT_APPROVED:${packageKey}`);
    }
  }
  for (const [packageKey, approval] of approvals) {
    const entry = packages[packageKey];
    if (!entry || entry.hasInstallScript !== true) blockers.push(`INSTALL_SCRIPT_APPROVAL_STALE:${packageKey}`);
    else if (approval.packageName !== entry.name || approval.version !== entry.version) blockers.push(`INSTALL_SCRIPT_APPROVAL_IDENTITY_MISMATCH:${packageKey}`);
  }
  return [...new Set(blockers)];
}

module.exports = { validateInstallScriptPolicy };
