'use strict';

const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const { validateInstallScriptPolicy } = require('./install-script-policy');

// Dependency versions must be canonical stable SemVer pins. Prerelease pins are
// intentionally blocked until full npm-semver prerelease semantics are implemented.
const EXACT_VERSION = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/;
const DEFAULT_APPROVED_HOSTS = Object.freeze(['registry.npmjs.org']);

function isCanonicalRegistryHostname(hostname) {
  if (typeof hostname !== 'string' || hostname.length < 1 || hostname.length > 253 || net.isIP(hostname) !== 0) return false;
  // Keep the allowlist to ASCII DNS hostnames. IDNs must be supplied in their
  // explicit punycode form so the configured value and URL hostname compare
  // identically. A trailing dot, empty label, underscore, or IP literal is not
  // accepted as an approved registry hostname.
  if (!/^[a-z0-9.-]+$/.test(hostname) || hostname.endsWith('.')) return false;
  const labels = hostname.split('.');
  if (labels.length < 2 || !labels.every(label => label.length >= 1 && label.length <= 63 &&
    /^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/.test(label))) return false;
  // WHATWG URL parsing canonicalizes legacy IPv4 forms such as 127.1 and
  // 0177.0.0.1. Reject any hostname that does not round-trip unchanged.
  try {
    const parsed = new URL(`https://${hostname}/`);
    return parsed.hostname === hostname && net.isIP(parsed.hostname) === 0;
  } catch {
    return false;
  }
}

function parseApprovedHosts(value) {
  if (value === undefined || value === '') return [...DEFAULT_APPROVED_HOSTS];
  if (typeof value !== 'string') {
    throw new TypeError('RLA_APPROVED_NPM_REGISTRIES must be a comma-separated list of hostnames');
  }
  const rawHosts = value.split(',').map(x => x.trim());
  if (!rawHosts.length || rawHosts.some(x => !x)) {
    throw new TypeError('RLA_APPROVED_NPM_REGISTRIES must not contain empty hostname entries');
  }
  const hosts = rawHosts.map(x => x.toLowerCase());
  if (hosts.some(x => !isCanonicalRegistryHostname(x))) {
    throw new TypeError('RLA_APPROVED_NPM_REGISTRIES must contain canonical ASCII DNS hostnames');
  }
  return [...new Set(hosts)];
}

function resolveLockedDependency(packages, fromPackageKey, dependencyName) {
  let current = fromPackageKey;
  while (true) {
    const candidate = current ? `${current}/node_modules/${dependencyName}` : `node_modules/${dependencyName}`;
    if (Object.prototype.hasOwnProperty.call(packages, candidate)) return candidate;
    if (!current) return null;
    current = current.replace(/(?:^|\/)node_modules\/(?:@[^/]+\/)?[^/]+$/, '');
  }
}

function parseCanonicalPackageKey(packageKey) {
  if (typeof packageKey !== 'string' || packageKey === '' || packageKey.includes('\\') || packageKey.includes('\0')) return null;
  const parts = packageKey.split('/');
  let i = 0;
  let lastName = null;
  while (i < parts.length) {
    if (parts[i] !== 'node_modules' || i + 1 >= parts.length) return null;
    i += 1;
    let name = parts[i];
    if (!name || name === '.' || name === '..' || name === 'node_modules' || name.startsWith('.')) return null;
    if (name.startsWith('@')) {
      if (!/^@[a-z0-9][a-z0-9._~-]*$/.test(name) || i + 1 >= parts.length) return null;
      const packagePart = parts[i + 1];
      if (!/^[a-z0-9][a-z0-9._~-]*$/.test(packagePart) || packagePart === 'node_modules') return null;
      name = `${name}/${packagePart}`;
      i += 2;
    } else {
      if (!/^[a-z0-9][a-z0-9._~-]*$/.test(name)) return null;
      i += 1;
    }
    lastName = name;
    if (i < parts.length && parts[i] !== 'node_modules') return null;
  }
  return lastName;
}

function expectedPackageNameFromKey(packageKey) {
  return parseCanonicalPackageKey(packageKey);
}

function parseSemverVersion(value) {
  if (typeof value !== 'string') return null;
  // Enforce non-empty dot-separated identifiers. Numeric prerelease identifiers
  // must not have leading zeroes; build metadata is validated but ignored for
  // precedence, as required by SemVer 2.0.0.
  const match = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?$/.exec(value);
  if (!match) return null;
  const core = [match[1], match[2], match[3]].map(Number);
  // JavaScript Number cannot exactly represent every SemVer numeric component.
  // Fail closed rather than compare rounded values as though they were exact.
  if (core.some(component => !Number.isSafeInteger(component))) return null;
  const prerelease = match[4] || '';
  if (prerelease.split('.').some(identifier => /^\d+$/.test(identifier) && identifier.length > 1 && identifier.startsWith('0'))) return null;
  return { major: core[0], minor: core[1], patch: core[2], prerelease };
}

function isSafeExactVersion(value) {
  if (typeof value !== 'string' || !EXACT_VERSION.test(value)) return false;
  const parsed = parseSemverVersion(value);
  return Boolean(parsed && !parsed.prerelease);
}

function compareSemverCore(a, b) {
  for (const key of ['major', 'minor', 'patch']) {
    if (a[key] !== b[key]) return a[key] < b[key] ? -1 : 1;
  }
  if (a.prerelease === b.prerelease) return 0;
  if (!a.prerelease) return 1;
  if (!b.prerelease) return -1;
  return a.prerelease < b.prerelease ? -1 : 1;
}

function versionSatisfiesSpec(versionText, specText) {
  const version = parseSemverVersion(versionText);
  if (!version || version.prerelease || typeof specText !== 'string' || !specText.trim()) return null;
  const spec = specText.trim();
  const exactSpec = parseSemverVersion(spec);
  if (exactSpec) {
    if (exactSpec.prerelease) return null;
    return compareSemverCore(version, exactSpec) === 0;
  }
  const alternatives = spec.split('||').map(part => part.trim());
  if (alternatives.some(part => !part)) return null;
  let supported = true;
  const matchesAlternative = alternative => {
    const tokens = alternative.split(/\s+/).filter(Boolean);
    if (tokens.length === 1 && /^(?:\*|x|X)$/.test(tokens[0])) return !version.prerelease;
    for (const token of tokens) {
      const wildcard = /^(\d+|x|X|\*)\.(\d+|x|X|\*)\.(\d+|x|X|\*)$/.exec(token);
      if (wildcard) {
        if (version.prerelease) return false;
        const parts = [version.major, version.minor, version.patch];
        for (let i = 1; i <= 3; i += 1) {
          const expected = wildcard[i];
          if (expected !== '*' && expected.toLowerCase() !== 'x' && parts[i - 1] !== Number(expected)) return false;
          if ((expected === '*' || expected.toLowerCase() === 'x') && wildcard.slice(i + 1).some(x => x !== '*' && x.toLowerCase() !== 'x')) return false;
        }
        continue;
      }
      const match = /^(\^|~|>=|<=|>|<)?(.+)$/.exec(token);
      if (!match) { supported = false; return false; }
      const operator = match[1] || '';
      const bound = parseSemverVersion(match[2]);
      if (!bound || bound.prerelease) { supported = false; return false; }
      if (version.prerelease && !match[2].includes('-')) return false;
      const comparison = compareSemverCore(version, bound);
      if (operator === '^') {
        if (comparison < 0) return false;
        if (bound.major > 0 && version.major !== bound.major) return false;
        if (bound.major === 0 && bound.minor > 0 && (version.major !== 0 || version.minor !== bound.minor)) return false;
        if (bound.major === 0 && bound.minor === 0 && (version.major !== 0 || version.minor !== 0 || version.patch !== bound.patch)) return false;
      } else if (operator === '~') {
        if (comparison < 0 || version.major !== bound.major || version.minor !== bound.minor) return false;
      } else if (operator === '>=' && comparison < 0) return false;
      else if (operator === '<=' && comparison > 0) return false;
      else if (operator === '>' && comparison <= 0) return false;
      else if (operator === '<' && comparison >= 0) return false;
      else if (!operator && comparison !== 0) return false;
    }
    return true;
  };
  const matched = alternatives.some(matchesAlternative);
  return supported ? matched : null;
}

function validateDependencyGraph(packages) {
  const blockers = [];
  for (const [packageKey, entry] of Object.entries(packages)) {
    if (!packageKey || packageKey === '') continue;
    if (!entry || typeof entry !== 'object' || Array.isArray(entry)) {
      blockers.push(`LOCK_ENTRY_INVALID:${packageKey}`);
      continue;
    }
    const expectedName = expectedPackageNameFromKey(packageKey);
    if (expectedName === null) {
      blockers.push(`LOCK_PACKAGE_KEY_NON_CANONICAL:${packageKey}`);
    } else {
      if (entry.name !== undefined && entry.name !== expectedName) {
        blockers.push(`LOCK_ENTRY_PACKAGE_NAME_MISMATCH:${packageKey}`);
      }
      if (!isSafeExactVersion(entry.version)) {
        blockers.push(`LOCK_ENTRY_VERSION_INVALID:${packageKey}`);
      }
    }
    for (const field of ['dependencies', 'optionalDependencies']) {
      const dependencies = entry[field];
      if (dependencies === undefined) continue;
      if (!dependencies || typeof dependencies !== 'object' || Array.isArray(dependencies)) {
        blockers.push(`LOCK_ENTRY_${field.toUpperCase()}_INVALID:${packageKey}`);
        continue;
      }
      for (const [dependencyName, spec] of Object.entries(dependencies)) {
        if (typeof spec !== 'string' || !spec.trim()) {
          blockers.push(`LOCK_DEPENDENCY_SPEC_INVALID:${packageKey}:${dependencyName}`);
          continue;
        }
        const targetKey = resolveLockedDependency(packages, packageKey, dependencyName);
        if (!targetKey) {
          blockers.push(`LOCK_DEPENDENCY_TARGET_MISSING:${packageKey}:${dependencyName}`);
        } else {
          const target = packages[targetKey];
          const satisfaction = target && versionSatisfiesSpec(target.version, spec);
          if (satisfaction === null) blockers.push(`LOCK_DEPENDENCY_SPEC_UNSUPPORTED:${packageKey}:${dependencyName}`);
          else if (!satisfaction) blockers.push(`LOCK_DEPENDENCY_VERSION_OUT_OF_RANGE:${packageKey}:${dependencyName}:${targetKey}`);
        }
      }
    }
  }
  return blockers;
}

// Read security-sensitive preflight inputs without following symlinks. Require
// a single-link regular file with no group/other write bits, and compare identity
// metadata before/after the bounded read. This reduces aliasing and mutation risk
// for package metadata, the lockfile, and install-script policy.
function readRegularFileNoFollow(filePath, missingCode, unsafeCode, changedCode,
  maxBytes = 32 * 1024 * 1024, tooLargeCode = 'PREFLIGHT_FILE_TOO_LARGE') {
  const noFollow = fs.constants.O_NOFOLLOW;
  if (!Number.isInteger(noFollow) || noFollow === 0) {
    return { ok: false, code: 'NOFOLLOW_UNAVAILABLE' };
  }
  if (!Number.isSafeInteger(maxBytes) || maxBytes < 1) {
    return { ok: false, code: 'PREFLIGHT_FILE_SIZE_LIMIT_INVALID' };
  }
  let fd;
  try {
    fd = fs.openSync(filePath, fs.constants.O_RDONLY | noFollow);
    const before = fs.fstatSync(fd, { bigint: true });
    if (!before.isFile() || (Number(before.mode) & 0o022) !== 0 || before.nlink !== 1n) {
      return { ok: false, code: unsafeCode };
    }
    if (before.size > BigInt(maxBytes)) return { ok: false, code: tooLargeCode };

    // Read in bounded chunks rather than readFileSync(fd), so a file that grows
    // after fstat cannot cause unbounded memory consumption during preflight.
    const chunks = [];
    const buffer = Buffer.allocUnsafe(64 * 1024);
    let totalBytes = 0;
    while (true) {
      const remainingPlusOne = maxBytes + 1 - totalBytes;
      if (remainingPlusOne <= 0) return { ok: false, code: tooLargeCode };
      const bytesToRead = Math.min(buffer.length, remainingPlusOne);
      const bytesRead = fs.readSync(fd, buffer, 0, bytesToRead, null);
      if (bytesRead === 0) break;
      totalBytes += bytesRead;
      if (totalBytes > maxBytes) return { ok: false, code: tooLargeCode };
      chunks.push(Buffer.from(buffer.subarray(0, bytesRead)));
    }
    const after = fs.fstatSync(fd, { bigint: true });
    if (!after.isFile() || before.dev !== after.dev || before.ino !== after.ino ||
        before.size !== after.size || before.mtimeNs !== after.mtimeNs ||
        before.ctimeNs !== after.ctimeNs || before.mode !== after.mode ||
        before.nlink !== after.nlink || BigInt(totalBytes) !== after.size) {
      return { ok: false, code: changedCode };
    }
    return { ok: true, content: Buffer.concat(chunks, totalBytes).toString('utf8') };
  } catch (error) {
    if (error.code === 'ENOENT') return { ok: false, code: missingCode };
    if (error.code === 'ELOOP') return { ok: false, code: unsafeCode };
    return { ok: false, code: unsafeCode };
  } finally {
    if (fd !== undefined) {
      try { fs.closeSync(fd); } catch {}
    }
  }
}

function readJsonRegularFileNoFollow(filePath, missingCode, invalidCode, unsafeCode, changedCode,
  maxBytes = 32 * 1024 * 1024, tooLargeCode = 'PREFLIGHT_FILE_TOO_LARGE') {
  const read = readRegularFileNoFollow(filePath, missingCode, unsafeCode, changedCode, maxBytes, tooLargeCode);
  if (!read.ok) return read;
  try { return { ok: true, value: JSON.parse(read.content) }; }
  catch { return { ok: false, code: invalidCode }; }
}

function isRealDirectoryNoFollow(directoryPath) {
  try {
    const stat = fs.lstatSync(directoryPath);
    // Trusted candidate/config directories must not be writable by group or
    // other users; sticky /tmp parents are outside this checked boundary.
    return stat.isDirectory() && !stat.isSymbolicLink() && (stat.mode & 0o022) === 0;
  } catch {
    return false;
  }
}

function checkDependencyLockfile({ rootDir, approvedHosts = [...DEFAULT_APPROVED_HOSTS] }) {
  const blockers = [];
  // O_NOFOLLOW protects only the final file component. Also reject a symlinked
  // candidate root or config directory so these trusted directory boundaries
  // cannot silently redirect the preflight to a different tree.
  if (!isRealDirectoryNoFollow(rootDir)) return result(['ROOT_DIRECTORY_PATH_UNSAFE'], null);
  const packagePath = path.join(rootDir, 'package.json');
  const lockPath = path.join(rootDir, 'package-lock.json');
  const packageRead = readJsonRegularFileNoFollow(packagePath, 'PACKAGE_JSON_MISSING_OR_INVALID', 'PACKAGE_JSON_MISSING_OR_INVALID', 'PACKAGE_JSON_PATH_UNSAFE', 'PACKAGE_JSON_CHANGED_DURING_READ', 1024 * 1024, 'PACKAGE_JSON_TOO_LARGE');
  if (!packageRead.ok) return result([packageRead.code], null);
  const pkg = packageRead.value;
  const dependencies = pkg && pkg.dependencies && typeof pkg.dependencies === 'object' ? pkg.dependencies : {};
  const directNames = Object.keys(dependencies).sort();
  if (!directNames.length) blockers.push('NO_RUNTIME_DEPENDENCIES_DECLARED');
  for (const name of directNames) {
    if (!isSafeExactVersion(dependencies[name])) {
      blockers.push(`DIRECT_DEPENDENCY_NOT_EXACTLY_PINNED:${name}`);
    }
  }

  const lockRead = readJsonRegularFileNoFollow(lockPath, 'PACKAGE_LOCK_JSON_MISSING', 'PACKAGE_LOCK_JSON_INVALID', 'PACKAGE_LOCK_PATH_UNSAFE', 'PACKAGE_LOCK_CHANGED_DURING_READ', 32 * 1024 * 1024, 'PACKAGE_LOCK_JSON_TOO_LARGE');
  if (!lockRead.ok) {
    blockers.push(lockRead.code);
    return result(blockers, null);
  }
  const lock = lockRead.value;
  if (!lock || typeof lock !== 'object' || Array.isArray(lock)) {
    blockers.push('PACKAGE_LOCK_JSON_INVALID');
    return result(blockers, null);
  }
  if (typeof pkg.name === 'string' && lock.name !== pkg.name) blockers.push('LOCKFILE_PACKAGE_NAME_MISMATCH');
  if (typeof pkg.version === 'string' && lock.version !== pkg.version) blockers.push('LOCKFILE_PACKAGE_VERSION_MISMATCH');
  if (!Number.isInteger(lock.lockfileVersion) || lock.lockfileVersion < 3) blockers.push('LOCKFILE_VERSION_MUST_BE_3_OR_NEWER');
  const lockedRootDeps = lock.packages && lock.packages[''] && lock.packages[''].dependencies;
  if (!lockedRootDeps || typeof lockedRootDeps !== 'object') blockers.push('LOCKFILE_ROOT_DEPENDENCIES_MISSING');
  else {
    for (const name of directNames) {
      if (lockedRootDeps[name] !== dependencies[name]) blockers.push(`ROOT_DEPENDENCY_MISMATCH:${name}`);
      const entry = lock.packages && lock.packages[`node_modules/${name}`];
      if (!entry || entry.version !== dependencies[name]) blockers.push(`DIRECT_DEPENDENCY_LOCK_ENTRY_MISMATCH:${name}`);
    }
    for (const name of Object.keys(lockedRootDeps)) {
      if (!Object.prototype.hasOwnProperty.call(dependencies, name)) blockers.push(`UNDECLARED_ROOT_DEPENDENCY_IN_LOCKFILE:${name}`);
    }
  }

  const packages = lock.packages;
  if (!packages || typeof packages !== 'object' || Array.isArray(packages)) blockers.push('LOCKFILE_PACKAGES_SECTION_MISSING');
  else {
    blockers.push(...validateDependencyGraph(packages));
    const configPath = path.join(rootDir, 'config');
    const policyPath = path.join(configPath, 'dependency-install-script-policy.json');
    let installScriptPolicy = null;
    if (!isRealDirectoryNoFollow(configPath)) {
      blockers.push('INSTALL_SCRIPT_POLICY_DIRECTORY_UNSAFE');
    } else {
      const policyRead = readJsonRegularFileNoFollow(policyPath, 'INSTALL_SCRIPT_POLICY_MISSING', 'INSTALL_SCRIPT_POLICY_INVALID', 'INSTALL_SCRIPT_POLICY_PATH_UNSAFE', 'INSTALL_SCRIPT_POLICY_CHANGED_DURING_READ', 1024 * 1024, 'INSTALL_SCRIPT_POLICY_TOO_LARGE');
      if (!policyRead.ok) blockers.push(policyRead.code);
      else installScriptPolicy = policyRead.value;
    }
    if (installScriptPolicy) blockers.push(...validateInstallScriptPolicy(packages, installScriptPolicy));
    for (const [name, entry] of Object.entries(packages)) {
      if (!name || name === '') continue;
      if (!entry || typeof entry !== 'object') { blockers.push(`LOCK_ENTRY_INVALID:${name}`); continue; }
      if (entry.link === true) { blockers.push(`LINK_DEPENDENCY_NOT_ALLOWED:${name}`); continue; }
      // Bundled dependencies bypass the ordinary registry URL and SRI checks. Do
      // not allow a lockfile entry to self-assert that exception; it requires a
      // separate, explicit review path before this preflight can permit install.
      if (entry.inBundle === true) {
        blockers.push(`BUNDLED_DEPENDENCY_NOT_APPROVED:${name}`);
        continue;
      }
      if (entry.resolved === undefined) {
        blockers.push(`RESOLVED_TARBALL_URL_MISSING:${name}`);
        continue;
      }
      let url;
      try { url = new URL(entry.resolved); }
      catch { blockers.push(`RESOLVED_TARBALL_URL_INVALID:${name}`); continue; }
      if (url.protocol !== 'https:' || url.username || url.password || url.port !== '' || url.search || url.hash || !approvedHosts.includes(url.hostname.toLowerCase())) {
        blockers.push(`RESOLVED_TARBALL_ORIGIN_NOT_APPROVED:${name}`);
      }
      if (entry.integrity !== undefined) {
        if (typeof entry.integrity !== 'string' || !/^[A-Za-z0-9]+-[A-Za-z0-9+/]+={0,2}$/.test(entry.integrity)) {
          blockers.push(`LOCK_ENTRY_INTEGRITY_INVALID:${name}`);
        } else {
          const separator = entry.integrity.indexOf('-');
          const algorithm = entry.integrity.slice(0, separator);
          const encodedDigest = entry.integrity.slice(separator + 1);
          if (algorithm !== 'sha512') blockers.push(`LOCK_ENTRY_INTEGRITY_ALGORITHM_NOT_SHA512:${name}`);
          else {
            const digest = Buffer.from(encodedDigest, 'base64');
            if (digest.length !== 64 || digest.toString('base64') !== encodedDigest) {
              blockers.push(`LOCK_ENTRY_INTEGRITY_INVALID:${name}`);
            }
          }
        }
      }
      if (entry.integrity === undefined && !entry.inBundle) blockers.push(`LOCK_ENTRY_INTEGRITY_MISSING:${name}`);
    }
  }
  return result([...new Set(blockers)], lock.lockfileVersion ?? null);
}

function result(blockers, lockfileVersion) {
  return {
    schemaVersion: 1,
    check: 'DEPENDENCY_LOCKFILE_PREFLIGHT',
    status: blockers.length ? 'BLOCKED' : 'PASS',
    lockfileVersion,
    blockers,
    installAllowed: blockers.length === 0,
    productionUseAuthorized: false
  };
}

module.exports = { DEFAULT_APPROVED_HOSTS, EXACT_VERSION, isRealDirectoryNoFollow, readRegularFileNoFollow, readJsonRegularFileNoFollow, checkDependencyLockfile, expectedPackageNameFromKey, isCanonicalRegistryHostname, isSafeExactVersion, parseApprovedHosts, parseCanonicalPackageKey, resolveLockedDependency, validateDependencyGraph, versionSatisfiesSpec };
