'use strict';

const MAX_DIAGNOSTIC_CHARS = 2000;
const CANDIDATE_VERSION = require('../package.json').version;
const BLOCKERS = Object.freeze([
  'APPROVED_DEPENDENCY_LOCKFILE_NOT_VERIFIED',
  'NATIVE_SQLITE_FILE_BACKUP_RESTORE_DRILL_NOT_VERIFIED',
  'WAL_CRASH_RECOVERY_RESTORE_DRILL_NOT_VERIFIED',
  'CLEAN_HOST_RESTORE_DRILL_NOT_VERIFIED',
  'INDEPENDENT_SECURITY_REVIEW_NOT_VERIFIED',
  'PENETRATION_TEST_NOT_VERIFIED',
  'USER_ACCEPTANCE_TESTING_NOT_VERIFIED',
  'FORMAL_RELEASE_APPROVAL_NOT_GRANTED'
]);

function safeDiagnostic(value) {
  if (typeof value !== 'string') return '';
  return value.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, ' ').slice(0, MAX_DIAGNOSTIC_CHARS);
}

function buildStagingReadinessReport({ exitCode, stdout, stderr, generatedAt = new Date().toISOString() }) {
  if (!Number.isInteger(exitCode)) throw new TypeError('exitCode must be an integer');
  if (typeof stdout !== 'string' || typeof stderr !== 'string') throw new TypeError('stdout and stderr must be strings');
  const date = new Date(generatedAt);
  if (!Number.isFinite(date.getTime()) || date.toISOString() !== generatedAt) throw new TypeError('generatedAt must be a canonical UTC ISO timestamp');

  let preflight = null;
  let parseError = null;
  const candidateJson = stdout.trim() ? stdout : stderr;
  try {
    preflight = JSON.parse(candidateJson);
    if (!preflight || typeof preflight !== 'object' || Array.isArray(preflight)) throw new Error('preflight JSON must be an object');
  } catch (error) {
    parseError = error.message;
  }

  const smokePassed = exitCode === 0 && !parseError && preflight.status === 'DRIVER_SMOKE_PASS' &&
    preflight.nativeDriver === true && preflight.npmPackage === 'sqlite3' &&
    typeof preflight.packageVersion === 'string' && typeof preflight.sqliteLibraryVersion === 'string' &&
    preflight.databaseBackupApi === true;

  const blockers = [...BLOCKERS];
  if (!smokePassed) blockers.unshift('NATIVE_SQLITE_DRIVER_SMOKE_NOT_PASSED');
  return {
    schemaVersion: 1,
    candidateVersion: CANDIDATE_VERSION,
    generatedAt: date.toISOString(),
    stage: 'NATIVE_SQLITE_STAGING_PREFLIGHT',
    preflightStatus: smokePassed ? 'DRIVER_SMOKE_PASS' : 'BLOCKED',
    preflightExitCode: exitCode,
    preflight: preflight ? {
      status: typeof preflight.status === 'string' ? preflight.status : 'UNKNOWN',
      code: typeof preflight.code === 'string' ? preflight.code : null,
      nativeDriver: preflight.nativeDriver === true,
      npmPackage: typeof preflight.npmPackage === 'string' ? preflight.npmPackage : null,
      packageVersion: typeof preflight.packageVersion === 'string' ? preflight.packageVersion : null,
      nodeVersion: typeof preflight.nodeVersion === 'string' ? preflight.nodeVersion : null,
      nodeModuleAbi: typeof preflight.nodeModuleAbi === 'string' ? preflight.nodeModuleAbi : null,
      platform: typeof preflight.platform === 'string' ? preflight.platform : null,
      architecture: typeof preflight.architecture === 'string' ? preflight.architecture : null,
      sqliteLibraryVersion: typeof preflight.sqliteLibraryVersion === 'string' ? preflight.sqliteLibraryVersion : null,
      databaseBackupApi: preflight.databaseBackupApi === true
    } : null,
    diagnostic: safeDiagnostic(parseError || (preflight && (preflight.message || preflight.code)) || (smokePassed ? '' : (stderr || stdout))),
    requiredFollowUp: blockers,
    dependencyLockfile: 'NOT_VERIFIED',
    realFileBackupRestore: 'NOT_VERIFIED',
    walCrashRecovery: 'NOT_VERIFIED',
    cleanHostRestore: 'NOT_VERIFIED',
    releaseStatus: 'RELEASE_BLOCKED',
    releaseAuthorityGranted: false,
    productionUseAuthorized: false
  };
}

module.exports = { MAX_DIAGNOSTIC_CHARS, BLOCKERS, buildStagingReadinessReport };
