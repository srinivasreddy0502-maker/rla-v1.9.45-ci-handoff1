'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const { parseExplicitRegistry } = require('./dependency-lockfile-acquisition-plan');
const { parseApprovedHosts } = require('./dependency-lockfile-preflight');

const MAX_INPUT_BYTES = 32 * 1024 * 1024;
const PASS = 'PASS';

function isObject(value) { return value !== null && typeof value === 'object' && !Array.isArray(value); }
function nonEmpty(value, max = 256) { return typeof value === 'string' && value.trim().length > 0 && value.length <= max; }
function isSha256(value) { return typeof value === 'string' && /^[a-f0-9]{64}$/.test(value); }
function canonicalUtc(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(value)) return false;
  const date = new Date(value);
  return Number.isFinite(date.getTime()) && date.toISOString() === value;
}
function addUnexpected(value, allowed, scope, blockers) {
  const keys = new Set(allowed);
  for (const key of Object.keys(value)) if (!keys.has(key)) blockers.push(`UNEXPECTED_FIELD_${scope}:${key}`);
}

function readBoundedRegularFileNoFollow(filePath, prefix) {
  const noFollow = fs.constants.O_NOFOLLOW;
  if (!Number.isInteger(noFollow) || noFollow === 0) return { ok: false, code: `${prefix}_NOFOLLOW_UNAVAILABLE` };
  let fd;
  try {
    fd = fs.openSync(filePath, fs.constants.O_RDONLY | noFollow);
    const before = fs.fstatSync(fd, { bigint: true });
    if (!before.isFile() || before.nlink !== 1n || (Number(before.mode) & 0o022) !== 0) return { ok: false, code: `${prefix}_FILE_UNSAFE` };
    if (before.size < 1n || before.size > BigInt(MAX_INPUT_BYTES)) return { ok: false, code: `${prefix}_SIZE_INVALID` };
    const chunks = [];
    let total = 0;
    const buffer = Buffer.alloc(64 * 1024);
    while (true) {
      const count = fs.readSync(fd, buffer, 0, buffer.length, null);
      if (count === 0) break;
      total += count;
      if (total > MAX_INPUT_BYTES) return { ok: false, code: `${prefix}_SIZE_INVALID` };
      chunks.push(Buffer.from(buffer.subarray(0, count)));
    }
    const after = fs.fstatSync(fd, { bigint: true });
    if (before.dev !== after.dev || before.ino !== after.ino || before.size !== after.size ||
        before.mtimeNs !== after.mtimeNs || before.ctimeNs !== after.ctimeNs || before.nlink !== after.nlink) {
      return { ok: false, code: `${prefix}_CHANGED_DURING_READ` };
    }
    return { ok: true, bytes: Buffer.concat(chunks, total) };
  } catch (error) {
    return { ok: false, code: error.code === 'ENOENT' ? `${prefix}_MISSING` : `${prefix}_FILE_UNSAFE` };
  } finally {
    if (fd !== undefined) { try { fs.closeSync(fd); } catch {} }
  }
}

function validateLockfilePromotionEvidence({ rootDir, evidence, env = process.env, expectedCandidateVersion = require('../package.json').version }) {
  const blockers = [];
  let approvedHosts;
  try { approvedHosts = parseApprovedHosts(env.RLA_APPROVED_NPM_REGISTRIES); }
  catch { approvedHosts = []; blockers.push('APPROVED_REGISTRY_ALLOWLIST_INVALID'); }

  let safeRoot = false;
  let canonicalRoot = null;
  if (typeof rootDir !== 'string' || !rootDir.trim()) {
    blockers.push('STAGING_ROOT_INVALID');
  } else {
    try {
      const stat = fs.lstatSync(rootDir);
      canonicalRoot = fs.realpathSync(rootDir);
      if (stat.isSymbolicLink() || !stat.isDirectory() || path.resolve(rootDir) !== canonicalRoot) {
        blockers.push('STAGING_ROOT_UNSAFE');
      } else {
        safeRoot = true;
      }
    } catch { blockers.push('STAGING_ROOT_UNAVAILABLE'); }
  }

  if (!isObject(evidence)) {
    blockers.push('EVIDENCE_ROOT_NOT_OBJECT');
    return report(blockers, expectedCandidateVersion, null, null);
  }
  addUnexpected(evidence, ['schemaVersion', 'candidateVersion', 'generatedAt', 'staging', 'registry', 'capture', 'lockfile', 'review'], 'ROOT', blockers);
  if (evidence.schemaVersion !== 1) blockers.push('SCHEMA_VERSION_UNSUPPORTED');
  if (evidence.candidateVersion !== expectedCandidateVersion) blockers.push('CANDIDATE_VERSION_MISMATCH');
  if (!canonicalUtc(evidence.generatedAt)) blockers.push('GENERATED_AT_INVALID');

  const staging = evidence.staging;
  if (isObject(staging)) addUnexpected(staging, ['approved', 'isolated', 'environmentId', 'operatorId'], 'STAGING', blockers);
  if (!isObject(staging) || staging.approved !== true || staging.isolated !== true || !nonEmpty(staging.environmentId, 128) || !nonEmpty(staging.operatorId, 128)) blockers.push('APPROVED_ISOLATED_STAGING_EVIDENCE_INCOMPLETE');

  let registry = null;
  try {
    if (!isObject(evidence.registry)) throw new TypeError('registry evidence missing');
    addUnexpected(evidence.registry, ['origin', 'tlsValidated', 'responseStatus'], 'REGISTRY', blockers);
    registry = parseExplicitRegistry(evidence.registry.origin, approvedHosts);
    if (registry !== evidence.registry.origin) blockers.push('REGISTRY_ORIGIN_NOT_CANONICAL');
    if (evidence.registry.tlsValidated !== true || evidence.registry.responseStatus !== 200) blockers.push('REGISTRY_CONNECTIVITY_EVIDENCE_INCOMPLETE');
  } catch { blockers.push('REGISTRY_NOT_IN_APPROVED_ALLOWLIST'); }

  const capture = evidence.capture;
  if (isObject(capture)) addUnexpected(capture, ['command', 'exitCode', 'networkTestPerformed', 'installScriptsDisabled', 'npmCiExecuted', 'npmVersion', 'nodeVersion', 'workingDirectoryIsolated'], 'CAPTURE', blockers);
  const expectedFlags = ['install', '--package-lock-only', '--ignore-scripts', '--no-audit', '--no-fund', '--lockfile-version=3'];
  if (!isObject(capture) || !Array.isArray(capture.command) || capture.command.length !== expectedFlags.length + 2 || capture.command[0] !== 'npm' ||
      expectedFlags.some((flag, i) => capture.command[i + 1] !== flag) || typeof registry !== 'string' || capture.command[capture.command.length - 1] !== `--registry=${registry}`) {
    blockers.push('CAPTURE_COMMAND_NOT_APPROVED');
  }
  if (!isObject(capture) || capture.exitCode !== 0 || capture.networkTestPerformed !== true || capture.installScriptsDisabled !== true ||
      capture.npmCiExecuted !== false || capture.workingDirectoryIsolated !== true || !nonEmpty(capture.npmVersion, 64) || !nonEmpty(capture.nodeVersion, 64)) {
    blockers.push('CAPTURE_EXECUTION_EVIDENCE_INCOMPLETE');
  }

  const lock = evidence.lockfile;
  if (isObject(lock)) addUnexpected(lock, ['sha256', 'bytes', 'lockfileVersion', 'packageJsonSha256', 'dependencyReviewStatus', 'dependencyGraphReviewRef', 'provenanceReviewed'], 'LOCKFILE', blockers);
  if (!isObject(lock) || !isSha256(lock.sha256) || !Number.isSafeInteger(lock.bytes) || lock.bytes < 1 || lock.lockfileVersion !== 3 ||
      !isSha256(lock.packageJsonSha256) || lock.dependencyReviewStatus !== PASS || !nonEmpty(lock.dependencyGraphReviewRef, 256) || lock.provenanceReviewed !== true) {
    blockers.push('LOCKFILE_REVIEW_EVIDENCE_INCOMPLETE');
  }

  let lockBytes = null;
  let packageBytes = null;
  if (safeRoot && canonicalRoot) {
    const lockResult = readBoundedRegularFileNoFollow(path.join(canonicalRoot, 'package-lock.json'), 'PACKAGE_LOCK');
    if (!lockResult.ok) blockers.push(lockResult.code); else lockBytes = lockResult.bytes;
    const packageResult = readBoundedRegularFileNoFollow(path.join(canonicalRoot, 'package.json'), 'PACKAGE_JSON');
    if (!packageResult.ok) blockers.push(packageResult.code); else packageBytes = packageResult.bytes;
  }
  let lockJson = null;
  let packageJson = null;
  if (lockBytes) {
    if (lock && isSha256(lock.sha256) && crypto.createHash('sha256').update(lockBytes).digest('hex') !== lock.sha256) blockers.push('PACKAGE_LOCK_SHA256_MISMATCH');
    if (lock && Number.isSafeInteger(lock.bytes) && lockBytes.length !== lock.bytes) blockers.push('PACKAGE_LOCK_BYTE_COUNT_MISMATCH');
    try { lockJson = JSON.parse(lockBytes.toString('utf8')); } catch { blockers.push('PACKAGE_LOCK_JSON_INVALID'); }
    if (lockJson && lockJson.lockfileVersion !== 3) blockers.push('PACKAGE_LOCK_VERSION_NOT_3');
  }
  if (packageBytes) {
    if (lock && isSha256(lock.packageJsonSha256) && crypto.createHash('sha256').update(packageBytes).digest('hex') !== lock.packageJsonSha256) blockers.push('PACKAGE_JSON_SHA256_MISMATCH');
    try { packageJson = JSON.parse(packageBytes.toString('utf8')); } catch { blockers.push('PACKAGE_JSON_INVALID'); }
  }
  if (lockJson && packageJson) {
    const lockRoot = lockJson.packages && lockJson.packages[''];
    if (!isObject(lockRoot)) blockers.push('PACKAGE_LOCK_ROOT_ENTRY_MISSING');
    else {
      if (lockJson.name !== packageJson.name || lockJson.version !== packageJson.version || lockRoot.name !== packageJson.name || lockRoot.version !== packageJson.version) {
        blockers.push('PACKAGE_LOCK_ROOT_IDENTITY_MISMATCH');
      }
      const stable = value => JSON.stringify(Object.fromEntries(Object.entries(isObject(value) ? value : {}).sort(([a], [b]) => a.localeCompare(b))));
      if (stable(lockRoot.dependencies) !== stable(packageJson.dependencies)) blockers.push('PACKAGE_LOCK_ROOT_DEPENDENCIES_MISMATCH');
      if (stable(lockRoot.devDependencies) !== stable(packageJson.devDependencies)) blockers.push('PACKAGE_LOCK_ROOT_DEV_DEPENDENCIES_MISMATCH');
    }
  }

  const review = evidence.review;
  if (isObject(review)) addUnexpected(review, ['status', 'reviewerId', 'reviewedAt', 'evidenceRef'], 'REVIEW', blockers);
  if (!isObject(review) || review.status !== PASS || !nonEmpty(review.reviewerId, 128) || !canonicalUtc(review.reviewedAt) || !nonEmpty(review.evidenceRef, 256)) {
    blockers.push('INDEPENDENT_REVIEW_EVIDENCE_INCOMPLETE');
  }
  if (isObject(staging) && isObject(review) && staging.operatorId === review.reviewerId) blockers.push('MAKER_CHECKER_SEPARATION_VIOLATION');
  if (canonicalUtc(evidence.generatedAt) && isObject(review) && canonicalUtc(review.reviewedAt) && review.reviewedAt < evidence.generatedAt) blockers.push('REVIEW_PRECEDES_EVIDENCE_GENERATION');

  return report(blockers, expectedCandidateVersion, lockBytes ? crypto.createHash('sha256').update(lockBytes).digest('hex') : null, registry);
}

function report(blockers, candidateVersion, observedLockfileSha256, registry) {
  return {
    schemaVersion: 1,
    check: 'LOCKFILE_PROMOTION_EVIDENCE_CONSISTENCY',
    candidateVersion,
    status: blockers.length ? 'BLOCKED' : 'EVIDENCE_CONSISTENT_PENDING_EXTERNAL_ATTESTATION',
    blockers,
    observedLockfileSha256,
    registry,
    cryptographicAttestationVerified: false,
    independentEnvironmentVerificationComplete: false,
    npmCiExecutedByValidator: false,
    productionUseAuthorized: false,
    releaseStatus: 'RELEASE_BLOCKED'
  };
}

module.exports = { MAX_INPUT_BYTES, readBoundedRegularFileNoFollow, validateLockfilePromotionEvidence };
