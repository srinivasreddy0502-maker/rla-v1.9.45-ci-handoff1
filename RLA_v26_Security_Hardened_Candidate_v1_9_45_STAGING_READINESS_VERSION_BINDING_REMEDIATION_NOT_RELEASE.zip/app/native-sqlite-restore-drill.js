'use strict';
const crypto = require('node:crypto');
const fs = require('node:fs/promises');
const path = require('node:path');

function safeRunId(value) {
  if (typeof value !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9._-]{0,79}$/.test(value)) {
    throw new Error('runId must use 1-80 safe filename characters');
  }
  return value;
}
function loadNativeSqlite3() {
  try { return require('sqlite3'); }
  catch (err) {
    if (err && (err.code === 'MODULE_NOT_FOUND' || err.code === 'ERR_DLOPEN_FAILED')) {
      const e = new Error('Native npm sqlite3 driver is unavailable; real restore drill is BLOCKED');
      e.code = 'NATIVE_SQLITE3_DRIVER_UNAVAILABLE';
      throw e;
    }
    throw err;
  }
}
async function regularFileNoSymlink(file, label) {
  const st = await fs.lstat(file);
  if (!st.isFile() || st.isSymbolicLink()) throw new Error(`${label} must be a regular non-symlink file`);
  // Resolve ancestor symlinks before any containment or sidecar checks.
  return fs.realpath(file);
}
async function privateDirectory(dir) {
  const resolved = path.resolve(dir);
  const st = await fs.lstat(resolved);
  if (!st.isDirectory() || st.isSymbolicLink()) throw new Error('evidenceDir must be a regular non-symlink directory');
  if (process.platform !== 'win32' && (st.mode & 0o077) !== 0) throw new Error('evidenceDir must have mode 0700 or stricter');
  // Canonicalize parent components so path-containment checks cannot be bypassed
  // through an ancestor symlink. The final directory itself was checked above.
  return fs.realpath(resolved);
}
function openDb(sqlite3, filename, mode) {
  return new Promise((resolve, reject) => {
    const db = new sqlite3.Database(filename, mode, err => err ? reject(err) : resolve(db));
  });
}
function backupDb(db, filename) {
  return new Promise((resolve, reject) => {
    if (typeof db.backup !== 'function') return reject(new Error('Installed sqlite3 driver lacks Database#backup API'));
    db.backup(filename, err => err ? reject(err) : resolve());
  });
}
function get(db, sql) {
  return new Promise((resolve, reject) => db.get(sql, (err, row) => err ? reject(err) : resolve(row)));
}
function all(db, sql) {
  return new Promise((resolve, reject) => db.all(sql, (err, rows) => err ? reject(err) : resolve(rows)));
}
function close(db) { return new Promise((resolve, reject) => db.close(err => err ? reject(err) : resolve())); }
async function validateDb(sqlite3, filename) {
  const db = await openDb(sqlite3, filename, sqlite3.OPEN_READONLY);
  try {
    const integrity = await get(db, 'PRAGMA integrity_check');
    if (!integrity || integrity.integrity_check !== 'ok') throw new Error('PRAGMA integrity_check did not return ok');
    const fk = await all(db, 'PRAGMA foreign_key_check');
    if (fk.length) throw new Error(`PRAGMA foreign_key_check found ${fk.length} violation(s)`);
    const tableRows = await all(db, "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name");
    return { integrity: integrity.integrity_check, foreignKeyViolations: fk.length, userTableCount: tableRows.length, userTables: tableRows.map(x => x.name) };
  } finally { await close(db); }
}
async function preflightRestoreDrill({ sourceDbPath, evidenceDir, runId }) {
  const id = safeRunId(runId);
  const source = await regularFileNoSymlink(path.resolve(sourceDbPath), 'sourceDbPath');
  const evidence = await privateDirectory(evidenceDir);
  if (source === evidence || source.startsWith(evidence + path.sep)) throw new Error('source database must be outside evidenceDir');
  // Main-file hashing is not a safe snapshot proof when SQLite WAL/SHM sidecars exist.
  // Refuse the drill rather than silently omit committed WAL content.
  const sidecars = await inspectSqliteSidecars(source);
  if (sidecars.length) throw new Error('SQLite WAL/SHM sidecar exists; controlled WAL-aware backup preflight is required');
  await checkOutputCollisions(evidence, id);
  return { source, evidence, runId: id, sidecars: 'NONE', overwrite: 'REFUSED' };
}
async function enforcePrivateArtifact(file, label = 'restore-drill artifact') {
  const st = await fs.lstat(file);
  if (!st.isFile() || st.isSymbolicLink()) throw new Error(`${label} must be a regular non-symlink file`);
  if (process.platform !== 'win32') {
    await fs.chmod(file, 0o600);
    const secured = await fs.stat(file);
    if ((secured.mode & 0o077) !== 0) throw new Error(`${label} permissions must be 0600 or stricter`);
  }
  return file;
}
async function sha256(file) { return crypto.createHash('sha256').update(await fs.readFile(file)).digest('hex'); }
function validateDrillConsistency({ sourceHashBefore, sourceHashAfter, backupHash, restoredHash, sourceValidation, backupValidation, restoredValidation }) {
  const validDb = v => v && v.integrity === 'ok' && v.foreignKeyViolations === 0 &&
    Number.isInteger(v.userTableCount) && v.userTableCount >= 0 && Array.isArray(v.userTables) &&
    v.userTableCount === v.userTables.length && v.userTables.every(x => typeof x === 'string');
  if (![sourceHashBefore, sourceHashAfter, backupHash, restoredHash].every(x => typeof x === 'string' && /^[a-f0-9]{64}$/.test(x))) {
    throw new Error('Restore drill SHA-256 evidence is missing or invalid');
  }
  if (sourceHashBefore !== sourceHashAfter) throw new Error('Source database changed during restore drill; result must be blocked');
  if (backupHash !== restoredHash) throw new Error('Restored copy hash differs from backup artifact');
  if (![sourceValidation, backupValidation, restoredValidation].every(validDb)) throw new Error('Database integrity or foreign-key validation failed');
  const sameTables = (a,b) => a.userTableCount === b.userTableCount && JSON.stringify(a.userTables) === JSON.stringify(b.userTables);
  if (!sameTables(sourceValidation, backupValidation) || !sameTables(backupValidation, restoredValidation)) {
    throw new Error('Source, backup, and restored table inventories differ');
  }
  return { consistent: true, sourceStable: true, backupMatchesRestored: true, tableInventoryMatches: true };
}
function sidecarPaths(source) {
  return [`${source}-wal`, `${source}-shm`];
}
function sameResolvedPath(a, b) { return path.resolve(a) === path.resolve(b); }
function verifyEvidenceRoot(source, evidence) {
  if (sameResolvedPath(source, evidence) || source.startsWith(evidence + path.sep)) {
    throw new Error('source database must be outside evidenceDir');
  }
  if (evidence.startsWith(path.dirname(source) + path.sep) && source.startsWith(evidence + path.sep)) {
    throw new Error('evidenceDir cannot contain source database');
  }
}
async function inspectSqliteSidecars(source) {
  const found = [];
  for (const sidecar of sidecarPaths(source)) {
    try {
      const st = await fs.lstat(sidecar);
      if (st.isSymbolicLink() || !st.isFile()) throw new Error(`SQLite sidecar ${path.basename(sidecar)} is not a regular file`);
      found.push({ path: sidecar, size: st.size });
    } catch (err) {
      if (err.code === 'ENOENT') continue;
      throw err;
    }
  }
  return found;
}
async function checkOutputCollisions(evidence, id) {
  const outputs = [
    path.join(evidence, `${id}.sqlite-backup.db`),
    path.join(evidence, `${id}.sqlite-restored.db`),
    path.join(evidence, `${id}.restore-drill.json`)
  ];
  for (const output of outputs) {
    try {
      await fs.lstat(output);
      throw new Error(`Restore-drill output already exists; refusing overwrite: ${path.basename(output)}`);
    } catch (err) {
      if (err.code === 'ENOENT') continue;
      throw err;
    }
  }
  return outputs;
}

async function acquireRestoreDrillLock(evidence, id) {
  const lockPath = path.join(evidence, `${id}.restore-drill.lock`);
  let handle;
  try {
    handle = await fs.open(lockPath, 'wx', 0o600);
  } catch (err) {
    if (err && err.code === 'EEXIST') {
      throw new Error(`Restore drill already running or stale lock exists; refusing concurrent run: ${path.basename(lockPath)}`);
    }
    throw err;
  }
  const owned = await handle.stat();
  try {
    await handle.writeFile(JSON.stringify({
      schemaVersion: 1,
      type: 'RLA_NATIVE_SQLITE_RESTORE_DRILL_LOCK',
      runId: id,
      pid: process.pid,
      createdAt: new Date().toISOString()
    }) + '\n', 'utf8');
    await handle.sync();
  } catch (err) {
    await handle.close().catch(() => {});
    try {
      const current = await fs.lstat(lockPath);
      if (current.dev === owned.dev && current.ino === owned.ino) await fs.unlink(lockPath);
    } catch (_) { /* Preserve original lock-write error. */ }
    throw err;
  }
  return async function releaseRestoreDrillLock() {
    await handle.close();
    // Only unlink the same file this process created. Never remove a replacement.
    const current = await fs.lstat(lockPath).catch(err => err.code === 'ENOENT' ? null : Promise.reject(err));
    if (current && current.dev === owned.dev && current.ino === owned.ino && current.isFile() && !current.isSymbolicLink()) {
      await fs.unlink(lockPath);
    }
  };
}

async function runNativeRestoreDrill({ sourceDbPath, evidenceDir, runId, sqlite3Module }) {
  const preflight = await preflightRestoreDrill({ sourceDbPath, evidenceDir, runId });
  const { runId: id, source, evidence } = preflight;
  const releaseLock = await acquireRestoreDrillLock(evidence, id);
  try {
  // Sidecar and collision checks are repeated immediately before native access.
  // This narrows (but cannot eliminate) races; production must quiesce writers or use SQLite's online backup API.
  const sidecarsBeforeOpen = await inspectSqliteSidecars(source);
  if (sidecarsBeforeOpen.length) throw new Error('SQLite WAL/SHM sidecar exists; native restore drill blocked pending controlled WAL-aware procedure');
  await checkOutputCollisions(evidence, id);
  const sqlite3 = sqlite3Module || loadNativeSqlite3();
  if (!sqlite3 || typeof sqlite3.Database !== 'function' || typeof sqlite3.OPEN_READONLY !== 'number') throw new Error('Native sqlite3 module interface is invalid');
  const backup = path.join(evidence, `${id}.sqlite-backup.db`);
  const restored = path.join(evidence, `${id}.sqlite-restored.db`);
  const manifestPath = path.join(evidence, `${id}.restore-drill.json`);
  const sourceHashBefore = await sha256(source);
  const sourceDb = await openDb(sqlite3, source, sqlite3.OPEN_READONLY);
  let sourceValidation;
  try {
    sourceValidation = await validateDb(sqlite3, source);
    await backupDb(sourceDb, backup);
  } finally { await close(sourceDb); }
  await enforcePrivateArtifact(backup, 'backup artifact');
  const sidecarsAfterBackup = await inspectSqliteSidecars(source);
  if (sidecarsAfterBackup.length) throw new Error('SQLite WAL/SHM sidecar appeared during backup; drill result blocked');
  const backupValidation = await validateDb(sqlite3, backup);
  await fs.copyFile(backup, restored, require('node:fs').constants.COPYFILE_EXCL);
  await enforcePrivateArtifact(restored, 'restored artifact');
  const restoredValidation = await validateDb(sqlite3, restored);
  const sourceHashAfter = await sha256(source);
  const backupHash = await sha256(backup);
  const restoredHash = await sha256(restored);
  const consistency = validateDrillConsistency({
    sourceHashBefore, sourceHashAfter, backupHash, restoredHash,
    sourceValidation, backupValidation, restoredValidation
  });
  const manifest = {
    schemaVersion: 1, type: 'RLA_NATIVE_SQLITE_RESTORE_DRILL', runId: id,
    completedAt: new Date().toISOString(), driver: 'npm sqlite3 native',
    source: { sha256Before: sourceHashBefore, sha256After: sourceHashAfter, validation: sourceValidation },
    backup: { file: path.basename(backup), sha256: backupHash, validation: backupValidation },
    restored: { file: path.basename(restored), sha256: restoredHash, validation: restoredValidation },
    consistency, result: 'PASS', scope: 'isolated restore copy only; no production database replacement performed'
  };
  const fh = await fs.open(manifestPath, 'wx', 0o600);
  try { await fh.writeFile(JSON.stringify(manifest, null, 2) + '\n', 'utf8'); await fh.sync(); } finally { await fh.close(); }
  return { manifestPath, backupPath: backup, restoredPath: restored, manifest };
  } finally {
    await releaseLock();
  }
}
module.exports = { safeRunId, loadNativeSqlite3, runNativeRestoreDrill, validateDrillConsistency, preflightRestoreDrill, inspectSqliteSidecars, checkOutputCollisions, acquireRestoreDrillLock, enforcePrivateArtifact };
