'use strict';
const crypto = require('node:crypto');
const fs = require('node:fs/promises');
const fsc = require('node:fs').constants;
const path = require('node:path');

const MAX_REVIEW_AGE_MS = 90 * 24 * 60 * 60 * 1000;
const MAX_MANIFEST_BYTES = 1024 * 1024;
const MAX_JSON_DEPTH = 64;
const MAX_JSON_NODES = 25000;
const REQUIRED_GATES = Object.freeze([
  'native_sqlite3_backup_restore',
  'wal_crash_recovery_restore_drill',
  'production_audit_workflow_integration',
  'independent_worm_storage',
  'independent_security_review',
  'penetration_test',
  'user_acceptance_testing',
  'formal_release_approval'
]);
function isObject(v) { return !!v && typeof v === 'object' && !Array.isArray(v); }
function sha256(buf) { return crypto.createHash('sha256').update(buf).digest('hex'); }
function decimalSignature(token) {
  const match = /^(-?)(\d+)(?:\.(\d+))?(?:[eE]([+-]?\d+))?$/.exec(token);
  if (!match) return null;
  const negative = match[1] === '-';
  const fraction = match[3] || '';
  let digits = (match[2] + fraction).replace(/^0+/, '');
  if (!digits) return '0';
  let exponent = Number(match[4] || 0) - fraction.length;
  if (!Number.isSafeInteger(exponent)) return null;
  while (digits.length > 1 && digits.endsWith('0')) {
    digits = digits.slice(0, -1);
    exponent++;
  }
  return `${negative ? '-' : '+'}${digits}e${exponent}`;
}
function hasLoneSurrogate(value) {
  for (let i = 0; i < value.length; i++) {
    const code = value.charCodeAt(i);
    if (code >= 0xd800 && code <= 0xdbff) {
      const next = value.charCodeAt(i + 1);
      if (!(next >= 0xdc00 && next <= 0xdfff)) return true;
      i++;
    } else if (code >= 0xdc00 && code <= 0xdfff) return true;
  }
  return false;
}
// JSON.parse silently accepts duplicate object keys and keeps the last value. Release
// evidence manifests must be unambiguous across parsers, so reject duplicate keys at
// every object depth before returning the parsed value.
function parseJsonNoDuplicateKeys(input) {
  // Bound the parser itself as well as file reads so direct callers cannot bypass
  // the manifest size policy. Only bytes or primitive strings are accepted.
  if (!Buffer.isBuffer(input) && typeof input !== 'string') {
    throw Object.assign(new TypeError('JSON manifest input must be a Buffer or string'), { code: 'RLA_JSON_INPUT_TYPE_INVALID' });
  }
  const inputBytes = Buffer.isBuffer(input) ? input.length : Buffer.byteLength(input, 'utf8');
  if (inputBytes > MAX_MANIFEST_BYTES) {
    throw Object.assign(new SyntaxError('maximum manifest byte size exceeded'), { code: 'RLA_MANIFEST_TOO_LARGE' });
  }
  // A UTF-8 BOM is not permitted in the release manifest. Some decoders silently
  // consume it, which can make byte-level evidence differ from the parsed document.
  if (Buffer.isBuffer(input) && input.length >= 3 && input[0] === 0xef && input[1] === 0xbb && input[2] === 0xbf) {
    throw Object.assign(new SyntaxError('UTF-8 BOM is not permitted in JSON manifest'), { code: 'RLA_JSON_BOM_NOT_ALLOWED' });
  }
  const source = Buffer.isBuffer(input) ? new TextDecoder('utf-8', { fatal: true, ignoreBOM: true }).decode(input) : String(input);
  if (source.charCodeAt(0) === 0xfeff) {
    throw Object.assign(new SyntaxError('UTF-8 BOM is not permitted in JSON manifest'), { code: 'RLA_JSON_BOM_NOT_ALLOWED' });
  }
  let i = 0;
  let nodeCount = 0;
  const isJsonWhitespace = ch => ch === ' ' || ch === '\t' || ch === '\r' || ch === '\n';
  const ws = () => { while (i < source.length && isJsonWhitespace(source[i])) i++; };
  function stringToken() {
    const start = i;
    if (source[i] !== '"') throw new SyntaxError('expected JSON string');
    i++;
    while (i < source.length) {
      const ch = source[i++];
      if (ch === '\\') { if (i < source.length) i++; continue; }
      if (ch === '"') {
        const parsed = JSON.parse(source.slice(start, i));
        if (hasLoneSurrogate(parsed)) throw Object.assign(new SyntaxError('lone UTF-16 surrogate is not permitted in JSON strings'), { code: 'RLA_JSON_LONE_SURROGATE' });
        return parsed;
      }
    }
    throw new SyntaxError('unterminated JSON string');
  }
  function value(depth = 0) {
    ws();
    nodeCount++;
    if (nodeCount > MAX_JSON_NODES) {
      throw Object.assign(new SyntaxError('maximum JSON node count exceeded'), { code: 'RLA_JSON_MAX_NODES' });
    }
    if ((source[i] === '{' || source[i] === '[') && depth >= MAX_JSON_DEPTH) {
      throw Object.assign(new SyntaxError('maximum JSON nesting depth exceeded'), { code: 'RLA_JSON_MAX_DEPTH' });
    }
    if (source[i] === '{') {
      i++; ws(); const out = Object.create(null); const keys = new Set();
      if (source[i] === '}') { i++; return out; }
      while (i < source.length) {
        ws(); const key = stringToken();
        if (keys.has(key)) throw Object.assign(new SyntaxError(`duplicate JSON object key: ${key}`), { code: 'RLA_DUPLICATE_JSON_KEY' });
        keys.add(key); ws();
        if (source[i++] !== ':') throw new SyntaxError('expected colon after JSON object key');
        out[key] = value(depth + 1); ws();
        if (source[i] === '}') { i++; return out; }
        if (source[i++] !== ',') throw new SyntaxError('expected comma in JSON object');
      }
      throw new SyntaxError('unterminated JSON object');
    }
    if (source[i] === '[') {
      i++; ws(); const out = [];
      if (source[i] === ']') { i++; return out; }
      while (i < source.length) {
        out.push(value(depth + 1)); ws();
        if (source[i] === ']') { i++; return out; }
        if (source[i++] !== ',') throw new SyntaxError('expected comma in JSON array');
      }
      throw new SyntaxError('unterminated JSON array');
    }
    if (source[i] === '"') return stringToken();
    const start = i;
    while (i < source.length && !isJsonWhitespace(source[i]) && !/[ ,\]}]/.test(source[i])) i++;
    if (start === i) throw new SyntaxError('expected JSON value');
    const token = source.slice(start, i);
    const parsed = JSON.parse(token);
    if (parsed !== null && typeof parsed === 'object') throw new SyntaxError('invalid JSON value');
    // JSON's numeric grammar permits large exponents, but JavaScript JSON.parse
    // can turn them into Infinity. Reject values that cannot be represented as
    // finite IEEE-754 numbers so different consumers cannot disagree on evidence.
    if (typeof parsed === 'number' && !Number.isFinite(parsed)) {
      throw Object.assign(new SyntaxError('non-finite JSON number is not permitted'), { code: 'RLA_JSON_NUMBER_NOT_FINITE' });
    }
    // A non-zero JSON numeric token that rounds all the way to zero has silently
    // underflowed in IEEE-754. Reject it rather than letting evidence fields change
    // meaning when consumed by JavaScript-based tooling.
    if (typeof parsed === 'number' && parsed === 0 && /[1-9]/.test(token.replace(/[eE].*$/, '').replace(/[+.-]/g, ''))) {
      throw Object.assign(new SyntaxError('JSON number underflows to zero'), { code: 'RLA_JSON_NUMBER_UNDERFLOW' });
    }
    // JavaScript Number cannot exactly represent every integer outside the safe
    // integer range. Reject such values rather than silently rounding evidence
    // fields differently from arbitrary-precision JSON consumers.
    if (typeof parsed === 'number' && Number.isInteger(parsed) && !Number.isSafeInteger(parsed)) {
      throw Object.assign(new SyntaxError('unsafe JSON integer is not permitted'), { code: 'RLA_JSON_INTEGER_NOT_SAFE' });
    }
    // Even finite, non-integer values can silently lose decimal precision (for
    // example 0.10000000000000001 becoming 0.1). Compare normalized decimal
    // signatures for the source token and Number#toString output. Exempt zero
    // because JSON explicitly permits -0 and underflow is checked above.
    if (typeof parsed === 'number' && parsed !== 0) {
      const signature = decimalSignature(token);
      const roundTrip = decimalSignature(parsed.toString());
      if (!signature || !roundTrip || signature !== roundTrip) {
        throw Object.assign(new SyntaxError('JSON number loses decimal precision in IEEE-754'), { code: 'RLA_JSON_NUMBER_PRECISION_LOSS' });
      }
    }
    return parsed;
  }
  const result = value(); ws();
  if (i !== source.length) throw new SyntaxError('trailing data after JSON value');
  return result;
}
function reviewTimestampIssue(value, now = Date.now()) {
  // Require canonical UTC seconds, reject future approvals, and expire review evidence after 90 days.
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/.test(value)) return 'INVALID';
  const ms = Date.parse(value);
  if (!Number.isFinite(ms) || new Date(ms).toISOString().replace('.000Z', 'Z') !== value) return 'INVALID';
  if (ms > now) return 'FUTURE';
  if (now - ms > MAX_REVIEW_AGE_MS) return 'STALE';
  return null;
}
function isValidReviewTimestamp(value, now = Date.now()) {
  return reviewTimestampIssue(value, now) === null;
}
function safeEvidencePath(value) {
  if (typeof value !== 'string' || value.length === 0 || path.isAbsolute(value) || value.includes('\\')) return false;
  const parts = value.split('/');
  return parts.every(p => p && p !== '.' && p !== '..' && /^[A-Za-z0-9._-]+$/.test(p));
}
async function readRegularNoFollow(file, { maxBytes = Infinity } = {}) {
  const noFollow = typeof fsc.O_NOFOLLOW === 'number' ? fsc.O_NOFOLLOW : 0;
  const handle = await fs.open(file, fsc.O_RDONLY | noFollow);
  try {
    const st = await handle.stat();
    if (!st.isFile()) throw Object.assign(new Error('not a regular file'), { code: 'RLA_NOT_REGULAR_FILE' });
    if (st.size > maxBytes) throw Object.assign(new Error('file exceeds configured size limit'), { code: 'RLA_FILE_TOO_LARGE' });
    if (Number.isInteger(st.nlink) && st.nlink !== 1) throw Object.assign(new Error('file must have exactly one hard link'), { code: 'RLA_HARDLINK_BLOCKED' });
    if (process.platform !== 'win32' && (st.mode & 0o077) !== 0) throw Object.assign(new Error('file permissions are not private'), { code: 'RLA_PERMISSIONS_NOT_PRIVATE' });
    const bytes = await handle.readFile();
    if (bytes.length > maxBytes) throw Object.assign(new Error('file exceeds configured size limit'), { code: 'RLA_FILE_TOO_LARGE' });
    return { bytes, stat: st };
  } finally { await handle.close(); }
}
async function rejectSymlinkPath(root, relative) {
  const parts = relative.split('/');
  let current = root;
  for (let i = 0; i < parts.length; i++) {
    current = path.join(current, parts[i]);
    const st = await fs.lstat(current);
    if (st.isSymbolicLink()) throw Object.assign(new Error('symlink path component'), { code: 'RLA_SYMLINK_PATH' });
    if (i < parts.length - 1 && !st.isDirectory()) throw Object.assign(new Error('non-directory path component'), { code: 'RLA_BAD_PATH_COMPONENT' });
    if (i < parts.length - 1 && process.platform !== 'win32' && (st.mode & 0o077) !== 0) {
      throw Object.assign(new Error('intermediate evidence directory permissions are not private'), { code: 'RLA_DIRECTORY_PERMISSIONS_NOT_PRIVATE' });
    }
  }
  return current;
}
/**
 * Fail-closed verification of external release-gate evidence.
 * This evaluates evidence completeness/integrity only; it never grants release authority.
 * Evidence roots must be private and evidence/manifest files are opened without following symlinks.
 */
async function evaluateReleaseGates({ manifestPath, evidenceRoot }) {
  const root = path.resolve(evidenceRoot);
  const rootStat = await fs.lstat(root);
  if (!rootStat.isDirectory() || rootStat.isSymbolicLink()) throw new Error('evidenceRoot must be a regular non-symlink directory');
  if (process.platform !== 'win32' && (rootStat.mode & 0o077) !== 0) throw new Error('evidenceRoot must be private (mode 0700)');
  let manifestBytes;
  try { manifestBytes = (await readRegularNoFollow(path.resolve(manifestPath), { maxBytes: MAX_MANIFEST_BYTES })).bytes; }
  catch (err) { throw new Error(`manifestPath must be a regular non-symlink file within ${MAX_MANIFEST_BYTES} bytes (${err.code || 'READ_FAILED'})`); }
  let manifest;
  try { manifest = parseJsonNoDuplicateKeys(manifestBytes); }
  catch (err) {
    if (err && err.code === 'RLA_DUPLICATE_JSON_KEY') throw new Error('manifest JSON contains duplicate object keys');
    throw new Error('manifest JSON is invalid');
  }
  if (!isObject(manifest) || manifest.schemaVersion !== 1 || manifest.releaseTrack !== 'NOT_RELEASE' || !Array.isArray(manifest.gates)) throw new Error('release-gate manifest schema/track is invalid');
  const byId = new Map();
  for (const gate of manifest.gates) {
    if (!isObject(gate) || typeof gate.gateId !== 'string' || byId.has(gate.gateId)) throw new Error('invalid or duplicate gateId');
    if (!REQUIRED_GATES.includes(gate.gateId)) throw new Error('unknown gateId');
    byId.set(gate.gateId, gate);
  }
  const results = [];
  for (const gateId of REQUIRED_GATES) {
    const gate = byId.get(gateId);
    if (!gate) { results.push({ gateId, status: 'BLOCKED', reason: 'REQUIRED_GATE_MISSING' }); continue; }
    if (gate.status !== 'PASS') { results.push({ gateId, status: 'BLOCKED', reason: gate.reason || 'EVIDENCE_NOT_APPROVED' }); continue; }
    if (!safeEvidencePath(gate.evidenceFile) || !/^[a-f0-9]{64}$/.test(gate.sha256 || '') || typeof gate.reviewedBy !== 'string' || !gate.reviewedBy.trim() || typeof gate.approvalRef !== 'string' || !gate.approvalRef.trim()) {
      results.push({ gateId, status: 'BLOCKED', reason: 'EVIDENCE_METADATA_INVALID' }); continue;
    }
    const timestampIssue = reviewTimestampIssue(gate.reviewedAt);
    if (timestampIssue) {
      const reason = timestampIssue === 'STALE' ? 'EVIDENCE_REVIEW_STALE' : timestampIssue === 'FUTURE' ? 'EVIDENCE_REVIEW_TIMESTAMP_FUTURE' : 'EVIDENCE_METADATA_INVALID';
      results.push({ gateId, status: 'BLOCKED', reason }); continue;
    }
    try {
      const file = await rejectSymlinkPath(root, gate.evidenceFile);
      const { bytes } = await readRegularNoFollow(file);
      const digest = sha256(bytes);
      if (digest !== gate.sha256) { results.push({ gateId, status: 'BLOCKED', reason: 'EVIDENCE_DIGEST_MISMATCH' }); continue; }
      results.push({ gateId, status: 'PASS', evidenceFile: gate.evidenceFile, sha256: digest, reviewedBy: gate.reviewedBy, reviewedAt: new Date(Date.parse(gate.reviewedAt)).toISOString(), approvalRef: gate.approvalRef });
    } catch (err) {
      let reason = 'EVIDENCE_FILE_UNREADABLE';
      if (err.code === 'ENOENT') reason = 'EVIDENCE_FILE_MISSING';
      else if (err.code === 'RLA_NOT_REGULAR_FILE') reason = 'EVIDENCE_NOT_REGULAR_FILE';
      else if (err.code === 'RLA_HARDLINK_BLOCKED') reason = 'EVIDENCE_HARDLINK_BLOCKED';
      else if (err.code === 'RLA_PERMISSIONS_NOT_PRIVATE') reason = 'EVIDENCE_PERMISSIONS_NOT_PRIVATE';
      else if (err.code === 'RLA_DIRECTORY_PERMISSIONS_NOT_PRIVATE') reason = 'EVIDENCE_DIRECTORY_PERMISSIONS_NOT_PRIVATE';
      else if (err.code === 'RLA_SYMLINK_PATH' || err.code === 'ELOOP') reason = 'EVIDENCE_SYMLINK_BLOCKED';
      else if (err.code === 'RLA_BAD_PATH_COMPONENT') reason = 'EVIDENCE_PATH_COMPONENT_INVALID';
      results.push({ gateId, status: 'BLOCKED', reason });
    }
  }
  const passed = results.filter(x => x.status === 'PASS').length;
  return { schemaVersion: 1, candidateTrack: 'NOT_RELEASE', releaseStatus: 'RELEASE_BLOCKED', releaseAuthorityGranted: false, requiredGateCount: REQUIRED_GATES.length, passedGateCount: passed, blockedGateCount: REQUIRED_GATES.length - passed, gates: results };
}
module.exports = { REQUIRED_GATES, MAX_REVIEW_AGE_MS, MAX_MANIFEST_BYTES, MAX_JSON_DEPTH, MAX_JSON_NODES, evaluateReleaseGates, isValidReviewTimestamp, reviewTimestampIssue, parseJsonNoDuplicateKeys };
