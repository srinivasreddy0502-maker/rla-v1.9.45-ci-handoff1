'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const MANIFEST_SCHEMA_VERSION = 1;

function toPosixPath(value) { return value.split(path.sep).join('/'); }
function isSafeRelativePath(value) {
  return typeof value === 'string' && value.length > 0 &&
    !value.startsWith('/') && !value.includes('\\') &&
    value.split('/').every(part => part && part !== '.' && part !== '..');
}
function sha256File(filePath) {
  const hash = crypto.createHash('sha256');
  hash.update(fs.readFileSync(filePath));
  return hash.digest('hex');
}
function walkFiles(rootDir, relativeDir = '') {
  const absoluteDir = path.join(rootDir, relativeDir);
  const entries = fs.readdirSync(absoluteDir, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name, 'en'));
  const files = [];
  for (const entry of entries) {
    const relativePath = relativeDir ? `${relativeDir}/${entry.name}` : entry.name;
    const absolutePath = path.join(rootDir, ...relativePath.split('/'));
    if (entry.isSymbolicLink()) throw new Error(`SYMLINK_NOT_ALLOWED:${relativePath}`);
    if (entry.isDirectory()) files.push(...walkFiles(rootDir, relativePath));
    else if (entry.isFile()) files.push({ relativePath, absolutePath });
    else throw new Error(`NON_REGULAR_FILE_NOT_ALLOWED:${relativePath}`);
  }
  return files;
}
function createPackageIntegrityManifest({ rootDir, manifestPath, generatedAt = new Date().toISOString() }) {
  const root = path.resolve(rootDir);
  const output = path.resolve(manifestPath);
  const relativeManifest = toPosixPath(path.relative(root, output));
  if (!isSafeRelativePath(relativeManifest)) throw new Error('MANIFEST_PATH_MUST_BE_INSIDE_PACKAGE_ROOT');
  const packageJsonPath = path.join(root, 'package.json');
  let packageJson;
  try { packageJson = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8')); }
  catch { throw new Error('PACKAGE_JSON_MISSING_OR_INVALID'); }
  const files = walkFiles(root)
    .filter(item => item.relativePath !== relativeManifest)
    .map(item => ({ path: item.relativePath, sizeBytes: fs.statSync(item.absolutePath).size, sha256: sha256File(item.absolutePath) }))
    .sort((a, b) => a.path.localeCompare(b.path, 'en'));
  return {
    schemaVersion: MANIFEST_SCHEMA_VERSION,
    manifestType: 'RLA_PACKAGE_INTEGRITY_MANIFEST',
    algorithm: 'SHA-256',
    packageName: typeof packageJson.name === 'string' ? packageJson.name : null,
    packageVersion: typeof packageJson.version === 'string' ? packageJson.version : null,
    generatedAt,
    entryCount: files.length,
    entries: files
  };
}
function validateManifest(manifest) {
  if (!manifest || typeof manifest !== 'object' || Array.isArray(manifest) ||
      manifest.schemaVersion !== MANIFEST_SCHEMA_VERSION ||
      manifest.manifestType !== 'RLA_PACKAGE_INTEGRITY_MANIFEST' ||
      manifest.algorithm !== 'SHA-256' || !Array.isArray(manifest.entries) ||
      manifest.entryCount !== manifest.entries.length) return ['MANIFEST_SCHEMA_INVALID'];
  const blockers = [];
  const seen = new Set();
  for (const entry of manifest.entries) {
    if (!entry || typeof entry !== 'object' || !isSafeRelativePath(entry.path) ||
        !Number.isSafeInteger(entry.sizeBytes) || entry.sizeBytes < 0 ||
        typeof entry.sha256 !== 'string' || !/^[a-f0-9]{64}$/.test(entry.sha256)) {
      blockers.push('MANIFEST_ENTRY_INVALID');
      continue;
    }
    if (seen.has(entry.path)) blockers.push(`MANIFEST_DUPLICATE_PATH:${entry.path}`);
    seen.add(entry.path);
  }
  return [...new Set(blockers)];
}
function verifyPackageIntegrityManifest({ rootDir, manifestPath }) {
  const root = path.resolve(rootDir);
  const output = path.resolve(manifestPath);
  const relativeManifest = toPosixPath(path.relative(root, output));
  if (!isSafeRelativePath(relativeManifest)) return { status: 'BLOCKED', blockers: ['MANIFEST_PATH_MUST_BE_INSIDE_PACKAGE_ROOT'], verifiedCount: 0, productionUseAuthorized: false };
  let manifest;
  try { manifest = JSON.parse(fs.readFileSync(output, 'utf8')); }
  catch { return { status: 'BLOCKED', blockers: ['MANIFEST_MISSING_OR_INVALID_JSON'], verifiedCount: 0, productionUseAuthorized: false }; }
  const blockers = validateManifest(manifest);
  if (blockers.length) return { status: 'BLOCKED', blockers, verifiedCount: 0, productionUseAuthorized: false };
  let actualFiles;
  try { actualFiles = walkFiles(root).map(item => item.relativePath).filter(name => name !== relativeManifest).sort((a, b) => a.localeCompare(b, 'en')); }
  catch (error) { return { status: 'BLOCKED', blockers: [String(error.message || 'PACKAGE_TREE_INVALID')], verifiedCount: 0, productionUseAuthorized: false }; }
  const expectedFiles = manifest.entries.map(entry => entry.path).sort((a, b) => a.localeCompare(b, 'en'));
  const expectedSet = new Set(expectedFiles);
  const actualSet = new Set(actualFiles);
  for (const name of expectedFiles) if (!actualSet.has(name)) blockers.push(`PACKAGE_FILE_MISSING:${name}`);
  for (const name of actualFiles) if (!expectedSet.has(name)) blockers.push(`UNMANIFESTED_PACKAGE_FILE:${name}`);
  let verifiedCount = 0;
  for (const entry of manifest.entries) {
    if (!actualSet.has(entry.path)) continue;
    const filePath = path.join(root, ...entry.path.split('/'));
    try {
      const stat = fs.lstatSync(filePath);
      if (!stat.isFile() || stat.isSymbolicLink()) { blockers.push(`PACKAGE_FILE_TYPE_INVALID:${entry.path}`); continue; }
      if (stat.size !== entry.sizeBytes) { blockers.push(`PACKAGE_FILE_SIZE_MISMATCH:${entry.path}`); continue; }
      if (sha256File(filePath) !== entry.sha256) { blockers.push(`PACKAGE_FILE_HASH_MISMATCH:${entry.path}`); continue; }
      verifiedCount++;
    } catch { blockers.push(`PACKAGE_FILE_UNREADABLE:${entry.path}`); }
  }
  const uniqueBlockers = [...new Set(blockers)];
  return {
    schemaVersion: 1,
    check: 'PACKAGE_INTEGRITY_MANIFEST_VERIFICATION',
    status: uniqueBlockers.length ? 'BLOCKED' : 'PASS',
    blockers: uniqueBlockers,
    entryCount: manifest.entryCount,
    verifiedCount,
    packageName: manifest.packageName,
    packageVersion: manifest.packageVersion,
    productionUseAuthorized: false
  };
}
module.exports = { createPackageIntegrityManifest, verifyPackageIntegrityManifest, validateManifest };
