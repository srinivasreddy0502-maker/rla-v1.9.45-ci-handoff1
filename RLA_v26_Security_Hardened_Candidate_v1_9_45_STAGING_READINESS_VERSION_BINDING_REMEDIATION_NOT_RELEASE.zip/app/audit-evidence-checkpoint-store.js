'use strict';
const crypto = require('node:crypto');
const fs = require('node:fs/promises');
const path = require('node:path');
const { createAuditCheckpoint, verifyAuditCheckpoint } = require('./audit-evidence-checkpoint');

function requireKey(key) {
  if (typeof key !== 'string' || Buffer.byteLength(key, 'utf8') < 32) {
    throw new Error('Evidence store key must contain at least 32 UTF-8 bytes');
  }
}
function safeId(id) {
  if (typeof id !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9._-]{0,100}$/.test(id)) {
    throw new Error('checkpointId must use 1-101 safe filename characters');
  }
  return id;
}
function mac(payload, key) {
  return crypto.createHmac('sha256', key).update(JSON.stringify(payload), 'utf8').digest('hex');
}
async function validatePrivateDirectory(dir, label) {
  const resolved = path.resolve(dir);
  const st = await fs.lstat(resolved);
  if (!st.isDirectory() || st.isSymbolicLink()) throw new Error(`${label} must be a regular non-symlink directory`);
  if (process.platform !== 'win32' && (st.mode & 0o077) !== 0) throw new Error(`${label} must be private (mode 0700)`);
  return resolved;
}
async function hashFile(file) {
  return crypto.createHash('sha256').update(await fs.readFile(file)).digest('hex');
}

/**
 * Publishes an already signed checkpoint into a separately configured evidence store.
 * The store is append-only at the application layer (exclusive creation); true WORM,
 * independent media, and access separation must be provided by deployment controls.
 */
async function publishCheckpoint({ checkpointPath, storageDir, checkpointId, storeKey, storeKeyId, now = new Date() }) {
  requireKey(storeKey);
  const id = safeId(checkpointId);
  if (typeof storeKeyId !== 'string' || !/^[A-Za-z0-9._-]{1,64}$/.test(storeKeyId)) throw new Error('storeKeyId is invalid');
  const source = path.resolve(checkpointPath);
  const sourceStat = await fs.lstat(source);
  if (!sourceStat.isFile() || sourceStat.isSymbolicLink()) throw new Error('source checkpoint must be a regular non-symlink file');
  const store = await validatePrivateDirectory(storageDir, 'storageDir');
  if (path.dirname(source) === store) throw new Error('source checkpoint and evidence store must be separate directories');
  const bytes = await fs.readFile(source);
  const checkpoint = JSON.parse(bytes.toString('utf8'));
  const checkpointSha256 = crypto.createHash('sha256').update(bytes).digest('hex');
  const payload = {
    schemaVersion: 1,
    recordType: 'RLA_AUDIT_CHECKPOINT_STORE_RECEIPT',
    checkpointId: id,
    checkpointFile: `${id}.checkpoint.json`,
    checkpointSha256,
    storeKeyId,
    storedAt: now.toISOString()
  };
  const receipt = { ...payload, hmacSha256: mac(payload, storeKey) };
  const targetCheckpoint = path.join(store, payload.checkpointFile);
  const targetReceipt = path.join(store, `${id}.receipt.json`);
  // Create both files exclusively; on a partial failure, retain evidence and require operator reconciliation.
  const cp = await fs.open(targetCheckpoint, 'wx', 0o400);
  try { await cp.writeFile(bytes); await cp.sync(); } finally { await cp.close(); }
  try {
    const rh = await fs.open(targetReceipt, 'wx', 0o400);
    try { await rh.writeFile(JSON.stringify(receipt, null, 2) + '\n', 'utf8'); await rh.sync(); } finally { await rh.close(); }
  } catch (err) {
    throw new Error(`Checkpoint was copied but receipt creation failed; do not overwrite or delete evidence; reconcile manually: ${err.message}`);
  }
  return { checkpointPath: targetCheckpoint, receiptPath: targetReceipt, checkpointSha256, storeKeyId };
}
function verifyReceipt(receipt, storeKey) {
  requireKey(storeKey);
  if (!receipt || typeof receipt !== 'object' || Array.isArray(receipt) ||
      receipt.schemaVersion !== 1 || receipt.recordType !== 'RLA_AUDIT_CHECKPOINT_STORE_RECEIPT' ||
      !/^[A-Za-z0-9][A-Za-z0-9._-]{0,100}$/.test(receipt.checkpointId || '') ||
      receipt.checkpointFile !== `${receipt.checkpointId}.checkpoint.json` ||
      !/^[a-f0-9]{64}$/.test(receipt.checkpointSha256 || '') ||
      typeof receipt.storeKeyId !== 'string' || !/^[A-Za-z0-9._-]{1,64}$/.test(receipt.storeKeyId) ||
      !/^[a-f0-9]{64}$/.test(receipt.hmacSha256 || '')) throw new Error('Evidence-store receipt schema is invalid');
  const { hmacSha256, ...payload } = receipt;
  const expected = Buffer.from(mac(payload, storeKey), 'hex');
  const actual = Buffer.from(hmacSha256, 'hex');
  if (expected.length !== actual.length || !crypto.timingSafeEqual(expected, actual)) throw new Error('Evidence-store receipt HMAC verification failed');
  return true;
}
async function verifyStoredCheckpoint({ storageDir, checkpointId, storeKeys, checkpointKey, recordsDir }) {
  const id = safeId(checkpointId);
  const store = await validatePrivateDirectory(storageDir, 'storageDir');
  if (!storeKeys || typeof storeKeys !== 'object' || Array.isArray(storeKeys)) throw new Error('storeKeys keyring is required');
  const receiptPath = path.join(store, `${id}.receipt.json`);
  const checkpointPath = path.join(store, `${id}.checkpoint.json`);
  const receiptStat = await fs.lstat(receiptPath);
  const checkpointStat = await fs.lstat(checkpointPath);
  if (!receiptStat.isFile() || receiptStat.isSymbolicLink() || !checkpointStat.isFile() || checkpointStat.isSymbolicLink()) {
    throw new Error('Stored receipt and checkpoint must be regular non-symlink files');
  }
  const receipt = JSON.parse(await fs.readFile(receiptPath, 'utf8'));
  const key = storeKeys[receipt.storeKeyId];
  if (typeof key !== 'string') throw new Error(`No evidence-store verification key configured for key id: ${receipt.storeKeyId}`);
  verifyReceipt(receipt, key);
  const digest = await hashFile(checkpointPath);
  if (digest !== receipt.checkpointSha256) throw new Error('Stored checkpoint digest does not match signed receipt');
  const verified = await verifyAuditCheckpoint({ recordsDir, checkpointPath, key: checkpointKey });
  return { valid: true, checkpointId: id, storeKeyId: receipt.storeKeyId, checkpointSha256: digest, ...verified };
}
module.exports = { publishCheckpoint, verifyStoredCheckpoint, verifyReceipt, validatePrivateDirectory };
