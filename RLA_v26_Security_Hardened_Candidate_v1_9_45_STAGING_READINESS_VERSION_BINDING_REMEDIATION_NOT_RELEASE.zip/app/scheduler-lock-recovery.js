'use strict';
const crypto = require('node:crypto');
const path = require('node:path');
const { inspectSchedulerLock } = require('./scheduler-lock');

const REQUIRED_ATTESTATIONS = Object.freeze([
  'serviceStopped',
  'allWritersStopped',
  'processIdentityChecked',
  'backupBeforeRecoveryVerified',
  'changeWindowApproved'
]);

function canonicalPayload(record) {
  const { hmacSha256, ...payload } = record;
  return JSON.stringify(payload);
}
function requireKey(key) {
  if (typeof key !== 'string' || Buffer.byteLength(key, 'utf8') < 32) {
    throw new Error('RLA_SCHEDULER_RECOVERY_AUDIT_KEY must contain at least 32 UTF-8 bytes');
  }
}
function validateText(value, label, max = 160) {
  if (typeof value !== 'string' || value.trim().length < 2 || value.length > max || /[\r\n\0]/.test(value)) {
    throw new Error(`${label} is invalid`);
  }
  return value.trim();
}
function sign(payload, key) {
  return crypto.createHmac('sha256', key).update(canonicalPayload(payload), 'utf8').digest('hex');
}
async function createSchedulerRecoveryAuthorization({
  lockPath, operatorId, approverId, incidentRef, reason, attestations, key,
  processExists, now = new Date()
}) {
  requireKey(key);
  const normalizedOperator = validateText(operatorId, 'operatorId');
  const normalizedApprover = validateText(approverId, 'approverId');
  if (normalizedOperator.toLocaleLowerCase('en-US') === normalizedApprover.toLocaleLowerCase('en-US')) {
    throw new Error('Operator and independent approver must be different people');
  }
  const normalizedIncident = validateText(incidentRef, 'incidentRef', 100);
  if (!/^[A-Za-z0-9][A-Za-z0-9._:/-]{1,99}$/.test(normalizedIncident)) {
    throw new Error('incidentRef must be a ticket/change reference using safe characters');
  }
  const normalizedReason = validateText(reason, 'reason', 1000);
  if (!attestations || typeof attestations !== 'object' || Array.isArray(attestations) ||
      REQUIRED_ATTESTATIONS.some(name => attestations[name] !== true)) {
    throw new Error(`All required recovery attestations must be true: ${REQUIRED_ATTESTATIONS.join(', ')}`);
  }
  const inspectionOptions = { ...(processExists ? { processExists } : {}), now: now.getTime() };
  const inspection = await inspectSchedulerLock(lockPath, inspectionOptions);
  const payload = {
    schemaVersion: 1,
    recordType: 'RLA_SCHEDULER_LOCK_RECOVERY_AUTHORIZATION',
    createdAt: now.toISOString(),
    lockPath: path.resolve(lockPath),
    observedLock: {
      pid: inspection.pid,
      acquiredAt: inspection.acquiredAt,
      status: inspection.status,
      ageMs: inspection.ageMs
    },
    operatorId: normalizedOperator,
    independentApproverId: normalizedApprover,
    incidentRef: normalizedIncident,
    reason: normalizedReason,
    attestations: Object.fromEntries(REQUIRED_ATTESTATIONS.map(name => [name, true])),
    permittedAction: 'manual-review-only-no-automatic-lock-removal',
    automaticCleanup: false
  };
  return { ...payload, hmacSha256: sign(payload, key) };
}
function verifySchedulerRecoveryAuthorization(record, key) {
  requireKey(key);
  if (!record || typeof record !== 'object' || Array.isArray(record) || record.schemaVersion !== 1 ||
      record.recordType !== 'RLA_SCHEDULER_LOCK_RECOVERY_AUTHORIZATION' ||
      record.permittedAction !== 'manual-review-only-no-automatic-lock-removal' ||
      record.automaticCleanup !== false || typeof record.hmacSha256 !== 'string' ||
      !/^[a-f0-9]{64}$/.test(record.hmacSha256)) {
    throw new Error('Recovery authorization record schema is invalid');
  }
  if (record.operatorId === record.independentApproverId) {
    throw new Error('Recovery authorization does not have independent approval');
  }
  if (!record.attestations || REQUIRED_ATTESTATIONS.some(name => record.attestations[name] !== true)) {
    throw new Error('Recovery authorization is missing required attestations');
  }
  const expected = Buffer.from(sign(record, key), 'hex');
  const actual = Buffer.from(record.hmacSha256, 'hex');
  if (expected.length !== actual.length || !crypto.timingSafeEqual(expected, actual)) {
    throw new Error('Recovery authorization HMAC verification failed');
  }
  return { valid: true, automaticCleanup: false, permittedAction: record.permittedAction };
}
module.exports = { REQUIRED_ATTESTATIONS, createSchedulerRecoveryAuthorization, verifySchedulerRecoveryAuthorization };
