'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { DEFAULT_APPROVED_HOSTS, isSafeExactVersion, parseApprovedHosts } = require('./dependency-lockfile-preflight');

function parseExplicitRegistry(value, approvedHosts = [...DEFAULT_APPROVED_HOSTS]) {
  if (typeof value !== 'string' || !value.trim()) throw new TypeError('RLA_APPROVED_NPM_REGISTRY must be explicitly configured');
  let url;
  try { url = new URL(value); } catch { throw new TypeError('RLA_APPROVED_NPM_REGISTRY must be a valid URL'); }
  if (url.protocol !== 'https:' || url.username || url.password || url.port || url.search || url.hash || !['', '/'].includes(url.pathname) || !approvedHosts.includes(url.hostname.toLowerCase())) {
    throw new TypeError('RLA_APPROVED_NPM_REGISTRY must be an approved HTTPS registry origin without credentials, path, port, query, or fragment');
  }
  return `https://${url.hostname.toLowerCase()}/`;
}

function inspectCandidateRoot(rootDir) {
  const result = { safe: false, canonicalRoot: null, blockers: [] };
  if (typeof rootDir !== 'string' || !rootDir.trim()) {
    result.blockers.push('CANDIDATE_ROOT_INVALID');
    return result;
  }
  let stat;
  try { stat = fs.lstatSync(rootDir); }
  catch { result.blockers.push('CANDIDATE_ROOT_UNAVAILABLE'); return result; }
  if (stat.isSymbolicLink() || !stat.isDirectory()) {
    result.blockers.push('CANDIDATE_ROOT_MUST_BE_REAL_DIRECTORY');
    return result;
  }
  let canonical;
  try { canonical = fs.realpathSync(rootDir); }
  catch { result.blockers.push('CANDIDATE_ROOT_CANONICALIZATION_FAILED'); return result; }
  if (path.resolve(rootDir) !== canonical) {
    result.blockers.push('CANDIDATE_ROOT_PATH_NOT_CANONICAL');
    return result;
  }
  result.safe = true;
  result.canonicalRoot = canonical;
  return result;
}

function inspectRegularFile(filePath, missingCode, unsafeCode) {
  try {
    const stat = fs.lstatSync(filePath);
    if (stat.isSymbolicLink() || !stat.isFile()) return { ok: false, code: unsafeCode };
    return { ok: true };
  } catch (error) {
    if (error.code === 'ENOENT') return { ok: false, code: missingCode };
    return { ok: false, code: unsafeCode };
  }
}

// Read the package manifest through a descriptor opened with O_NOFOLLOW. This
// closes the lstat-then-read symlink swap window on platforms that support it.
// Fail closed where O_NOFOLLOW is unavailable; this planner must not silently
// downgrade to a path-based read.
function readRegularFileNoFollow(filePath) {
  const noFollow = fs.constants.O_NOFOLLOW;
  if (!Number.isInteger(noFollow) || noFollow === 0) {
    return { ok: false, code: 'PACKAGE_JSON_NOFOLLOW_UNAVAILABLE' };
  }
  let fd;
  try {
    fd = fs.openSync(filePath, fs.constants.O_RDONLY | noFollow);
    const before = fs.fstatSync(fd, { bigint: true });
    if (!before.isFile()) return { ok: false, code: 'PACKAGE_JSON_PATH_UNSAFE' };
    const content = fs.readFileSync(fd, 'utf8');
    const after = fs.fstatSync(fd, { bigint: true });
    if (!after.isFile() || before.dev !== after.dev || before.ino !== after.ino ||
        before.size !== after.size || before.mtimeNs !== after.mtimeNs ||
        BigInt(Buffer.byteLength(content, 'utf8')) !== after.size) {
      return { ok: false, code: 'PACKAGE_JSON_CHANGED_DURING_READ' };
    }
    return { ok: true, content };
  } catch (error) {
    if (error.code === 'ENOENT') return { ok: false, code: 'PACKAGE_JSON_MISSING_OR_INVALID' };
    return { ok: false, code: 'PACKAGE_JSON_PATH_UNSAFE' };
  } finally {
    if (fd !== undefined) {
      try { fs.closeSync(fd); } catch {}
    }
  }
}

function buildLockfileAcquisitionPlan({ rootDir, registryValue, approvedHosts = [...DEFAULT_APPROVED_HOSTS] }) {
  const blockers = [];
  let registry = null;
  try { registry = parseExplicitRegistry(registryValue, approvedHosts); }
  catch (error) { blockers.push(`APPROVED_REGISTRY_INVALID:${error.message}`); }

  const root = inspectCandidateRoot(rootDir);
  blockers.push(...root.blockers);
  let pkg;
  if (root.safe) {
    const packagePath = path.join(root.canonicalRoot, 'package.json');
    const lockPath = path.join(root.canonicalRoot, 'package-lock.json');
    const packageCheck = inspectRegularFile(packagePath, 'PACKAGE_JSON_MISSING_OR_INVALID', 'PACKAGE_JSON_PATH_UNSAFE');
    if (!packageCheck.ok) {
      blockers.push(packageCheck.code);
    } else {
      const readResult = readRegularFileNoFollow(packagePath);
      if (!readResult.ok) {
        blockers.push(readResult.code);
      } else {
        try { pkg = JSON.parse(readResult.content); }
        catch { blockers.push('PACKAGE_JSON_MISSING_OR_INVALID'); }
      }
    }
    try {
      const lockStat = fs.lstatSync(lockPath);
      if (lockStat.isSymbolicLink() || !lockStat.isFile()) blockers.push('PACKAGE_LOCK_PATH_UNSAFE');
      else blockers.push('PACKAGE_LOCK_ALREADY_EXISTS_REQUIRES_REVIEW');
    } catch (error) {
      if (error.code !== 'ENOENT') blockers.push('PACKAGE_LOCK_PATH_UNAVAILABLE');
    }
  }
  const dependencies = pkg && pkg.dependencies && typeof pkg.dependencies === 'object' && !Array.isArray(pkg.dependencies) ? pkg.dependencies : {};
  if (root.safe && !Object.keys(dependencies).length) blockers.push('NO_RUNTIME_DEPENDENCIES_DECLARED');
  for (const [name, version] of Object.entries(dependencies)) {
    if (!isSafeExactVersion(version)) blockers.push(`DIRECT_DEPENDENCY_NOT_EXACTLY_PINNED:${name}`);
  }
  return {
    schemaVersion: 2,
    check: 'DEPENDENCY_LOCKFILE_ACQUISITION_PLAN',
    status: blockers.length ? 'BLOCKED' : 'PLAN_READY',
    blockers,
    candidateRoot: root.safe ? root.canonicalRoot : null,
    registry,
    target: 'isolated temporary staging directory only; do not generate directly in the release workspace',
    command: registry ? ['npm', 'install', '--package-lock-only', '--ignore-scripts', '--no-audit', '--no-fund', '--lockfile-version=3', `--registry=${registry}`] : null,
    requiredAfterCapture: [
      'review registry metadata and complete package graph',
      'verify package-lock.json with the RLA dependency lockfile preflight',
      'review install-script policy and native sqlite3 build provenance separately',
      'promote the reviewed lockfile only after independent approval'
    ],
    networkTestPerformed: false,
    lockfileCreated: false,
    npmCiExecuted: false,
    productionUseAuthorized: false
  };
}

function resolveLockfileAcquisitionPlan(rootDir, env = process.env) {
  let approvedHosts;
  try { approvedHosts = parseApprovedHosts(env.RLA_APPROVED_NPM_REGISTRIES); }
  catch {
    return { schemaVersion: 1, check: 'DEPENDENCY_LOCKFILE_ACQUISITION_PLAN', status: 'BLOCKED', blockers: ['APPROVED_REGISTRY_ALLOWLIST_INVALID'], registry: null, command: null, networkTestPerformed: false, lockfileCreated: false, npmCiExecuted: false, productionUseAuthorized: false };
  }
  return buildLockfileAcquisitionPlan({ rootDir, registryValue: env.RLA_APPROVED_NPM_REGISTRY, approvedHosts });
}

module.exports = { parseExplicitRegistry, inspectCandidateRoot, inspectRegularFile, readRegularFileNoFollow, buildLockfileAcquisitionPlan, resolveLockfileAcquisitionPlan };
