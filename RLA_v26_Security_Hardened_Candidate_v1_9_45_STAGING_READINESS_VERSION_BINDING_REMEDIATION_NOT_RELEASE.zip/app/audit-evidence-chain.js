'use strict';
const crypto = require('node:crypto');
const fs = require('node:fs/promises');
const path = require('node:path');
const { constants: fsConstants } = require('node:fs');

function requireKey(key) {
  if (typeof key !== 'string' || Buffer.byteLength(key, 'utf8') < 32) {
    throw new Error('RLA_AUDIT_EVIDENCE_KEY must contain at least 32 UTF-8 bytes');
  }
}
function canonical(record) {
  const { hmacSha256, ...payload } = record;
  return JSON.stringify(payload);
}
function hmac(record, key) {
  return crypto.createHmac('sha256', key).update(canonical(record), 'utf8').digest('hex');
}
function sha256(bytes) { return crypto.createHash('sha256').update(bytes).digest('hex'); }
function safeEvidenceName(name) {
  if (typeof name !== 'string' || !name || name.length > 200 || path.isAbsolute(name) ||
      name.split(/[\\/]/).some(part => part === '..' || part === '' || part === '.')) {
    throw new Error('Evidence name must be a safe relative path without traversal');
  }
  return name;
}
async function readEvidence(root, name) {
  const safe = safeEvidenceName(name);
  if (typeof root !== 'string' || !root.trim()) throw new Error('Evidence root must be a non-empty path');
  const rootPath = path.resolve(root);
  const rootStat = await fs.lstat(rootPath);
  if (!rootStat.isDirectory() || rootStat.isSymbolicLink()) {
    throw new Error('Evidence root must be a regular directory, not a symlink');
  }
  const full = path.resolve(rootPath, safe);
  if (!full.startsWith(rootPath + path.sep)) throw new Error('Evidence path escapes evidence root');

  // Reject symlinks at every named path component, not only at the final file.
  // This blocks a nested directory symlink from redirecting evidence reads outside
  // the configured evidence root.
  const parts = safe.split(/[\\/]/);
  let current = rootPath;
  for (let i = 0; i < parts.length; i++) {
    current = path.join(current, parts[i]);
    const st = await fs.lstat(current);
    if (st.isSymbolicLink()) {
      if (i === parts.length - 1) throw new Error('Evidence must be a regular non-symlink file');
      throw new Error('Evidence path components must not be symlinks');
    }
    if (i < parts.length - 1 && !st.isDirectory()) throw new Error('Evidence parent components must be directories');
    if (i === parts.length - 1 && !st.isFile()) throw new Error('Evidence must be a regular non-symlink file');
  }

  // Open without following a final-component symlink and hash bytes from the same
  // descriptor whose metadata was checked, reducing check/read substitution risk.
  const handle = await fs.open(full, fsConstants.O_RDONLY | (fsConstants.O_NOFOLLOW || 0));
  try {
    const openedStat = await handle.stat();
    if (!openedStat.isFile()) throw new Error('Evidence must be a regular non-symlink file');
    const bytes = await handle.readFile();
    return { name: safe, size: openedStat.size, sha256: sha256(bytes) };
  } finally {
    await handle.close();
  }
}
async function createEvidenceRecord({ evidenceRoot, evidenceNames, sequence, previousRecordDigest = null, key, actorId, eventType, changeRef, now = new Date() }) {
  requireKey(key);
  if (!Number.isSafeInteger(sequence) || sequence < 1) throw new Error('sequence must be a positive safe integer');
  if (sequence === 1 && previousRecordDigest !== null) throw new Error('first record must have null previousRecordDigest');
  if (sequence > 1 && !/^[a-f0-9]{64}$/.test(previousRecordDigest || '')) throw new Error('subsequent records require previousRecordDigest');
  for (const [v, label] of [[actorId, 'actorId'], [eventType, 'eventType'], [changeRef, 'changeRef']]) {
    if (typeof v !== 'string' || v.trim().length < 2 || v.length > 160 || /[\r\n\0]/.test(v)) throw new Error(`${label} is invalid`);
  }
  if (!Array.isArray(evidenceNames) || evidenceNames.length < 1 || evidenceNames.length > 100) throw new Error('evidenceNames must contain 1-100 files');
  const unique = new Set(evidenceNames);
  if (unique.size !== evidenceNames.length) throw new Error('duplicate evidence names are not allowed');
  const evidence = [];
  for (const name of evidenceNames) evidence.push(await readEvidence(evidenceRoot, name));
  const payload = {
    schemaVersion: 1,
    recordType: 'RLA_AUDIT_EVIDENCE_CHAIN_RECORD',
    sequence,
    createdAt: now.toISOString(),
    previousRecordDigest,
    actorId: actorId.trim(),
    eventType: eventType.trim(),
    changeRef: changeRef.trim(),
    evidence
  };
  return { ...payload, hmacSha256: hmac(payload, key) };
}
function verifyEvidenceRecord(record, key) {
  requireKey(key);
  if (!record || typeof record !== 'object' || Array.isArray(record) || record.schemaVersion !== 1 ||
      record.recordType !== 'RLA_AUDIT_EVIDENCE_CHAIN_RECORD' || !Number.isSafeInteger(record.sequence) || record.sequence < 1 ||
      !Array.isArray(record.evidence) || record.evidence.length < 1 || !/^[a-f0-9]{64}$/.test(record.hmacSha256 || '')) {
    throw new Error('Audit evidence record schema is invalid');
  }
  if ((record.sequence === 1 && record.previousRecordDigest !== null) ||
      (record.sequence > 1 && !/^[a-f0-9]{64}$/.test(record.previousRecordDigest || ''))) {
    throw new Error('Audit evidence chain linkage is invalid');
  }
  const expected = Buffer.from(hmac(record, key), 'hex');
  const actual = Buffer.from(record.hmacSha256, 'hex');
  if (expected.length !== actual.length || !crypto.timingSafeEqual(expected, actual)) throw new Error('Audit evidence HMAC verification failed');
  for (const item of record.evidence) {
    safeEvidenceName(item.name);
    if (!Number.isSafeInteger(item.size) || item.size < 0 || !/^[a-f0-9]{64}$/.test(item.sha256 || '')) throw new Error('Evidence descriptor is invalid');
  }
  return { valid: true, recordDigest: sha256(Buffer.from(JSON.stringify(record))), sequence: record.sequence };
}
async function verifyEvidenceFiles(record, evidenceRoot) {
  for (const item of record.evidence) {
    const current = await readEvidence(evidenceRoot, item.name);
    if (current.size !== item.size || current.sha256 !== item.sha256) throw new Error(`Evidence digest mismatch: ${item.name}`);
  }
  return true;
}
function verifyEvidenceChain(records, key) {
  if (!Array.isArray(records) || records.length < 1) throw new Error('Evidence chain must contain at least one record');
  let previous = null;
  for (let i = 0; i < records.length; i++) {
    const record = records[i];
    if (record.sequence !== i + 1) throw new Error('Evidence chain sequence is not contiguous');
    if (record.previousRecordDigest !== previous) throw new Error('Evidence chain previous-record digest mismatch');
    const checked = verifyEvidenceRecord(record, key);
    previous = checked.recordDigest;
  }
  return { valid: true, recordCount: records.length, finalRecordDigest: previous };
}

const MAX_AUDIT_RECORD_BYTES = 1024 * 1024;
async function readAuditRecordNoFollow(filePath) {
  if (typeof fsConstants.O_NOFOLLOW !== 'number') {
    throw new Error('O_NOFOLLOW is unavailable; refusing to read audit records without no-follow protection');
  }
  const handle = await fs.open(filePath, fsConstants.O_RDONLY | fsConstants.O_NOFOLLOW);
  try {
    const before = await handle.stat();
    if (!before.isFile()) throw new Error('Audit record must be a regular non-symlink file');
    if (before.size > MAX_AUDIT_RECORD_BYTES) throw new Error('Audit record exceeds 1 MiB size limit');
    const bytes = await handle.readFile();
    const after = await handle.stat();
    if (!after.isFile() || after.size > MAX_AUDIT_RECORD_BYTES || after.size !== before.size || bytes.length !== after.size) {
      throw new Error('Audit record changed or exceeded size limit while being read');
    }
    return bytes.toString('utf8');
  } finally {
    await handle.close();
  }
}

async function appendEvidenceRecord({ recordsDir, evidenceRoot, evidenceNames, key, actorId, eventType, changeRef, now = new Date() }) {
  requireKey(key);
  const recordsPath = path.resolve(recordsDir);
  const evidencePath = path.resolve(evidenceRoot);
  const recordsStat = await fs.lstat(recordsPath);
  const evidenceStat = await fs.lstat(evidencePath);
  if (!recordsStat.isDirectory() || recordsStat.isSymbolicLink() || !evidenceStat.isDirectory() || evidenceStat.isSymbolicLink()) {
    throw new Error('recordsDir and evidenceRoot must be regular directories, not symlinks');
  }
  if (process.platform !== 'win32' && ((recordsStat.mode & 0o077) !== 0 || (evidenceStat.mode & 0o077) !== 0)) {
    throw new Error('recordsDir and evidenceRoot must be private (mode 0700 or stricter)');
  }
  const lockPath = path.join(recordsPath, '.append.lock');
  try {
    await fs.mkdir(lockPath, { mode: 0o700 });
  } catch (err) {
    if (err && err.code === 'EEXIST') throw new Error('Evidence append lock exists; inspect it and recover manually');
    throw err;
  }
  const token = crypto.randomBytes(24).toString('hex');
  const ownerPath = path.join(lockPath, 'owner.json');
  try {
    await fs.writeFile(ownerPath, JSON.stringify({ pid: process.pid, token, createdAt: now.toISOString() }) + '\n', { flag: 'wx', mode: 0o600 });
    const names = (await fs.readdir(recordsPath)).filter(n => /^record-\d{6}\.json$/.test(n)).sort();
    const records = [];
    for (const name of names) {
      const full = path.join(recordsPath, name);
      const st = await fs.lstat(full);
      if (!st.isFile() || st.isSymbolicLink()) throw new Error(`Record must be a regular non-symlink file: ${name}`);
      const record = JSON.parse(await readAuditRecordNoFollow(full));
      records.push(record);
    }
    if (records.length) verifyEvidenceChain(records, key);
    const sequence = records.length + 1;
    const previousRecordDigest = records.length ? verifyEvidenceRecord(records[records.length - 1], key).recordDigest : null;
    const record = await createEvidenceRecord({ evidenceRoot: evidencePath, evidenceNames, sequence, previousRecordDigest, key, actorId, eventType, changeRef, now });
    await verifyEvidenceFiles(record, evidencePath);
    const recordName = `record-${String(sequence).padStart(6, '0')}.json`;
    const finalPath = path.join(recordsPath, recordName);
    const tempPath = path.join(recordsPath, `.record-${String(sequence).padStart(6, '0')}-${token}.tmp`);
    const handle = await fs.open(tempPath, 'wx', 0o600);
    try {
      await handle.writeFile(JSON.stringify(record, null, 2) + '\n', 'utf8');
      await handle.sync();
    } finally {
      await handle.close();
    }
    try {
      await fs.link(tempPath, finalPath);
      await fs.unlink(tempPath);
    } catch (err) {
      await fs.rm(tempPath, { force: true });
      if (err && err.code === 'EEXIST') throw new Error('Target record already exists; refusing overwrite');
      throw err;
    }
    return { recordName, sequence, recordDigest: verifyEvidenceRecord(record, key).recordDigest };
  } finally {
    try {
      const owner = JSON.parse(await fs.readFile(ownerPath, 'utf8'));
      if (owner.token === token) await fs.rm(lockPath, { recursive: true, force: true });
    } catch (_) {
      // Preserve an unverifiable lock for operator inspection; never remove another owner's lock.
    }
  }
}

module.exports = { createEvidenceRecord, verifyEvidenceRecord, verifyEvidenceFiles, verifyEvidenceChain, appendEvidenceRecord, safeEvidenceName, readAuditRecordNoFollow };
