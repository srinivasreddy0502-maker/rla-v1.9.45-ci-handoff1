'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const sqlite3 = require('sqlite3');

const PORT = Number(process.env.PORT || 3000);
const DB_PATH = process.env.RLA_DB_PATH || path.join(__dirname, 'rla.db');
const MAX_BODY_BYTES = 64 * 1024;
const PROD = process.env.NODE_ENV === 'production';
const html = fs.readFileSync(path.join(__dirname, 'index.html'), 'utf8');
const db = new sqlite3.Database(DB_PATH);
const states = {
  INTAKE: ['EVIDENCE'], EVIDENCE: ['VALIDATION'], VALIDATION: ['OFFICER_REVIEW'],
  OFFICER_REVIEW: ['AUTHORITY'], AUTHORITY: ['ORDER'], ORDER: ['RECORD_UPDATE'],
  RECORD_UPDATE: ['NOTIFICATION'], NOTIFICATION: ['CLOSED']
};

function respond(res, status, payload, extraHeaders = {}) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
    'Content-Security-Policy': "default-src 'self'; frame-ancestors 'none'",
    ...extraHeaders
  });
  res.end(JSON.stringify(payload));
}
function fail(res, status, code) { return respond(res, status, { error: code }); }
function sha256(value) { return crypto.createHash('sha256').update(value).digest('hex'); }
function transitionDigest(v) {
  return sha256(JSON.stringify({ application_id: v.application_id, maker_id: v.maker_id, jurisdiction: v.jurisdiction, from_state: v.from_state, to_state: v.to_state, expected_version: v.expected_version }));
}
function dbRun(sql, params = []) {
  return new Promise((resolve, reject) => db.run(sql, params, function (err) {
    if (err) reject(err); else resolve({ changes: this.changes, lastID: this.lastID });
  }));
}
function dbGet(sql, params = []) {
  return new Promise((resolve, reject) => db.get(sql, params, (err, row) => err ? reject(err) : resolve(row)));
}
function dbAll(sql, params = []) {
  return new Promise((resolve, reject) => db.all(sql, params, (err, rows) => err ? reject(err) : resolve(rows)));
}
function dbExec(sql) {
  return new Promise((resolve, reject) => db.exec(sql, err => err ? reject(err) : resolve()));
}
function isTransientSqliteLock(err) {
  const code = String(err && err.code || '').toUpperCase();
  const message = String(err && err.message || '').toLowerCase();
  return code === 'SQLITE_BUSY' || code === 'SQLITE_LOCKED' ||
    message.includes('database is locked') || message.includes('database is busy');
}
async function initDbWithRetry(maxAttempts = 8) {
  // A competing process may briefly own the database lock during WAL setup or
  // BEGIN IMMEDIATE. Retry only transient lock errors; fail closed for all others.
  for (let attempt = 1; ; attempt++) {
    try {
      return await initDb();
    } catch (err) {
      if (!isTransientSqliteLock(err) || attempt >= maxAttempts) throw err;
      const delayMs = Math.min(500, 25 * (2 ** (attempt - 1)));
      await new Promise(resolve => setTimeout(resolve, delayMs));
    }
  }
}
async function hasColumn(table, column) {
  const cols = await dbAll(`PRAGMA table_info(${table})`);
  return cols.some(c => c.name === column);
}
async function initDb() {
  // These connection-level settings must be applied before opening the schema transaction.
  // WAL improves reader/writer coexistence; busy_timeout allows short lock contention to resolve.
  await dbExec('PRAGMA busy_timeout=5000; PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;');
  // Serialize schema creation, migrations, and one-time bootstrap across processes.
  // BEGIN IMMEDIATE obtains SQLite's cross-process writer lock before any schema mutation.
  return inTransaction(async () => {
  // Validate policy before mutating the database, so a malformed policy cannot leave
  // behind a partially bootstrapped account.
  const rawPolicy = process.env.RLA_AUTHZ_POLICY_JSON;
  if (!rawPolicy && PROD) throw new Error('RLA_AUTHZ_POLICY_JSON is required in production');
  let policy = {};
  if (rawPolicy) {
    policy = JSON.parse(rawPolicy);
    if (!policy || typeof policy !== 'object' || Array.isArray(policy)) throw new Error('RLA_AUTHZ_POLICY_JSON must be an object');
    const entries = Object.entries(policy);
    if (entries.length === 0) throw new Error('RLA_AUTHZ_POLICY_JSON must define at least one role');
    for (const [role, permissions] of entries) {
      if (!role.trim() || !Array.isArray(permissions) || permissions.length === 0 ||
          permissions.some(p => typeof p !== 'string' || !p.trim() || p.trim() === '*'))
        throw new Error('RLA_AUTHZ_POLICY_JSON must map roles to non-empty arrays of explicit permissions; wildcard permission is prohibited');
    }
  }
  await dbExec(`
    PRAGMA foreign_keys=ON;
    CREATE TABLE IF NOT EXISTS users(
      id TEXT PRIMARY KEY, name TEXT NOT NULL, role TEXT NOT NULL,
      token_hash TEXT UNIQUE NOT NULL, jurisdiction TEXT
    );
    CREATE TABLE IF NOT EXISTS applications(
      id TEXT PRIMARY KEY, service_type TEXT NOT NULL, parcel_reference TEXT,
      state TEXT NOT NULL, version INTEGER NOT NULL, created_at TEXT NOT NULL,
      created_by TEXT NOT NULL, jurisdiction TEXT,
      FOREIGN KEY(created_by) REFERENCES users(id)
    );
    CREATE TABLE IF NOT EXISTS evidence(
      id TEXT PRIMARY KEY, application_id TEXT NOT NULL, type TEXT NOT NULL,
      sha256 TEXT NOT NULL, created_at TEXT NOT NULL,
      FOREIGN KEY(application_id) REFERENCES applications(id)
    );
    CREATE TABLE IF NOT EXISTS transition_requests(
      id TEXT PRIMARY KEY, application_id TEXT NOT NULL, maker_id TEXT NOT NULL,
      jurisdiction TEXT NOT NULL, from_state TEXT NOT NULL, to_state TEXT NOT NULL,
      expected_version INTEGER NOT NULL, request_digest TEXT NOT NULL,
      status TEXT NOT NULL CHECK(status IN ('PENDING','APPROVED','REJECTED','STALE')),
      created_at TEXT NOT NULL, decided_at TEXT, checker_id TEXT, decision_reason TEXT,
      FOREIGN KEY(application_id) REFERENCES applications(id),
      FOREIGN KEY(maker_id) REFERENCES users(id), FOREIGN KEY(checker_id) REFERENCES users(id)
    );
    CREATE INDEX IF NOT EXISTS idx_transition_requests_scope_status ON transition_requests(jurisdiction,status,created_at);
    CREATE TABLE IF NOT EXISTS audit(
      id TEXT PRIMARY KEY, actor TEXT NOT NULL, action TEXT NOT NULL,
      object_id TEXT, from_state TEXT, to_state TEXT, created_at TEXT NOT NULL, jurisdiction TEXT
    );
  `);
  if (!(await hasColumn('users', 'jurisdiction'))) await dbExec('ALTER TABLE users ADD COLUMN jurisdiction TEXT');
  if (!(await hasColumn('applications', 'jurisdiction'))) await dbExec('ALTER TABLE applications ADD COLUMN jurisdiction TEXT');
  if (!(await hasColumn('audit', 'jurisdiction'))) await dbExec('ALTER TABLE audit ADD COLUMN jurisdiction TEXT');
  await dbRun('CREATE INDEX IF NOT EXISTS idx_apps_scope_created ON applications(jurisdiction, created_at)');
  await dbRun('CREATE INDEX IF NOT EXISTS idx_audit_scope_created ON audit(jurisdiction, created_at)');

  // Bootstrap is explicit and one-time. Existing installations do not need the bootstrap
  // secret on every restart; a supplied token never silently rotates an existing account.
  const existing = await dbGet("SELECT id FROM users WHERE id='U_BOOTSTRAP_ADMIN'");
  const bootstrapToken = process.env.RLA_BOOTSTRAP_ADMIN_TOKEN;
  if (!existing) {
    if (PROD && !bootstrapToken) throw new Error('RLA_BOOTSTRAP_ADMIN_TOKEN is required for initial secure bootstrap');
    if (bootstrapToken) {
      if (bootstrapToken.length < 32) throw new Error('RLA_BOOTSTRAP_ADMIN_TOKEN must be at least 32 characters');
      await dbRun(
        'INSERT INTO users(id,name,role,token_hash,jurisdiction) VALUES(?,?,?,?,?)',
        ['U_BOOTSTRAP_ADMIN', 'Bootstrap Administrator', 'ADMIN', sha256(bootstrapToken), process.env.RLA_BOOTSTRAP_ADMIN_JURISDICTION || null]
      );
    }
  } else if (bootstrapToken && bootstrapToken.length < 32) {
    throw new Error('RLA_BOOTSTRAP_ADMIN_TOKEN must be at least 32 characters when supplied');
  }
  return policy;
  });
}

function parseBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let total = 0;
    let tooLarge = false;
    let settled = false;
    req.on('data', chunk => {
      if (tooLarge) return; // Continue draining without retaining an oversized body.
      total += chunk.length;
      if (total > MAX_BODY_BYTES) {
        tooLarge = true;
        chunks.length = 0;
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      if (settled) return;
      settled = true;
      if (tooLarge) return reject(Object.assign(new Error('BODY_TOO_LARGE'), { status: 413, code: 'BODY_TOO_LARGE' }));
      if (total === 0) return resolve({});
      const ct = String(req.headers['content-type'] || '').toLowerCase();
      if (!ct.includes('application/json')) return reject(Object.assign(new Error('JSON_REQUIRED'), { status: 415, code: 'JSON_REQUIRED' }));
      try {
        const parsed = JSON.parse(Buffer.concat(chunks).toString('utf8'));
        if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error('JSON_OBJECT_REQUIRED');
        resolve(parsed);
      } catch (_) {
        reject(Object.assign(new Error('INVALID_JSON'), { status: 400, code: 'INVALID_JSON' }));
      }
    });
    req.on('error', err => {
      if (settled) return;
      settled = true;
      reject(err);
    });
  });
}

async function authenticate(req) {
  const auth = String(req.headers.authorization || '');
  const match = auth.match(/^Bearer ([^\s]+)$/);
  if (!match) return null;
  return dbGet('SELECT id,name,role,jurisdiction FROM users WHERE token_hash=?', [sha256(match[1])]);
}
function allowed(policy, user, permission) {
  if (!user || !policy || !Array.isArray(policy[user.role])) return false;
  return policy[user.role].includes(permission);
}
function scoped(user, row) {
  // Null scope never means global access. Global access must be an explicit policy decision
  // implemented by a separate reviewed permission, not an implicit wildcard.
  return Boolean(user && user.jurisdiction && row && row.jurisdiction &&
    user.jurisdiction === row.jurisdiction);
}
// The application currently uses one SQLite connection. Serialize transaction
// lifecycles so concurrent HTTP requests cannot interleave BEGIN/COMMIT/ROLLBACK
// on that shared connection. Keep the queue alive even if a transaction fails.
let transactionQueue = Promise.resolve();
async function inTransaction(fn) {
  let release;
  const previous = transactionQueue;
  transactionQueue = new Promise(resolve => { release = resolve; });
  await previous;
  try {
    await dbExec('BEGIN IMMEDIATE');
    try {
      const result = await fn();
      await dbExec('COMMIT');
      return result;
    } catch (err) {
      try { await dbExec('ROLLBACK'); } catch (_) {}
      throw err;
    }
  } finally {
    release();
  }
}
async function writeAudit(actor, action, objectId, fromState, toState, jurisdiction) {
  if (typeof jurisdiction !== 'string' || !jurisdiction.trim()) {
    throw Object.assign(new Error('AUDIT_JURISDICTION_REQUIRED'), { code: 'AUDIT_JURISDICTION_REQUIRED' });
  }
  await dbRun('INSERT INTO audit(id,actor,action,object_id,from_state,to_state,created_at,jurisdiction) VALUES(?,?,?,?,?,?,?,?)',
    [crypto.randomUUID(), actor, action, objectId || null, fromState || null, toState || null, new Date().toISOString(), jurisdiction]);
}
function safePath(req) {
  const parsed = new URL(req.url, 'http://rla.local');
  if (parsed.pathname.includes('\\') || /%2f|%5c/i.test(parsed.pathname)) return null;
  return { pathname: parsed.pathname, searchParams: parsed.searchParams };
}

let policy = null;
let policyConfigured = false;
const server = http.createServer(async (req, res) => {
  const requestId = crypto.randomUUID();
  res.setHeader('X-Request-ID', requestId);
  if (req.method === 'GET' && req.url === '/') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'X-Content-Type-Options': 'nosniff',
      'Content-Security-Policy': "default-src 'self'; frame-ancestors 'none'" });
    return res.end(html);
  }
  if (req.method === 'GET' && req.url === '/api/health') {
    return respond(res, 200, { status: 'ok', version: 'v26-candidate', readiness: policyConfigured ? 'configured' : 'authorization-policy-missing' });
  }
  const route = safePath(req);
  if (!route) return fail(res, 400, 'INVALID_PATH');
  if (!policyConfigured) return fail(res, 503, 'AUTHORIZATION_POLICY_NOT_CONFIGURED');

  try {
    const user = await authenticate(req);
    if (!user) return fail(res, 401, 'AUTH_REQUIRED');
    const { pathname } = route;

    if (req.method === 'GET' && pathname === '/api/applications') {
      if (!allowed(policy, user, 'applications:read')) return fail(res, 403, 'FORBIDDEN');
      if (!user.jurisdiction) return fail(res, 403, 'JURISDICTION_REQUIRED');
      const rows = await dbAll(
        'SELECT id,service_type,parcel_reference,state,version,created_at,created_by,jurisdiction FROM applications WHERE jurisdiction=? ORDER BY created_at DESC',
        [user.jurisdiction]);
      return respond(res, 200, rows);
    }

    if (req.method === 'POST' && pathname === '/api/applications') {
      if (!allowed(policy, user, 'applications:create')) return fail(res, 403, 'FORBIDDEN');
      if (!user.jurisdiction) return fail(res, 403, 'JURISDICTION_REQUIRED');
      const b = await parseBody(req);
      if (typeof b.service_type !== 'string' || !b.service_type.trim() || b.service_type.length > 100)
        return fail(res, 400, 'INVALID_SERVICE_TYPE');
      if (b.parcel_reference != null && (typeof b.parcel_reference !== 'string' || b.parcel_reference.length > 120))
        return fail(res, 400, 'INVALID_PARCEL_REFERENCE');
      const id = 'APP-' + crypto.randomUUID().slice(0, 8).toUpperCase();
      const now = new Date().toISOString();
      await inTransaction(async () => {
        await dbRun('INSERT INTO applications(id,service_type,parcel_reference,state,version,created_at,created_by,jurisdiction) VALUES(?,?,?,?,?,?,?,?)',
          [id, b.service_type.trim(), b.parcel_reference || null, 'INTAKE', 1, now, user.id, user.jurisdiction]);
        await writeAudit(user.id, 'APPLICATION_CREATED', id, null, 'INTAKE', user.jurisdiction);
      });
      return respond(res, 201, { id, state: 'INTAKE', version: 1 });
    }

    // Maker submits a transition request; this endpoint never mutates workflow state directly.
    const transitionRequest = pathname.match(/^\/api\/applications\/([A-Za-z0-9-]{1,80})\/transition-requests$/);
    if (req.method === 'POST' && transitionRequest) {
      if (!allowed(policy, user, 'applications:transition_request')) return fail(res, 403, 'FORBIDDEN');
      const b = await parseBody(req);
      if (!Number.isInteger(b.expected_version) || typeof b.to_state !== 'string')
        return fail(res, 400, 'INVALID_TRANSITION_REQUEST');
      const id = transitionRequest[1];
      const result = await inTransaction(async () => {
        const app = await dbGet('SELECT * FROM applications WHERE id=?', [id]);
        if (!app) return { status: 404, body: { error: 'NOT_FOUND' } };
        if (!scoped(user, app)) return { status: 403, body: { error: 'FORBIDDEN' } };
        if (b.expected_version !== app.version) return { status: 409, body: { error: 'STALE_VERSION', current_version: app.version } };
        if (!states[app.state] || !states[app.state].includes(b.to_state)) return { status: 400, body: { error: 'INVALID_TRANSITION' } };
        const requestId = 'TR-' + crypto.randomUUID();
        const now = new Date().toISOString();
        const material = { application_id: id, maker_id: user.id, jurisdiction: user.jurisdiction,
          from_state: app.state, to_state: b.to_state, expected_version: app.version };
        const digest = transitionDigest(material);
        await dbRun(`INSERT INTO transition_requests(id,application_id,maker_id,jurisdiction,from_state,to_state,expected_version,request_digest,status,created_at)
          VALUES(?,?,?,?,?,?,?,?,?,?)`, [requestId, id, user.id, user.jurisdiction, app.state, b.to_state, app.version, digest, 'PENDING', now]);
        await writeAudit(user.id, 'TRANSITION_REQUESTED', id, app.state, b.to_state, user.jurisdiction);
        return { status: 202, body: { request_id: requestId, application_id: id, status: 'PENDING', expected_version: app.version } };
      });
      return respond(res, result.status, result.body);
    }

    // Checker approval/rejection is a separate, permission-gated decision. State mutation,
    // decision consumption, and audit append occur in one transaction.
    const transitionDecision = pathname.match(/^\/api\/applications\/([A-Za-z0-9-]{1,80})\/transition-requests\/(TR-[A-Za-z0-9-]{1,80})\/decision$/);
    if (req.method === 'POST' && transitionDecision) {
      if (!allowed(policy, user, 'applications:approve_transition')) return fail(res, 403, 'FORBIDDEN');
      const b = await parseBody(req);
      if (!['APPROVE', 'REJECT'].includes(b.decision) || (b.reason != null && (typeof b.reason !== 'string' || b.reason.length > 500)))
        return fail(res, 400, 'INVALID_DECISION');
      const appId = transitionDecision[1], requestId = transitionDecision[2];
      const result = await inTransaction(async () => {
        const reqRow = await dbGet('SELECT * FROM transition_requests WHERE id=? AND application_id=?', [requestId, appId]);
        if (!reqRow) return { status: 404, body: { error: 'REQUEST_NOT_FOUND' } };
        if (!scoped(user, { jurisdiction: reqRow.jurisdiction })) return { status: 403, body: { error: 'FORBIDDEN' } };
        if (user.id === reqRow.maker_id) return { status: 403, body: { error: 'MAKER_CANNOT_APPROVE_OWN_REQUEST' } };
        if (reqRow.status !== 'PENDING') return { status: 409, body: { error: 'DECISION_ALREADY_CONSUMED' } };
        const material = { application_id: reqRow.application_id, maker_id: reqRow.maker_id, jurisdiction: reqRow.jurisdiction,
          from_state: reqRow.from_state, to_state: reqRow.to_state, expected_version: reqRow.expected_version };
        if (transitionDigest(material) !== reqRow.request_digest) return { status: 409, body: { error: 'REQUEST_DIGEST_MISMATCH' } };
        const app = await dbGet('SELECT * FROM applications WHERE id=?', [appId]);
        if (!app || !scoped(user, app)) return { status: 403, body: { error: 'FORBIDDEN' } };
        if (app.version !== reqRow.expected_version || app.state !== reqRow.from_state) {
          await dbRun("UPDATE transition_requests SET status='STALE',decided_at=?,checker_id=?,decision_reason=? WHERE id=? AND status='PENDING'",
            [new Date().toISOString(), user.id, b.reason || null, requestId]);
          await writeAudit(user.id, 'TRANSITION_REQUEST_STALE', appId, reqRow.from_state, reqRow.to_state, reqRow.jurisdiction);
          return { status: 409, body: { error: 'STALE_REQUEST' } };
        }
        const now = new Date().toISOString();
        if (b.decision === 'REJECT') {
          const changed = await dbRun("UPDATE transition_requests SET status='REJECTED',decided_at=?,checker_id=?,decision_reason=? WHERE id=? AND status='PENDING'",
            [now, user.id, b.reason || null, requestId]);
          if (changed.changes !== 1) return { status: 409, body: { error: 'DECISION_ALREADY_CONSUMED' } };
          await writeAudit(user.id, 'TRANSITION_REJECTED', appId, reqRow.from_state, reqRow.to_state, reqRow.jurisdiction);
          return { status: 200, body: { request_id: requestId, status: 'REJECTED', state: app.state, version: app.version } };
        }
        const update = await dbRun('UPDATE applications SET state=?,version=version+1 WHERE id=? AND version=? AND state=?',
          [reqRow.to_state, appId, reqRow.expected_version, reqRow.from_state]);
        if (update.changes !== 1) return { status: 409, body: { error: 'STALE_VERSION' } };
        const consumed = await dbRun("UPDATE transition_requests SET status='APPROVED',decided_at=?,checker_id=?,decision_reason=? WHERE id=? AND status='PENDING'",
          [now, user.id, b.reason || null, requestId]);
        if (consumed.changes !== 1) return { status: 409, body: { error: 'DECISION_ALREADY_CONSUMED' } };
        await writeAudit(user.id, 'TRANSITION_APPROVED', appId, reqRow.from_state, reqRow.to_state, reqRow.jurisdiction);
        return { status: 200, body: { request_id: requestId, status: 'APPROVED', id: appId, state: reqRow.to_state, version: app.version + 1 } };
      });
      return respond(res, result.status, result.body);
    }

    // Legacy direct mutation route is intentionally disabled to prevent maker-checker bypass.
    if (req.method === 'POST' && /^\/api\/applications\/([A-Za-z0-9-]{1,80})\/transition$/.test(pathname)) {
      return fail(res, 410, 'MAKER_CHECKER_REQUIRED');
    }

    if (req.method === 'GET' && pathname === '/api/audit') {
      if (!allowed(policy, user, 'audit:read')) return fail(res, 403, 'FORBIDDEN');
      if (!user.jurisdiction) return fail(res, 403, 'JURISDICTION_REQUIRED');
      const rows = await dbAll(
        'SELECT id,actor,action,object_id,from_state,to_state,created_at FROM audit WHERE jurisdiction=? ORDER BY created_at DESC LIMIT 500',
        [user.jurisdiction]);
      return respond(res, 200, rows);
    }
    return fail(res, 404, 'NOT_FOUND');
  } catch (err) {
    const status = err.status || 500;
    const code = err.code || 'SERVER_ERROR';
    // Never log request bodies, tokens, or other secrets.
    process.stderr.write(JSON.stringify({ level: 'error', requestId, code }) + '\n');
    if (!res.headersSent && !res.destroyed) return fail(res, status, code);
    if (!res.destroyed) res.end();
  }
});

(async () => {
  try {
    policy = await initDbWithRetry();
    policyConfigured = Boolean(process.env.RLA_AUTHZ_POLICY_JSON);
    server.listen(PORT, () => process.stdout.write(`RLA v26 hardened candidate listening on ${PORT}\n`));
  } catch (err) {
    process.stderr.write(`RLA startup blocked: ${err.message}\n`);
    process.exitCode = 1;
    db.close();
  }
})();
process.on('SIGTERM', () => server.close(() => db.close()));
process.on('SIGINT', () => server.close(() => db.close()));
