'use strict';
const crypto = require('node:crypto');
const fs = require('node:fs/promises');
const path = require('node:path');
const { verifyEvidenceChain } = require('./audit-evidence-chain');

function requireKey(key) {
  if (typeof key !== 'string' || Buffer.byteLength(key, 'utf8') < 32) {
    throw new Error('RLA_AUDIT_EVIDENCE_KEY must contain at least 32 UTF-8 bytes');
  }
}
function canonical(payload) { return JSON.stringify(payload); }
function sign(payload, key) {
  return crypto.createHmac('sha256', key).update(canonical(payload), 'utf8').digest('hex');
}
function safeRecordName(name) {
  return typeof name === 'string' && /^record-\d{6}\.json$/.test(name);
}
async function loadEvidenceChain(recordsDir) {
  const root = path.resolve(recordsDir);
  const rootStat = await fs.lstat(root);
  if (!rootStat.isDirectory() || rootStat.isSymbolicLink()) throw new Error('recordsDir must be a regular directory');
  if (process.platform !== 'win32' && (rootStat.mode & 0o077) !== 0) throw new Error('recordsDir must be private');
  const names = (await fs.readdir(root)).filter(n => /^record-\d{6}\.json$/.test(n)).sort();
  if (!names.length) throw new Error('No audit evidence records found');
  const records = [];
  for (const name of names) {
    const full = path.join(root, name);
    const st = await fs.lstat(full);
    if (!st.isFile() || st.isSymbolicLink()) throw new Error(`Record must be a regular non-symlink file: ${name}`);
    const record = JSON.parse(await fs.readFile(full, 'utf8'));
    if (!safeRecordName(name) || record.sequence !== records.length + 1) throw new Error('Record filenames and sequence must be contiguous');
    records.push(record);
  }
  const verified = verifyEvidenceChain(records, arguments[1]);
  return { records, verified };
}
async function readAndVerifyChain(recordsDir, key) {
  requireKey(key);
  const root = path.resolve(recordsDir);
  const rootStat = await fs.lstat(root);
  if (!rootStat.isDirectory() || rootStat.isSymbolicLink()) throw new Error('recordsDir must be a regular directory');
  if (process.platform !== 'win32' && (rootStat.mode & 0o077) !== 0) throw new Error('recordsDir must be private');
  const names = (await fs.readdir(root)).filter(n => /^record-\d{6}\.json$/.test(n)).sort();
  if (!names.length) throw new Error('No audit evidence records found');
  const records = [];
  for (const name of names) {
    const full = path.join(root, name);
    const st = await fs.lstat(full);
    if (!st.isFile() || st.isSymbolicLink()) throw new Error(`Record must be a regular non-symlink file: ${name}`);
    const record = JSON.parse(await fs.readFile(full, 'utf8'));
    if (record.sequence !== records.length + 1) throw new Error('Record filenames and sequence must be contiguous');
    records.push(record);
  }
  const verified = verifyEvidenceChain(records, key);
  return { records, verified };
}
async function createAuditCheckpoint({ recordsDir, checkpointPath, key, now = new Date() }) {
  requireKey(key);
  const { verified } = await readAndVerifyChain(recordsDir, key);
  const payload = {
    schemaVersion: 1,
    recordType: 'RLA_AUDIT_EVIDENCE_CHECKPOINT',
    createdAt: now.toISOString(),
    recordCount: verified.recordCount,
    finalRecordDigest: verified.finalRecordDigest
  };
  const checkpoint = { ...payload, hmacSha256: sign(payload, key) };
  const out = path.resolve(checkpointPath);
  const parent = path.dirname(out);
  const parentStat = await fs.lstat(parent);
  if (!parentStat.isDirectory() || parentStat.isSymbolicLink()) throw new Error('checkpoint parent must be a regular directory');
  if (process.platform !== 'win32' && (parentStat.mode & 0o077) !== 0) throw new Error('checkpoint parent must be private');
  const handle = await fs.open(out, 'wx', 0o600);
  try {
    await handle.writeFile(JSON.stringify(checkpoint, null, 2) + '\n', 'utf8');
    await handle.sync();
  } finally { await handle.close(); }
  return { checkpointPath: out, recordCount: payload.recordCount, finalRecordDigest: payload.finalRecordDigest };
}
function verifyCheckpointSignature(checkpoint, key) {
  requireKey(key);
  if (!checkpoint || typeof checkpoint !== 'object' || Array.isArray(checkpoint) ||
      checkpoint.schemaVersion !== 1 || checkpoint.recordType !== 'RLA_AUDIT_EVIDENCE_CHECKPOINT' ||
      !Number.isSafeInteger(checkpoint.recordCount) || checkpoint.recordCount < 1 ||
      !/^[a-f0-9]{64}$/.test(checkpoint.finalRecordDigest || '') ||
      !/^[a-f0-9]{64}$/.test(checkpoint.hmacSha256 || '')) throw new Error('Checkpoint schema is invalid');
  const { hmacSha256, ...payload } = checkpoint;
  const expected = Buffer.from(sign(payload, key), 'hex');
  const actual = Buffer.from(hmacSha256, 'hex');
  if (expected.length !== actual.length || !crypto.timingSafeEqual(expected, actual)) throw new Error('Checkpoint HMAC verification failed');
  return true;
}
async function verifyAuditCheckpoint({ recordsDir, checkpointPath, key }) {
  requireKey(key);
  const checkpointStat = await fs.lstat(checkpointPath);
  if (!checkpointStat.isFile() || checkpointStat.isSymbolicLink()) throw new Error('checkpoint must be a regular non-symlink file');
  const checkpoint = JSON.parse(await fs.readFile(checkpointPath, 'utf8'));
  verifyCheckpointSignature(checkpoint, key);
  const { verified } = await readAndVerifyChain(recordsDir, key);
  if (verified.recordCount !== checkpoint.recordCount || verified.finalRecordDigest !== checkpoint.finalRecordDigest) {
    throw new Error('Current evidence chain does not match signed checkpoint');
  }
  return { valid: true, recordCount: verified.recordCount, finalRecordDigest: verified.finalRecordDigest };
}
module.exports = { createAuditCheckpoint, verifyAuditCheckpoint, verifyCheckpointSignature, readAndVerifyChain };
