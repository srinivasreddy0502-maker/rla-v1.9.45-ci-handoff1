'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { checkDependencyLockfile, parseApprovedHosts } = require('./dependency-lockfile-preflight');

function buildSafeNpmCiArgs() {
  return ['ci', '--ignore-scripts', '--no-audit', '--no-fund'];
}

function buildSafeNpmEnvironment(sourceEnv, approvedHosts) {
  if (!sourceEnv || typeof sourceEnv !== 'object' || !Array.isArray(approvedHosts) || approvedHosts.length === 0) {
    throw new TypeError('A source environment and approved registry hosts are required');
  }
  const env = { ...sourceEnv };
  for (const key of Object.keys(env)) {
    if (/^(?:npm_config_|npm_config_|NPM_CONFIG_)/i.test(key) || /^(?:NODE_OPTIONS|NODE_PATH|NODE_TLS_REJECT_UNAUTHORIZED|NODE_EXTRA_CA_CERTS|NODE_USE_ENV_PROXY|npm_execpath|npm_node_execpath)$/i.test(key)) {
      delete env[key];
    }
  }
  // Lockfile URLs are independently checked against this host allowlist. Pin npm's
  // registry setting too, so inherited npm_config_registry cannot redirect metadata requests.
  env.npm_config_registry = `https://${approvedHosts[0]}/`;
  env.npm_config_ignore_scripts = 'true';
  env.npm_config_audit = 'false';
  env.npm_config_fund = 'false';
  env.npm_config_update_notifier = 'false';
  env.npm_config_strict_ssl = 'true';
  return env;
}

function evaluateSafeInstall({ rootDir, approvedHosts }) {
  const report = checkDependencyLockfile({ rootDir, approvedHosts });
  return {
    schemaVersion: 1,
    check: 'SAFE_NPM_CI_PREFLIGHT',
    status: report.status === 'PASS' ? 'PASS' : 'BLOCKED',
    blockers: report.blockers,
    lockfileVersion: report.lockfileVersion,
    installAllowed: report.status === 'PASS',
    commandArgs: buildSafeNpmCiArgs(),
    lifecycleScriptsSuppressed: true,
    inheritedNpmConfigStripped: true,
    nodeRuntimeInjectionVariablesStripped: true,
    tlsVerificationEnforced: true,
    registryPinnedToApprovedHost: approvedHosts[0] || null,
    nativeBuildReady: false,
    productionUseAuthorized: false,
    nextStep: report.status === 'PASS'
      ? 'DEPENDENCIES_FETCHED_WITH_SCRIPTS_SUPPRESSED; REVIEW_AND_AUTHORIZE_NATIVE_BUILD_SEPARATELY'
      : 'FIX_PREFLIGHT_BLOCKERS_BEFORE_INSTALL'
  };
}

function resolveSafeInstallConfig(rootDir, registryValue) {
  let approvedHosts;
  try {
    approvedHosts = parseApprovedHosts(registryValue);
  } catch {
    return {
      schemaVersion: 1,
      check: 'SAFE_NPM_CI_PREFLIGHT',
      status: 'BLOCKED',
      blockers: ['APPROVED_REGISTRY_CONFIGURATION_INVALID'],
      lockfileVersion: null,
      installAllowed: false,
      commandArgs: buildSafeNpmCiArgs(),
      lifecycleScriptsSuppressed: true,
      inheritedNpmConfigStripped: true,
      nodeRuntimeInjectionVariablesStripped: true,
      tlsVerificationEnforced: true,
      registryPinnedToApprovedHost: null,
      nativeBuildReady: false,
      productionUseAuthorized: false,
      nextStep: 'FIX_REGISTRY_CONFIGURATION_BEFORE_INSTALL'
    };
  }
  return evaluateSafeInstall({ rootDir, approvedHosts });
}

module.exports = { buildSafeNpmCiArgs, buildSafeNpmEnvironment, evaluateSafeInstall, resolveSafeInstallConfig };
