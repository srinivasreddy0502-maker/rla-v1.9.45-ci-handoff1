'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');

async function assertPrivateDirectory(dirPath, label) {
  const stat = await fs.promises.lstat(dirPath);
  if (stat.isSymbolicLink() || !stat.isDirectory()) {
    throw new Error(`${label} must be an existing directory, not a symbolic link`);
  }
  if (process.platform !== 'win32' && (stat.mode & 0o077) !== 0) {
    throw new Error(`${label} must not grant group or other permissions (use mode 0700)`);
  }
  return stat;
}

async function acquireSchedulerLock(lockPath) {
  const absoluteLockPath = path.resolve(lockPath);
  const parent = path.dirname(absoluteLockPath);
  await assertPrivateDirectory(parent, 'Scheduler lock parent');
  const token = crypto.randomBytes(32).toString('hex');
  const metadata = {
    schemaVersion: 1,
    pid: process.pid,
    acquiredAt: new Date().toISOString(),
    token
  };

  // mkdir is the cross-process atomic acquisition point. Never auto-delete an
  // existing lock: a stale lock requires an operator-reviewed recovery action.
  await fs.promises.mkdir(absoluteLockPath, { mode: 0o700 });
  try {
    const metadataPath = path.join(absoluteLockPath, 'owner.json');
    const handle = await fs.promises.open(metadataPath, 'wx', 0o600);
    try {
      await handle.writeFile(`${JSON.stringify(metadata)}\n`, 'utf8');
      await handle.sync();
    } finally {
      await handle.close();
    }
    await fs.promises.chmod(absoluteLockPath, 0o700);
    return { lockPath: absoluteLockPath, token, pid: metadata.pid, acquiredAt: metadata.acquiredAt };
  } catch (error) {
    // Leave the lock directory in place if initialization partially failed;
    // deleting it automatically could remove a lock another process observed.
    throw new Error(`Scheduler lock created but initialization failed; operator review required: ${error.message}`);
  }
}

async function releaseSchedulerLock(lock) {
  if (!lock || typeof lock.lockPath !== 'string' || typeof lock.token !== 'string') {
    throw new Error('A valid scheduler lock handle is required');
  }
  const lockPath = path.resolve(lock.lockPath);
  const stat = await fs.promises.lstat(lockPath);
  if (stat.isSymbolicLink() || !stat.isDirectory()) throw new Error('Scheduler lock path is not a regular directory');
  const metadataPath = path.join(lockPath, 'owner.json');
  const metadataStat = await fs.promises.lstat(metadataPath);
  if (metadataStat.isSymbolicLink() || !metadataStat.isFile()) throw new Error('Scheduler lock metadata is not a regular file');
  const metadata = JSON.parse(await fs.promises.readFile(metadataPath, 'utf8'));
  const expected = Buffer.from(lock.token, 'utf8');
  const actual = Buffer.from(typeof metadata.token === 'string' ? metadata.token : '', 'utf8');
  if (expected.length !== actual.length || !crypto.timingSafeEqual(expected, actual)) {
    throw new Error('Scheduler lock ownership mismatch; refusing to release another process lock');
  }
  await fs.promises.unlink(metadataPath);
  await fs.promises.rmdir(lockPath);
  return { released: true, lockPath };
}


async function inspectSchedulerLock(lockPath, { now = Date.now(), processExists = defaultProcessExists } = {}) {
  const absoluteLockPath = path.resolve(lockPath);
  const parent = path.dirname(absoluteLockPath);
  await assertPrivateDirectory(parent, 'Scheduler lock parent');
  const lockStat = await fs.promises.lstat(absoluteLockPath);
  if (lockStat.isSymbolicLink() || !lockStat.isDirectory()) {
    throw new Error('Scheduler lock path is not a regular directory');
  }
  if (process.platform !== 'win32' && (lockStat.mode & 0o077) !== 0) {
    throw new Error('Scheduler lock directory must not grant group or other permissions');
  }
  const metadataPath = path.join(absoluteLockPath, 'owner.json');
  const metadataStat = await fs.promises.lstat(metadataPath);
  if (metadataStat.isSymbolicLink() || !metadataStat.isFile()) {
    throw new Error('Scheduler lock metadata is not a regular file');
  }
  if (process.platform !== 'win32' && (metadataStat.mode & 0o077) !== 0) {
    throw new Error('Scheduler lock metadata must not grant group or other permissions');
  }
  let metadata;
  try {
    metadata = JSON.parse(await fs.promises.readFile(metadataPath, 'utf8'));
  } catch {
    throw new Error('Scheduler lock metadata is unreadable or invalid JSON; operator review required');
  }
  if (!metadata || metadata.schemaVersion !== 1 || !Number.isSafeInteger(metadata.pid) || metadata.pid < 1 ||
      typeof metadata.acquiredAt !== 'string' || !Number.isFinite(Date.parse(metadata.acquiredAt)) ||
      typeof metadata.token !== 'string' || !/^[a-f0-9]{64}$/.test(metadata.token)) {
    throw new Error('Scheduler lock metadata schema is invalid; operator review required');
  }
  const processState = await processExists(metadata.pid);
  const ageMs = Math.max(0, now - Date.parse(metadata.acquiredAt));
  // This is diagnostic only. A PID can be reused, so a present PID does not prove
  // that it belongs to the original owner. Never remove a lock automatically.
  let status;
  if (processState === true) status = 'pid-present-owner-identity-unproven-review-required';
  else if (processState === false) status = 'possibly-stale-lock-operator-review-required';
  else status = 'process-state-unknown-operator-review-required';
  return {
    ok: true,
    lockPath: absoluteLockPath,
    pid: metadata.pid,
    acquiredAt: metadata.acquiredAt,
    ageMs,
    status,
    automaticCleanup: false,
    tokenExposed: false
  };
}

async function defaultProcessExists(pid) {
  try {
    process.kill(pid, 0);
    return true;
  } catch (error) {
    if (error && error.code === 'ESRCH') return false;
    // EPERM means a process likely exists but cannot be inspected; other errors
    // are intentionally treated as unknown rather than evidence of staleness.
    return null;
  }
}

module.exports = { acquireSchedulerLock, releaseSchedulerLock, assertPrivateDirectory, inspectSchedulerLock, defaultProcessExists };
