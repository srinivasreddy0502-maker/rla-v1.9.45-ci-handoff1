'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');

const MANIFEST_VERSION = 1;
const HEX_SHA256 = /^[a-f0-9]{64}$/;

function requireKey(key) {
  if (typeof key !== 'string' || Buffer.byteLength(key, 'utf8') < 32) {
    throw new Error('RLA_BACKUP_MANIFEST_KEY must contain at least 32 UTF-8 bytes');
  }
  return Buffer.from(key, 'utf8');
}

function hmacFor(payload, key) {
  return crypto.createHmac('sha256', requireKey(key)).update(JSON.stringify(payload)).digest('hex');
}

function hashFile(filePath) {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash('sha256');
    const stream = fs.createReadStream(filePath);
    stream.on('error', reject);
    stream.on('data', chunk => hash.update(chunk));
    stream.on('end', () => resolve(hash.digest('hex')));
  });
}

async function createManifest(backupPath, manifestPath, key) {
  requireKey(key);
  const resolvedBackup = path.resolve(backupPath);
  const resolvedManifest = path.resolve(manifestPath);
  const stat = await fs.promises.stat(resolvedBackup);
  if (!stat.isFile() || stat.size === 0) throw new Error('Backup must be a non-empty regular file');
  if (resolvedBackup === resolvedManifest) throw new Error('Manifest path must differ from backup path');

  const payload = {
    version: MANIFEST_VERSION,
    artifact: path.basename(resolvedBackup),
    sizeBytes: stat.size,
    sha256: await hashFile(resolvedBackup),
    createdAt: new Date().toISOString()
  };
  const manifest = { ...payload, hmacSha256: hmacFor(payload, key) };
  const directory = path.dirname(resolvedManifest);
  const temporaryPath = path.join(directory, `.${path.basename(resolvedManifest)}.${process.pid}.${crypto.randomBytes(8).toString('hex')}.tmp`);
  let handle;
  try {
    handle = await fs.promises.open(temporaryPath, 'wx', 0o600);
    await handle.writeFile(`${JSON.stringify(manifest, null, 2)}\n`, { encoding: 'utf8' });
    await handle.sync();
    await handle.close();
    handle = null;
    await fs.promises.rename(temporaryPath, resolvedManifest);
    return manifest;
  } catch (error) {
    if (handle) await handle.close().catch(() => {});
    await fs.promises.unlink(temporaryPath).catch(() => {});
    throw error;
  }
}

async function verifyManifest(backupPath, manifestPath, key) {
  const resolvedBackup = path.resolve(backupPath);
  const manifest = JSON.parse(await fs.promises.readFile(path.resolve(manifestPath), 'utf8'));
  const { version, artifact, sizeBytes, sha256, createdAt, hmacSha256, ...extra } = manifest;
  if (Object.keys(extra).length || version !== MANIFEST_VERSION || typeof artifact !== 'string' ||
      !Number.isSafeInteger(sizeBytes) || sizeBytes < 1 || !HEX_SHA256.test(sha256 || '') ||
      typeof createdAt !== 'string' || !HEX_SHA256.test(hmacSha256 || '')) {
    throw new Error('Backup manifest schema is invalid');
  }
  const payload = { version, artifact, sizeBytes, sha256, createdAt };
  const expectedHmac = Buffer.from(hmacFor(payload, key), 'hex');
  const actualHmac = Buffer.from(hmacSha256, 'hex');
  if (actualHmac.length !== expectedHmac.length || !crypto.timingSafeEqual(actualHmac, expectedHmac)) {
    throw new Error('Backup manifest authentication failed');
  }
  if (artifact !== path.basename(resolvedBackup)) throw new Error('Backup artifact name does not match manifest');
  const stat = await fs.promises.stat(resolvedBackup);
  if (!stat.isFile() || stat.size !== sizeBytes) throw new Error('Backup size does not match manifest');
  const actualHash = await hashFile(resolvedBackup);
  const expectedHash = Buffer.from(sha256, 'hex');
  const actualHashBytes = Buffer.from(actualHash, 'hex');
  if (!crypto.timingSafeEqual(actualHashBytes, expectedHash)) throw new Error('Backup SHA-256 does not match manifest');
  return { ok: true, artifact, sizeBytes, sha256 };
}

/**
 * Copy an authenticated backup into a newly-created private directory, then
 * verify the staged copy against the same authenticated manifest. Restore
 * callers must use the returned stagedPath, not the mutable original path.
 */
async function stageVerifiedBackup(backupPath, manifestPath, stagingRoot, key) {
  requireKey(key);
  const resolvedBackup = path.resolve(backupPath);
  const resolvedRoot = path.resolve(stagingRoot);
  const sourceLstat = await fs.promises.lstat(resolvedBackup);
  if (sourceLstat.isSymbolicLink() || !sourceLstat.isFile() || sourceLstat.size < 1) {
    throw new Error('Backup must be a non-empty regular file, not a symbolic link');
  }

  const verifiedSource = await verifyManifest(resolvedBackup, manifestPath, key);
  const rootLstat = await fs.promises.lstat(resolvedRoot);
  if (rootLstat.isSymbolicLink() || !rootLstat.isDirectory()) {
    throw new Error('Staging root must be an existing directory, not a symbolic link');
  }
  const rootStat = rootLstat;
  if (process.platform !== 'win32' && (rootStat.mode & 0o077) !== 0) {
    throw new Error('Staging root must not grant group or other permissions');
  }

  const stageDir = path.join(resolvedRoot, `rla-restore-${process.pid}-${crypto.randomBytes(12).toString('hex')}`);
  await fs.promises.mkdir(stageDir, { mode: 0o700 });
  const stagedPath = path.join(stageDir, path.basename(resolvedBackup));
  try {
    await fs.promises.copyFile(resolvedBackup, stagedPath, fs.constants.COPYFILE_EXCL);
    await fs.promises.chmod(stagedPath, 0o600);
    const stagedLstat = await fs.promises.lstat(stagedPath);
    if (stagedLstat.isSymbolicLink() || !stagedLstat.isFile()) {
      throw new Error('Staged backup is not a regular file');
    }
    const verifiedStage = await verifyManifest(stagedPath, manifestPath, key);
    if (verifiedStage.sha256 !== verifiedSource.sha256 || verifiedStage.sizeBytes !== verifiedSource.sizeBytes) {
      throw new Error('Staged backup differs from verified source');
    }
    return { ...verifiedStage, stagedPath, stagingDirectory: stageDir };
  } catch (error) {
    await fs.promises.rm(stageDir, { recursive: true, force: true }).catch(() => {});
    throw error;
  }
}

module.exports = { createManifest, verifyManifest, stageVerifiedBackup };
