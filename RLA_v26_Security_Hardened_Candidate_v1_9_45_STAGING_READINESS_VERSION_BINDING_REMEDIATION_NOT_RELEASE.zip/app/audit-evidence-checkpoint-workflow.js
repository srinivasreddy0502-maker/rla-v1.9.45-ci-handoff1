'use strict';
const crypto = require('node:crypto');
const fs = require('node:fs/promises');
const path = require('node:path');
const { createAuditCheckpoint } = require('./audit-evidence-checkpoint');
const { publishCheckpoint, verifyStoredCheckpoint, validatePrivateDirectory } = require('./audit-evidence-checkpoint-store');

function safeId(id) {
  if (typeof id !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9._-]{0,100}$/.test(id)) throw new Error('checkpointId must use 1-101 safe filename characters');
  return id;
}
async function healthCheckEvidenceStore(storageDir) {
  const store = await validatePrivateDirectory(storageDir, 'storageDir');
  const probe = path.join(store, `.rla-health-${process.pid}-${crypto.randomBytes(12).toString('hex')}.tmp`);
  let handle;
  try {
    handle = await fs.open(probe, 'wx', 0o600);
    await handle.writeFile('RLA_EVIDENCE_STORE_HEALTHCHECK\n', 'utf8');
    await handle.sync();
    await handle.close(); handle = null;
    const st = await fs.lstat(probe);
    if (!st.isFile() || st.isSymbolicLink()) throw new Error('health probe did not create a regular file');
    await fs.unlink(probe);
    return { healthy: true, writable: true, fsync: true, probeRemoved: true };
  } catch (err) {
    if (handle) { try { await handle.close(); } catch (_) {} }
    // Preserve a probe if cleanup or verification failed; do not hide a storage incident.
    throw new Error(`Evidence-store health check failed; inspect probe ${probe} if present: ${err.message}`);
  }
}

/**
 * Controlled application-level orchestration. It verifies the source chain while
 * creating a checkpoint, then publishes the checkpoint to the configured evidence
 * store. It deliberately does not delete staged evidence on publication failure.
 */
async function checkpointAndPublish({ recordsDir, stagingDir, storageDir, checkpointId, auditKey, storeKey, storeKeyId, now = new Date() }) {
  const id = safeId(checkpointId);
  if (path.resolve(stagingDir) === path.resolve(storageDir)) throw new Error('stagingDir and storageDir must be separate directories');
  const staging = await validatePrivateDirectory(stagingDir, 'stagingDir');
  const store = await validatePrivateDirectory(storageDir, 'storageDir');
  const health = await healthCheckEvidenceStore(store);
  const stagedPath = path.join(staging, `${id}.checkpoint.json`);
  const checkpoint = await createAuditCheckpoint({ recordsDir, checkpointPath: stagedPath, key: auditKey, now });
  try {
    const published = await publishCheckpoint({ checkpointPath: stagedPath, storageDir: store, checkpointId: id, storeKey, storeKeyId, now });
    return { status: 'PUBLISHED', checkpointId: id, recordCount: checkpoint.recordCount, finalRecordDigest: checkpoint.finalRecordDigest, storageHealth: health, stagedPath, ...published };
  } catch (err) {
    throw new Error(`Checkpoint created at ${stagedPath} but publication did not complete; preserve staged checkpoint and reconcile evidence-store state manually: ${err.message}`);
  }
}

/** Read-only inventory of checkpoint/receipt pairs; never repairs or deletes files. */
async function inspectCheckpointStore(storageDir) {
  const store = await validatePrivateDirectory(storageDir, 'storageDir');
  const names = await fs.readdir(store);
  const ids = new Set();
  for (const name of names) {
    let m = /^([A-Za-z0-9][A-Za-z0-9._-]{0,100})\.checkpoint\.json$/.exec(name);
    if (!m) m = /^([A-Za-z0-9][A-Za-z0-9._-]{0,100})\.receipt\.json$/.exec(name);
    if (m) ids.add(m[1]);
  }
  const items = [];
  for (const id of [...ids].sort()) {
    const cp = path.join(store, `${id}.checkpoint.json`);
    const receipt = path.join(store, `${id}.receipt.json`);
    const hasCheckpoint = names.includes(`${id}.checkpoint.json`);
    const hasReceipt = names.includes(`${id}.receipt.json`);
    const item = { checkpointId: id, hasCheckpoint, hasReceipt, state: hasCheckpoint && hasReceipt ? 'PAIR_PRESENT_REQUIRES_VERIFICATION' : hasCheckpoint ? 'ORPHAN_CHECKPOINT_REQUIRES_RECONCILIATION' : 'ORPHAN_RECEIPT_REQUIRES_RECONCILIATION' };
    for (const [file, key] of [[cp, 'checkpointFileType'], [receipt, 'receiptFileType']]) {
      if (!names.includes(path.basename(file))) continue;
      const st = await fs.lstat(file);
      item[key] = st.isSymbolicLink() ? 'SYMLINK' : st.isFile() ? 'REGULAR_FILE' : 'OTHER';
    }
    items.push(item);
  }
  return { readOnly: true, automaticRepair: false, itemCount: items.length, items };
}
async function verifyPublishedCheckpoint(args) { return verifyStoredCheckpoint(args); }
module.exports = { healthCheckEvidenceStore, checkpointAndPublish, inspectCheckpointStore, verifyPublishedCheckpoint };
