'use strict';
const crypto = require('node:crypto');
const fs = require('node:fs/promises');
const path = require('node:path');

const REQUIRED_VALIDATION = v => v && v.integrity === 'ok' && v.foreignKeyViolations === 0 && Number.isInteger(v.userTableCount) && v.userTableCount >= 0 && Array.isArray(v.userTables);
function blocked(reason, details = {}) { return { status: 'BLOCKED', releaseGate: 'BLOCKED', releaseAuthorityGranted: false, reason, ...details }; }
function sha(value) { return typeof value === 'string' && /^[a-f0-9]{64}$/.test(value); }
async function hashFile(file) { return crypto.createHash('sha256').update(await fs.readFile(file)).digest('hex'); }
async function verifyRestoreDrillEvidence({ manifestPath, evidenceDir, reviewer, reviewedAt, approvalReference }) {
  if (typeof reviewer !== 'string' || !reviewer.trim() || typeof approvalReference !== 'string' || !approvalReference.trim() || !reviewedAt || !Number.isFinite(Date.parse(reviewedAt))) return blocked('REVIEW_METADATA_MISSING_OR_INVALID');
  const root = path.resolve(evidenceDir);
  const rootStat = await fs.lstat(root);
  if (!rootStat.isDirectory() || rootStat.isSymbolicLink()) return blocked('EVIDENCE_DIR_NOT_REGULAR_DIRECTORY');
  if (process.platform !== 'win32' && (rootStat.mode & 0o077) !== 0) return blocked('EVIDENCE_DIR_PERMISSIONS_TOO_BROAD');
  const mp = path.resolve(manifestPath);
  if (path.dirname(mp) !== root) return blocked('MANIFEST_MUST_BE_DIRECT_CHILD_OF_EVIDENCE_DIR');
  const mst = await fs.lstat(mp);
  if (!mst.isFile() || mst.isSymbolicLink()) return blocked('MANIFEST_NOT_REGULAR_FILE');
  let m;
  try { m = JSON.parse(await fs.readFile(mp, 'utf8')); } catch { return blocked('MANIFEST_INVALID_JSON'); }
  if (!m || m.schemaVersion !== 1 || m.type !== 'RLA_NATIVE_SQLITE_RESTORE_DRILL' || m.result !== 'PASS' || m.driver !== 'npm sqlite3 native') return blocked('MANIFEST_NOT_NATIVE_RESTORE_PASS');
  if (!m.source || !m.backup || !m.restored || !sha(m.source.sha256Before) || !sha(m.backup.sha256) || !sha(m.restored.sha256)) return blocked('REQUIRED_HASHES_MISSING');
  if (!REQUIRED_VALIDATION(m.source.validation) || !REQUIRED_VALIDATION(m.backup.validation) || !REQUIRED_VALIDATION(m.restored.validation)) return blocked('DATABASE_VALIDATION_FAILED_OR_INCOMPLETE');
  if (m.backup.sha256 !== m.restored.sha256) return blocked('RESTORED_COPY_HASH_MISMATCH');
  for (const [key, artifact] of [['backup',m.backup],['restored',m.restored]]) {
    if (typeof artifact.file !== 'string' || artifact.file !== path.basename(artifact.file) || !/^[A-Za-z0-9][A-Za-z0-9._-]{0,120}$/.test(artifact.file)) return blocked('ARTIFACT_PATH_INVALID', { artifact: key });
    const fp = path.join(root, artifact.file);
    let st; try { st = await fs.lstat(fp); } catch { return blocked('ARTIFACT_MISSING', { artifact: key }); }
    if (!st.isFile() || st.isSymbolicLink()) return blocked('ARTIFACT_NOT_REGULAR_FILE', { artifact: key });
    if (await hashFile(fp) !== artifact.sha256) return blocked('ARTIFACT_HASH_MISMATCH', { artifact: key });
  }
  // This harness cannot independently re-open the source at review time; source hash stability must be recorded by the drill runner and independently checked by the operator.
  return { status: 'EVIDENCE_VALIDATED', releaseGate: 'PENDING_INDEPENDENT_REVIEW', releaseAuthorityGranted: false, runId: m.runId, reviewer: reviewer.trim(), reviewedAt: new Date(Date.parse(reviewedAt)).toISOString(), approvalReference: approvalReference.trim(), note: 'Evidence consistency validated; this does not authorize release or replace independent target-host review.' };
}
module.exports = { verifyRestoreDrillEvidence };
