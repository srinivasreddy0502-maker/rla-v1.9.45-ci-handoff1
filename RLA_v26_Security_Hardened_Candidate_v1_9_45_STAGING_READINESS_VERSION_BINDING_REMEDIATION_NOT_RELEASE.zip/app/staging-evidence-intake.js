'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');
const { TextDecoder } = require('node:util');

const MAX_EVIDENCE_BYTES = 1024 * 1024;
const PASS = 'PASS';
const REQUIRED = Object.freeze({
  recovery: ['backupRestore', 'integrityCheck', 'foreignKeyCheck', 'walCrashRecovery', 'cleanHostRestore'],
  assurance: ['independentSecurityReview', 'authorizedPenetrationTest', 'uat', 'auditEvidenceReview', 'formalGovernanceApproval']
});

function isObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}
function nonEmpty(value, max = 256) {
  return typeof value === 'string' && value.trim().length > 0 && value.length <= max;
}
function canonicalUtc(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(value)) return false;
  const d = new Date(value);
  return Number.isFinite(d.getTime()) && d.toISOString() === value;
}
function sha256(value) { return typeof value === 'string' && /^[a-f0-9]{64}$/i.test(value); }
function addUnexpectedKeys(value, allowed, scope, blockers) {
  const permitted = new Set(allowed);
  for (const key of Object.keys(value)) {
    if (!permitted.has(key)) blockers.push(`UNEXPECTED_FIELD_${scope}:${key}`);
  }
}

function validateStagingEvidenceIntake(input, expectedCandidateVersion = require('../package.json').version) {
  const blockers = [];
  if (!isObject(input)) {
    return { schemaVersion: 1, intakeStatus: 'BLOCKED', blockers: ['EVIDENCE_ROOT_NOT_OBJECT'], releaseStatus: 'RELEASE_BLOCKED', releaseAuthorityGranted: false, productionUseAuthorized: false };
  }
  addUnexpectedKeys(input, ['schemaVersion', 'candidateVersion', 'generatedAt', 'staging', 'dependencyLockfile', 'nativeSqlite', 'recovery', 'assurance', 'evidenceReferences'], 'ROOT', blockers);
  if (input.schemaVersion !== 1) blockers.push('SCHEMA_VERSION_UNSUPPORTED');
  if (input.candidateVersion !== expectedCandidateVersion) blockers.push('CANDIDATE_VERSION_MISMATCH');
  if (!canonicalUtc(input.generatedAt)) blockers.push('GENERATED_AT_INVALID');

  if (isObject(input.staging)) addUnexpectedKeys(input.staging, ['approved', 'isolated', 'environmentId'], 'STAGING', blockers);
  if (!isObject(input.staging) || input.staging.approved !== true || input.staging.isolated !== true || !nonEmpty(input.staging.environmentId, 128)) {
    blockers.push('APPROVED_ISOLATED_STAGING_NOT_EVIDENCED');
  }
  const lock = input.dependencyLockfile;
  if (isObject(lock)) addUnexpectedKeys(lock, ['present', 'sha256', 'generatedInApprovedStaging', 'dependencyReviewStatus', 'provenanceReviewed'], 'DEPENDENCY_LOCKFILE', blockers);
  if (!isObject(lock) || lock.present !== true || !sha256(lock.sha256) || lock.generatedInApprovedStaging !== true || lock.dependencyReviewStatus !== PASS || lock.provenanceReviewed !== true) {
    blockers.push('DEPENDENCY_LOCKFILE_EVIDENCE_INCOMPLETE');
  }
  const sqlite = input.nativeSqlite;
  if (isObject(sqlite)) addUnexpectedKeys(sqlite, ['smokeTestStatus', 'driverVersion', 'nodeVersion', 'platform', 'architecture'], 'NATIVE_SQLITE', blockers);
  if (!isObject(sqlite) || sqlite.smokeTestStatus !== PASS || !nonEmpty(sqlite.driverVersion, 64) || !nonEmpty(sqlite.nodeVersion, 64) || !nonEmpty(sqlite.platform, 64) || !nonEmpty(sqlite.architecture, 64)) {
    blockers.push('NATIVE_SQLITE_EVIDENCE_INCOMPLETE');
  }
  if (isObject(input.recovery)) addUnexpectedKeys(input.recovery, REQUIRED.recovery, 'RECOVERY', blockers);
  if (isObject(input.assurance)) addUnexpectedKeys(input.assurance, REQUIRED.assurance, 'ASSURANCE', blockers);
  for (const key of REQUIRED.recovery) {
    if (!isObject(input.recovery) || input.recovery[key] !== PASS) blockers.push(`RECOVERY_${key.replace(/[A-Z]/g, m => `_${m}`).toUpperCase()}_NOT_PASSED`);
  }
  for (const key of REQUIRED.assurance) {
    if (!isObject(input.assurance) || input.assurance[key] !== PASS) blockers.push(`ASSURANCE_${key.replace(/[A-Z]/g, m => `_${m}`).toUpperCase()}_NOT_PASSED`);
  }
  if (!Array.isArray(input.evidenceReferences) || input.evidenceReferences.length < 1 || input.evidenceReferences.length > 100) {
    blockers.push('EVIDENCE_REFERENCES_INVALID');
  } else {
    const seenIds = new Set();
    const seenHashes = new Set();
    input.evidenceReferences.forEach((ref, i) => {
      if (isObject(ref)) addUnexpectedKeys(ref, ['id', 'sha256', 'capturedAt', 'reviewerId'], `EVIDENCE_REFERENCE_${i + 1}`, blockers);
      if (!isObject(ref) || !nonEmpty(ref.id, 128) || !sha256(ref.sha256) || !canonicalUtc(ref.capturedAt) || !nonEmpty(ref.reviewerId, 128)) {
        blockers.push(`EVIDENCE_REFERENCE_${i + 1}_INVALID`);
        return;
      }
      if (seenIds.has(ref.id)) blockers.push(`EVIDENCE_REFERENCE_${i + 1}_DUPLICATE_ID`);
      seenIds.add(ref.id);
      const normalizedHash = ref.sha256.toLowerCase();
      if (seenHashes.has(normalizedHash)) blockers.push(`EVIDENCE_REFERENCE_${i + 1}_DUPLICATE_SHA256`);
      seenHashes.add(normalizedHash);
      if (canonicalUtc(input.generatedAt) && ref.capturedAt > input.generatedAt) {
        blockers.push(`EVIDENCE_REFERENCE_${i + 1}_CAPTURED_AFTER_GENERATION`);
      }
    });
  }
  const complete = blockers.length === 0;
  const report = {
    schemaVersion: 1,
    candidateVersion: expectedCandidateVersion,
    intakeStatus: complete ? 'EVIDENCE_COMPLETE_PENDING_INDEPENDENT_VERIFICATION' : 'BLOCKED',
    blockers,
    evidenceReferenceCount: Array.isArray(input.evidenceReferences) ? input.evidenceReferences.length : 0,
    evidenceInputDigestSha256: crypto.createHash('sha256').update(JSON.stringify(input)).digest('hex'),
    releaseStatus: 'RELEASE_BLOCKED',
    releaseAuthorityGranted: false,
    productionUseAuthorized: false
  };
  // Bind the digest to the complete generated report (except the digest field itself),
  // rather than only to a small subset of fields.
  report.reportDigestSha256 = crypto.createHash('sha256').update(JSON.stringify(report)).digest('hex');
  return report;
}

function readEvidenceFileNoFollow(filePath) {
  if (typeof filePath !== 'string' || filePath.length === 0) throw new TypeError('evidence file path is required');
  if (typeof fs.constants.O_NOFOLLOW !== 'number') throw Object.assign(new Error('O_NOFOLLOW is unavailable; fail closed'), { code: 'O_NOFOLLOW_UNAVAILABLE' });
  const fd = fs.openSync(filePath, fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW);
  try {
    const before = fs.fstatSync(fd, { bigint: true });
    if (!before.isFile()) throw Object.assign(new Error('evidence input must be a regular file'), { code: 'EVIDENCE_NOT_REGULAR_FILE' });
    if (before.nlink !== 1n) throw Object.assign(new Error('evidence input must have exactly one hard link'), { code: 'EVIDENCE_HARDLINK_REJECTED' });
    if ((Number(before.mode) & 0o022) !== 0) throw Object.assign(new Error('evidence input must not be group/other writable'), { code: 'EVIDENCE_WRITABLE_MODE_REJECTED' });
    if (before.size < 1n || before.size > BigInt(MAX_EVIDENCE_BYTES)) throw Object.assign(new Error('evidence input size is outside permitted bounds'), { code: 'EVIDENCE_SIZE_REJECTED' });
    const chunks = [];
    let total = 0;
    const buffer = Buffer.alloc(16 * 1024);
    while (true) {
      const count = fs.readSync(fd, buffer, 0, buffer.length, null);
      if (count === 0) break;
      total += count;
      if (total > MAX_EVIDENCE_BYTES) throw Object.assign(new Error('evidence input exceeded size limit while reading'), { code: 'EVIDENCE_SIZE_REJECTED' });
      chunks.push(Buffer.from(buffer.subarray(0, count)));
    }
    const after = fs.fstatSync(fd, { bigint: true });
    if (before.dev !== after.dev || before.ino !== after.ino || before.size !== after.size || before.mtimeNs !== after.mtimeNs || before.ctimeNs !== after.ctimeNs || before.nlink !== after.nlink) {
      throw Object.assign(new Error('evidence input changed while being read'), { code: 'EVIDENCE_CHANGED_DURING_READ' });
    }
    const bytes = Buffer.concat(chunks, total);
    try { return new TextDecoder('utf-8', { fatal: true }).decode(bytes); }
    catch { throw Object.assign(new Error('evidence input is not valid UTF-8'), { code: 'EVIDENCE_UTF8_INVALID' }); }
  } finally {
    fs.closeSync(fd);
  }
}

module.exports = { MAX_EVIDENCE_BYTES, readEvidenceFileNoFollow, validateStagingEvidenceIntake };
