# Dependency Preflight Permission and Hard-Link Hardening — v1.9.32

## Scope

The dependency-lockfile preflight now fails closed when security-sensitive inputs are group- or other-writable, or when a preflight input has multiple hard links. The candidate root and `config` directory must be real directories and must not have group/other write bits set. The checks cover `package.json`, `package-lock.json`, and `config/dependency-install-script-policy.json`.

## Rationale

A file that is writable by another local principal, or reachable through multiple hard links, can be changed or aliased outside the expected candidate tree. Rejecting these conditions reduces tampering and aliasing risk before parsing dependency metadata. This is defense in depth and does not replace an isolated staging environment or OS-level access controls.

## Fail-closed behavior

Unsafe file modes and hard-link counts return the existing path-unsafe blocker for the affected input. Unsafe root/config directory modes return the existing directory-unsafe blocker. No dependency installation is started by this preflight.

## Tests added

- Group/other-writable `package.json` is blocked.
- Group/other-writable `package-lock.json` is blocked.
- Group/other-writable `config` directory is blocked.
- Hard-linked `package.json` is blocked.

Tests use synthetic fixtures only; no real land records are read or modified.
