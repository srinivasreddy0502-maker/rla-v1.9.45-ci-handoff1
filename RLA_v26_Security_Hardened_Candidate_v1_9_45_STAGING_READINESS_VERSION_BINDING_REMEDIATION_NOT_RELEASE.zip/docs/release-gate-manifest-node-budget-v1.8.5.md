# Release-Gate Manifest Node-Budget Hardening — v1.8.5

## Change

The strict release-gate JSON parser now limits the total number of parsed JSON values (object, array, primitive) to 25,000 per manifest, in addition to the existing 1 MiB input limit, 64-level nesting limit, duplicate-key rejection, and strict UTF-8 decoding.

When the limit is exceeded, the parser raises `RLA_JSON_MAX_NODES`. The release-gate evaluator fails closed and does not grant release authority.

## Regression coverage

- Reject a JSON array that exceeds the configured node budget.
- Accept a JSON array at the configured node-count boundary.
- Retain existing duplicate-key, depth, manifest-size, evidence-path, digest, review-freshness, symlink, hard-link, and permission tests.

## Security notes and limits

The 25,000-node budget is a candidate policy and requires governance-owner approval before adoption. It is not a substitute for independent parser review or resource limits at the HTTP/request boundary. Filesystem TOCTOU and Windows ACL risks are not resolved by this change. Passing tests do not grant release authority.
