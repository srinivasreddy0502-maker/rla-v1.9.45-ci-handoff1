# Release-Gate Manifest Size Hardening — v1.8.2

## Change

- Adds `MAX_MANIFEST_BYTES = 1,048,576` (1 MiB) for the release-gate manifest.
- Checks the opened file's reported size before reading and checks the bytes actually read again, so a file that grows after the initial stat is also rejected.
- Uses a no-follow file open where the platform exposes `O_NOFOLLOW`; retains regular-file, hard-link and POSIX permission checks.
- Rejects oversized manifests with `RLA_FILE_TOO_LARGE` wrapped in the manifest preflight error.
- Adds a regression test for an oversized manifest.

## Rationale

A manifest is small structured control data. Bounding its size reduces the risk of excessive memory use during release-gate parsing. The limit is a candidate implementation policy and should be reviewed before formal adoption.

## Limitations

This does not eliminate all filesystem time-of-check/time-of-use races, validate Windows ACLs, prove the authenticity of approvals, or grant release authority. Evidence file content size is not limited by this change. A trusted, controlled evidence root and independent review remain required.

## Status

`RELEASE BLOCKED — NOT RELEASE`. Offline tests do not substitute for native SQLite backup/restore, WAL/crash recovery, independent security review, penetration testing, UAT, or formal approval.
