# Release-Gate Manifest JSON Number Hardening — v1.8.9

## Change
The strict JSON manifest parser now rejects numeric tokens that JavaScript parses to a non-finite IEEE-754 number (for example `1e400`) with `RLA_JSON_NUMBER_NOT_FINITE`.

## Rationale
JSON numeric syntax can represent exponents larger than JavaScript's finite Number range. If one consumer sees a huge exponent while another sees `Infinity`, release evidence interpretation can diverge. This candidate rejects overflowed numeric values rather than allowing parser-dependent semantics.

## Regression coverage
- Reject top-level `1e400`.
- Reject nested `-1e999`.
- Accept finite exponent `1e300`.
- Accept finite nested exponent `-2.5e2`.

## Limitations
This validation is not a substitute for a complete manifest schema, independent code review, or staging runtime validation. Underflow to zero and precision loss for very large but finite numbers are not rejected by this change; numeric fields should remain schema-constrained and preferably use strings for identifiers and exact quantities.
