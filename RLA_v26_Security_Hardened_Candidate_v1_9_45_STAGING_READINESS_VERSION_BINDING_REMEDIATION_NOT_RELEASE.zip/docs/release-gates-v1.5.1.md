# Release gates — v1.5.1

- [x] Static suite passes (14/14)
- [x] Offline runtime suite passes (12/12)
- [x] Multi-process write smoke test passes
- [x] Concurrent bootstrap passes; 5 repeated runs
- [x] Syntax checks pass (5/5)
- [ ] Native npm sqlite3 runtime suite
- [ ] Migration rollback, backup/restore, WAL checkpoint, crash recovery
- [ ] User revocation/token lifecycle review
- [ ] Independent security review and penetration test
- [ ] Official workflow/role approval and UAT
- [ ] Deployment sign-off

Decision: RELEASE_BLOCKED until all applicable gates are evidenced and approved.
