# Release-Gate Manifest Parser Input-Boundary Hardening — v1.8.8

## Change

The strict JSON manifest parser now enforces the 1 MiB manifest limit itself, in addition to the file-read limit used by `evaluateReleaseGates`. It measures UTF-8 byte length for primitive string inputs and uses the exact byte length for Buffer inputs. It also accepts only Buffer or primitive string inputs instead of coercing arbitrary objects through `String(input)`.

## Failure codes

- `RLA_MANIFEST_TOO_LARGE`: parser input exceeds `MAX_MANIFEST_BYTES`.
- `RLA_JSON_INPUT_TYPE_INVALID`: input is neither a Buffer nor a primitive string.

## Regression coverage

- Direct oversized string input is rejected.
- Direct oversized Buffer input is rejected.
- Unsupported object input with a custom `toString` is rejected without coercion.
- Existing manifest size, BOM, duplicate-key, strict UTF-8, nesting, node-count, Unicode scalar, evidence integrity, and release-gate tests remain in the offline suite.

## Scope and limitations

This hardening prevents direct parser callers from bypassing the byte-size limit and avoids arbitrary object coercion. It does not establish release readiness, eliminate every filesystem race, validate Windows ACLs, or replace native SQLite backup/restore tests and independent security review. The release state remains `RELEASE BLOCKED — NOT RELEASE`.
