# RLA v26 Security-Hardened Candidate v1.5.3 — Verification Report

**Status:** NOT RELEASE / RELEASE BLOCKED  
**Candidate package version:** `0.7.3-candidate`  
**Purpose:** Add an offline regression test proving schema changes are rolled back when legacy database migration fails partway through initialization.

## Change

Added `tests/runtime/migration-rollback.test.js` and wired it into `npm run test:all:offline`. The test seeds a deliberately malformed legacy `applications` table, launches the server using the test-only `node:sqlite` compatibility adapter, expects startup to fail closed, and verifies that tables, columns, and indexes created during the failed initialization transaction do not remain.

## Results observed in this environment

- Static security suite: **14/14 PASS**.
- Offline runtime integration suite: **12/12 PASS**.
- Multi-process concurrent-write smoke test: **1/1 PASS**.
- Concurrent bootstrap race smoke test: **1/1 PASS**.
- Concurrent bootstrap stress test: **10/10 iterations PASS** (fresh database each iteration; two server processes per iteration).
- Migration rollback regression: **1/1 PASS**.
- JavaScript syntax checks: **PASS** for `app/server.js` and the new test.
- ZIP integrity: checked after packaging.

## Important limitations

- Offline runtime tests use a test-only adapter backed by Node.js `node:sqlite`; this is **not** the production npm `sqlite3` package.
- This migration test uses a deliberately malformed schema to force a migration failure. It does not replace a full legacy-schema compatibility matrix or crash/power-loss testing.
- Native-driver verification, backup/restore, WAL checkpointing, crash recovery, filesystem permissions, user revocation, token lifecycle, independent security review, penetration testing, official workflow approval, UAT, and deployment sign-off remain open.

## Release gates

- [x] Static security suite
- [x] Offline runtime integration suite
- [x] Multi-process concurrent-write smoke test
- [x] Concurrent first-time bootstrap smoke test
- [x] 10-iteration concurrent bootstrap stress test
- [x] Failed migration schema rollback test (offline compatibility adapter)
- [ ] Native npm `sqlite3` driver runtime suite
- [ ] Native-driver migration rollback and crash recovery
- [ ] Backup/restore and WAL checkpoint verification
- [ ] Filesystem permissions and deployment configuration review
- [ ] User revocation/token lifecycle review
- [ ] Independent security review and penetration test
- [ ] Official workflow/role approval and UAT
- [ ] Deployment sign-off

**Decision:** `OFFLINE_MIGRATION_ROLLBACK_PASS · NATIVE_SQLITE3_NOT_VERIFIED · RELEASE_BLOCKED`.

For RLA operational mapping, the role name remains **GPO (గ్రామ పాలన ఆఫీసర్)**. Jurisdiction isolation, authorized human approval for official land-record changes, and auditable change history remain mandatory requirements.
