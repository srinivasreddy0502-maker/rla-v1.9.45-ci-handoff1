# RLA v26 v1.7.7 — Release-Gate Evidence Hard-Link and Permission Hardening

**Disposition: RELEASE BLOCKED — NOT RELEASE**

## Change summary

Building on v1.7.6 symlink controls, the evidence reader now rejects files whose opened file handle reports more than one hard link, and on POSIX rejects manifest/evidence files with group or other permission bits set. These checks apply to the opened file handle, not just a pre-open path lookup. This reduces the chance that evidence can be aliased outside the evidence directory or modified/read through overly permissive filesystem permissions.

The evaluator continues to require the eight defined release gates, evidence digests, reviewer/timestamp/approval metadata, and a private evidence root. It continues to return `releaseAuthorityGranted: false` unconditionally.

## Added regression tests

- Reject evidence files with multiple hard links.
- Reject evidence files with non-private POSIX permissions.

## Verification

- `npm run test:all:offline`: 143 passed, 0 failed, 0 skipped across 23 test-runner summaries.
- Focused release-gate evidence suite: 10 passed, 0 failed, 0 skipped.
- JavaScript syntax checks: all discovered `.js` files passed `node --check`.
- ZIP integrity: verified after packaging.
- Native SQLite preflight: BLOCKED, exit code 2, `NATIVE_SQLITE3_DRIVER_UNAVAILABLE`.
- Native file-level backup/restore: NOT RUN.

## Limitations

- Filesystem semantics differ by OS and filesystem; hard-link counts and permission bits must be verified on the target host. The current checks do not eliminate path-component TOCTOU races or replace operating-system isolation and independent evidence review.
- Offline tests do not establish production security, native SQLite correctness, or recovery objectives.

## Required release gates remain open

1. Install and attest the approved native SQLite dependency on a target-like staging host.
2. Pass native preflight and complete a real isolated backup/restore drill.
3. Independently validate integrity, foreign keys, table inventory, domain invariants, and WAL/crash recovery; repeat restore and failure-recovery drills.
4. Verify production audit-workflow integration and independent WORM storage.
5. Complete independent security review, penetration testing, UAT, and formal release approval.

No production database was changed. Do not deploy this candidate to production.
