# RLA v26 Security-Hardened Candidate v1.9.5 — Verification Report

**Track:** NOT_RELEASE  
**Decision:** RELEASE_BLOCKED — NOT RELEASE  
**Generated:** 2026-10-12  
**Baseline:** v1.9.4 (preserved unchanged)

## Scope

Added dependency lockfile preflight governance. Direct dependency `sqlite3` is now pinned to exact version `5.1.7` in `package.json`. The new checker requires a valid npm lockfile v3+, matching package identity and root dependency declarations, exact direct dependency entries, HTTPS tarball URLs from an explicitly approved host, and integrity metadata. It emits machine-readable results and fails closed. Staging evidence capture now includes the actual dependency-lockfile preflight result.

## Verification results

- Full offline suite: **189 passed, 0 failed, 0 skipped** across 25 test-runner summaries.
- New dependency-lockfile preflight tests: **10 passed, 0 failed, 0 skipped**.
- Staging readiness report tests: **7 passed, 0 failed, 0 skipped**.
- JavaScript syntax checks: **54/54 passed**.
- ZIP archive integrity: checked after packaging.
- Dependency lockfile preflight: **BLOCKED**, exit code 2, `PACKAGE_LOCK_JSON_MISSING`.
- Native SQLite preflight: **BLOCKED**, exit code 2, `NATIVE_SQLITE3_DRIVER_UNAVAILABLE`.
- Staging evidence capture: exit code 2; records both blockers, `releaseAuthorityGranted: false`, and `productionUseAuthorized: false`.

## Limitations

No package lockfile was generated or approved. No `npm ci` was run. Structural tests use temporary fixture files and do not demonstrate registry access or dependency installation. Native SQLite backup/restore, WAL/crash recovery, clean-host restore, independent security review, penetration testing, UAT, audit evidence review, and formal approval remain unverified.

## Reproduction

```sh
npm run test:all:offline
find app scripts tests -name '*.js' -type f -print0 | xargs -0 -n1 node --check
node scripts/dependency-lockfile-preflight.js
node scripts/native-sqlite-preflight.js
node scripts/capture-staging-readiness.js docs/staging-readiness-evidence-v1.9.5.json
```

The preflight commands are expected to exit `2` in the current environment. The offline test suite and syntax checks should pass. Evidence capture refuses to grant release authority and refuses to overwrite an existing evidence file.

## Required next actions

1. Confirm the approved npm registry/mirror and generate a lockfile only in that approved environment.
2. Review and pin the complete dependency graph, tarball origins, and integrity hashes; then rerun the preflight.
3. Perform a clean staging install from the reviewed lockfile and verify native `sqlite3` operation.
4. Complete actual file-based backup/restore, WAL/crash recovery, integrity/foreign-key checks, and clean-host restore.
5. Complete independent security review, penetration testing, UAT, audit-evidence review, and formal approval.

**Final status: RELEASE_BLOCKED — NOT RELEASE.** Passing offline tests do not establish native SQLite runtime correctness or authorize use against official land records.
