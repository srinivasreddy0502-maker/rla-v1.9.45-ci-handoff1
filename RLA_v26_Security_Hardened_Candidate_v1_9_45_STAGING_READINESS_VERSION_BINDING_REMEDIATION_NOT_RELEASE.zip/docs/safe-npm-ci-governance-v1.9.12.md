# Safe npm CI Governance — RLA v26 v1.9.12

## Purpose

Provide a single guarded entry point for dependency installation. The wrapper runs the existing dependency lockfile preflight first and blocks before invoking npm when the lockfile, approved registry configuration, dependency graph, package origins, integrity metadata, or install-script policy fails validation.

## Install behavior

The fixed command arguments are:

`npm ci --ignore-scripts --no-audit --no-fund`

- `--ignore-scripts` suppresses dependency lifecycle scripts during the initial dependency-fetch/install phase.
- User-supplied command-line arguments are not accepted by the wrapper.
- The wrapper uses the existing approved-registry configuration and dependency lockfile validator.
- If preflight is blocked, npm is not invoked and the wrapper exits with code 2.
- If npm ci succeeds with scripts suppressed, the wrapper records `DEPENDENCIES_FETCHED_WITH_SCRIPTS_SUPPRESSED` and exits with code 3 intentionally. This means dependency files were installed but the application is not yet runtime-ready.
- Native packages such as `sqlite3` may require a separately reviewed build/rebuild step. That step must not be inferred or automatically approved by this wrapper.

## Operational safety

Run only in an isolated staging workspace using synthetic data. Review dependency provenance, lockfile integrity, install-script approvals, and native build requirements independently. Never run this workflow against production land-record data or treat a successful npm command as release approval.

## Known blocker in this candidate

`package-lock.json` is absent, so the wrapper correctly returns `PACKAGE_LOCK_JSON_MISSING` with exit code 2. No `npm ci` execution occurred in this candidate validation.
