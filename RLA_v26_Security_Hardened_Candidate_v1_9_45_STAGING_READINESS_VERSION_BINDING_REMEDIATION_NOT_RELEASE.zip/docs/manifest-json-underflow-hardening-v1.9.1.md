# RLA v26 v1.9.1 — JSON Numeric Underflow Hardening

## Change
The strict release-gate manifest parser rejects a non-zero JSON numeric token when JavaScript IEEE-754 parsing rounds it to zero. This prevents evidence values such as `1e-400` from silently becoming `0`. The parser reports `RLA_JSON_NUMBER_UNDERFLOW`.

Explicit zero forms such as `0e-999` and `-0` remain accepted because their mathematical value is zero. Existing finite-number and safe-integer checks remain in place.

## Regression coverage
- Reject `1e-400`.
- Reject `-1e-999` in a JSON object.
- Accept `0e-999` and `-0`.

## Limitations
This control addresses underflow-to-zero only. It does not provide arbitrary-precision decimal arithmetic and does not eliminate all floating-point precision differences. Independent review and target-environment testing remain required.
