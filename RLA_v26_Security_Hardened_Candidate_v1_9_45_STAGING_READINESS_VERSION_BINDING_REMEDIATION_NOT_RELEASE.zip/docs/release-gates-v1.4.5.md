# RLA v26 Release Gates — v1.4.5

Status: RELEASE_BLOCKED

| Gate | Current status | Evidence required |
|---|---|---|
| Static security tests | PASS (14/14) | Re-run log included in candidate |
| Offline SQLite compatibility integration | PASS (7/7) | Test-only `node:sqlite` adapter log included; not native-driver evidence |
| Native `sqlite3` driver | NOT VERIFIED | Install from approved registry/mirror and run full integration suite |
| Maker-checker | NOT IMPLEMENTED | Implement control model and pass acceptance tests in `maker-checker-control-design.md` |
| User provisioning/revocation | NOT VERIFIED | Lifecycle tests, disabled-user denial, token rotation/revocation evidence |
| Evidence storage and integrity | NOT VERIFIED | Hash verification, upload limits, access controls, retention and deletion tests |
| Legacy audit reconciliation | PENDING GOVERNANCE | Authorized jurisdiction mapping; never infer jurisdiction without evidence |
| Identity provider integration | NOT VERIFIED | Approved authentication architecture and integration tests |
| Production deployment hardening | NOT VERIFIED | TLS/reverse proxy, secret management, backups, restore, monitoring, patching, incident response |
| Independent security review / penetration test | NOT DONE | Signed findings and remediation evidence |
| UAT and official approval | NOT DONE | Authorized user acceptance and competent authority sign-off |

## Release rule
Any `NOT VERIFIED`, `NOT IMPLEMENTED`, `PENDING GOVERNANCE`, or `NOT DONE` gate above blocks production release. A successful static or offline compatibility suite does not override these gates.

Official land-record mutations must retain jurisdiction enforcement, authorized human approval, GPO (గ్రామ పాలన ఆఫీసర్) role naming where applicable, and tamper-evident audit requirements.
