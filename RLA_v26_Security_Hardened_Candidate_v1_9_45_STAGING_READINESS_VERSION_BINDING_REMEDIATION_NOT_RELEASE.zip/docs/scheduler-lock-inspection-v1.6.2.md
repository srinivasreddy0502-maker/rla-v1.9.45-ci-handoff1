# Scheduler Lock Inspection — v1.6.2

The read-only `scripts/inspect-scheduler-lock.js` command reports lock metadata, age, PID visibility, and an operator-review status. It never deletes or modifies a lock and never prints the ownership token.

## Status meanings

- `pid-present-owner-identity-unproven-review-required`: a process currently responds to PID probing, but PID reuse means identity is not established.
- `possibly-stale-lock-operator-review-required`: the PID does not currently resolve; this is not authorization to delete the lock.
- `process-state-unknown-operator-review-required`: process status could not be determined.

## Recovery rule

Never automatically remove a stale-looking lock. Confirm through host/service/process supervision and operations records that no backup job is active, preserve the lock metadata for audit, obtain authorized operator approval, and then use the approved runbook to resolve it. PID probing is diagnostic only and is not a distributed lock/fencing mechanism. Validate filesystem semantics before multi-host use.
