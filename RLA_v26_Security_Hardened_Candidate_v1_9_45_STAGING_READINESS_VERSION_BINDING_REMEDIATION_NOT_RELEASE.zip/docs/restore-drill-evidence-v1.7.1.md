# RLA v26 — Restore-Drill Evidence Verification v1.7.1

Status: NOT RELEASE / RELEASE BLOCKED.

This module checks a native SQLite restore-drill manifest and its backup/restored artifacts for consistent hashes, successful SQLite integrity and foreign-key checks, private evidence directory, regular files, and review metadata. A valid result is `EVIDENCE_VALIDATED` with `releaseGate: PENDING_INDEPENDENT_REVIEW`; it never grants release authority.

The verifier is an evidence consistency check, not proof that the manifest claims are truthful. It does not itself execute SQLite or independently re-open the original source database. A real native-driver run, source hash stability, target-host restore drill, independent review, security testing, UAT, and formal approval remain required. Do not synthesize PASS evidence when the native driver is unavailable.
