# RLA v26 v1.5.0 — Concurrent Bootstrap and Migration Hardening

Status: NOT RELEASE

## Change

- Startup schema creation, additive column migrations, index creation, and one-time bootstrap account creation now execute inside a SQLite `BEGIN IMMEDIATE` transaction after connection-level PRAGMAs are configured.
- This uses SQLite's database-level writer lock to serialize initialization across processes, rather than relying on the in-process transaction queue alone.
- Added `tests/runtime/concurrent-bootstrap.test.js`, which launches two server processes concurrently against one fresh database and verifies both become ready and exactly one bootstrap administrator exists.
- Added npm script `test:bootstrap-race:offline`.

## Verification performed in this environment

- Static security suite: 14/14 PASS.
- Offline runtime integration suite: 12/12 PASS.
- Existing two-process concurrent write smoke test: 1/1 PASS (20 writes asserted by test).
- Concurrent first-start bootstrap test: 1/1 PASS.
- Syntax checks: PASS.
- Test adapter uses Node.js `node:sqlite`; it is test-only and is not the production npm `sqlite3` driver.

## Limitations / release gates

- Native npm `sqlite3` driver integration has not been verified in this environment.
- The race test is an offline compatibility test; repeat it with the native driver in the approved build environment.
- Validate lock timeout behavior under slow storage, failed migration rollback, backup/restore, WAL checkpointing, filesystem permissions, and crash recovery.
- Independent security review, penetration testing, official workflow/role approval, UAT, and deployment sign-off remain required.

## Decision

`CONCURRENT_BOOTSTRAP_OFFLINE_PASS · NATIVE_SQLITE3_NOT_VERIFIED · RELEASE_BLOCKED`
