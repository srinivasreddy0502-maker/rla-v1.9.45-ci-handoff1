# Package Integrity Test Summary v1.9.6

Focused tests: 9 passed, 0 failed, 0 skipped.

Covered cases:
1. Valid SHA-256 manifest creation and verification.
2. Content tampering detection.
3. Missing file detection.
4. Unexpected file detection.
5. Duplicate and unsafe manifest path rejection.
6. Malformed digest, size, and schema rejection.
7. Symbolic-link rejection where supported by the host.
8. Missing manifest fail-closed behavior.
9. Manifest output path constrained to the package root.

The suite tests integrity mechanisms; it is not a signed provenance attestation.
