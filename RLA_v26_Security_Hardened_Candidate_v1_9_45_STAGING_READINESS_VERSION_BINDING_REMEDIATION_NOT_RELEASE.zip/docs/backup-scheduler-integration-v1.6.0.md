# RLA v26 v1.6.0 — Backup Scheduler Integration Contract

**Status: design/runbook only; no host scheduler is installed or enabled by this package.**

## Required scheduled-job order

1. The deployment operator provisions the source DB path, backup directory and manifest directory. On POSIX systems, backup/manifest directories must be private (mode `0700`); backup artifacts are created with restrictive permissions.
2. The secret `RLA_BACKUP_MANIFEST_KEY` is injected at runtime from the approved secret manager. Never place it in this ZIP, source control, command-line arguments, logs, or scheduler unit text.
3. Run the preflight before every backup:
   `node scripts/backup-preflight.js <source-db> <new-backup-file> <new-manifest-file>`
4. Only if preflight exits `0`, run:
   `node scripts/create-consistent-backup.js <source-db> <new-backup-file> <new-manifest-file>`
5. Require exit code `0`, then independently verify the backup/manifest using `scripts/backup-manifest.js verify <backup-file> <manifest-file>`.
6. Emit a sanitized operational event containing run ID, exit code, artifact identifiers, size and digest; never include the HMAC key. Alert on non-zero exit, missing manifest, digest mismatch, or missed scheduled run.
7. Apply approved retention only after the off-site copy is verified and the retention policy authorizes deletion. Do not silently overwrite artifacts.
8. Periodically conduct a restore drill to a separate target, run SQLite integrity and foreign-key checks, then application-level read-only validation.

## Scheduler requirements

- Use a host-level singleton lock (for example, `flock` on Linux) so overlapping jobs cannot write to the same artifact paths.
- Use unique, timestamped artifact names; create paths under administrator-controlled directories.
- Set explicit least-privilege service identity, umask `077`, bounded execution timeout, disk-space alerting, and a documented owner/on-call route.
- Configure the schedule only after validating native `sqlite3` on the target host and running a real backup/restore drill. This package intentionally does not install a systemd unit, cron entry, cloud schedule, or production credentials.

## Evidence still required

A passing preflight confirms path/permission/key shape and API availability only. It does not prove a backup completed, that WAL state is consistent, that off-site replication succeeded, or that restore meets RPO/RTO. Record native-driver versions, real command outputs, artifact hashes, restore target, integrity-check results, application smoke tests, operator and approval ticket in the controlled evidence store.
