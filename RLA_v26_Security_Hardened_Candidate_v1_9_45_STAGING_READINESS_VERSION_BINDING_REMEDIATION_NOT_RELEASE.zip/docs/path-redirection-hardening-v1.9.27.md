# Dependency Lockfile Acquisition Path-Redirection Hardening — v1.9.27

## Controls added

1. The candidate root must exist, be a directory, not be a symbolic link, and match its canonical real path.
2. `package.json` must be a regular non-symlink file before the planner reads it.
3. `package-lock.json` is checked with `lstat`; a symbolic link or non-regular object is reported as `PACKAGE_LOCK_PATH_UNSAFE`, while an existing regular file remains blocked for review.
4. A rejected root prevents package and lockfile inspection below that root.
5. Regression tests cover root symlinks, package manifest symlinks, and lockfile symlinks.

## Limits

These checks are not a substitute for staging isolation, least-privilege filesystem permissions, immutable build inputs, independent lockfile review, or race-resistant filesystem operations. The planner remains non-executing: no network, lockfile creation, npm install, or npm ci is performed.
