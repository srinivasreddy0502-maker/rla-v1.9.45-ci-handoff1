# RLA v26 — Dependency Origin and Bundled-Entry Hardening v1.9.16

**Status:** Candidate-only hardening; `RELEASE_BLOCKED — NOT RELEASE`.

## Change

The dependency-lockfile preflight now rejects two additional classes of lockfile ambiguity:

1. Tarball URLs with a non-default HTTPS port, query string, or fragment are rejected, in addition to existing checks for HTTPS, credentials, and the configured approved hostname allowlist.
2. A lock entry cannot set `inBundle: true` to bypass resolved-tarball and SHA-512 integrity checks. Such entries now block with `BUNDLED_DEPENDENCY_NOT_APPROVED:<package-key>` pending a separate explicit review path.

## Verification

Focused tests exercise non-standard ports, query strings, URL fragments, and a self-declared bundled entry that omits URL/integrity metadata. The existing valid HTTPS registry fixture continues to pass.

## Limitations

This is structural validation, not cryptographic verification of downloaded tarball bytes, proof of registry account integrity, or independent approval of a real lockfile. `package-lock.json` is still missing from the candidate, so no real dependency graph was accepted and `npm ci` was not run. The approved-registry decision and any future lockfile must be reviewed independently. Release remains blocked.
