# RLA v26 — Package Integrity Manifest v1.9.6

## Purpose

This manifest records a SHA-256 digest and byte length for each regular file in the candidate tree, excluding the manifest file itself. Verification detects missing files, unexpected extra files, content changes, unsafe manifest paths, duplicate paths, malformed digests, and symbolic links.

## Use

From the package root:

```sh
node scripts/verify-package-integrity-manifest.js
```

The verifier exits non-zero and reports `BLOCKED` if any check fails. Rebuild a manifest only as part of an authorized package assembly process:

```sh
node scripts/create-package-integrity-manifest.js
```

The creator uses exclusive creation and refuses to overwrite an existing manifest. For a new build, remove the old candidate only in a separate build workspace and generate a fresh manifest after all package files are final.

## Limitations

- SHA-256 file hashes provide integrity comparison, not authenticity or a digital signature.
- A manifest and its package can both be replaced by an attacker with write access; distribute the ZIP SHA-256 through an independently trusted channel.
- Verification is a point-in-time check and does not prove freedom from time-of-check/time-of-use races after verification.
- Passing this check does not establish runtime correctness, security approval, land-record correctness, or production authorization.
