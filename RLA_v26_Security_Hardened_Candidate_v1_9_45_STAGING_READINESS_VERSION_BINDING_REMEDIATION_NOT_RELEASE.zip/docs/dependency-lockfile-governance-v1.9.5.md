# RLA v26 — Dependency Lockfile Governance v1.9.5

## Purpose

Prevent installation attempts from being treated as approved when the dependency graph is not pinned, the lockfile is missing/inconsistent, or resolved tarballs are not from an explicitly approved HTTPS registry origin.

## Implemented checks

- Direct runtime dependencies must use exact versions, not ranges or tags.
- `package-lock.json` must exist and be valid JSON.
- Lockfile format must be npm lockfile version 3 or newer.
- Package name/version metadata and root dependency declarations must match `package.json`.
- Each direct dependency must have a matching locked package entry and version.
- Resolved tarball URLs must use HTTPS, contain no embedded credentials, and use an exact host in `RLA_APPROVED_NPM_REGISTRIES`.
- Resolved package entries must have valid integrity metadata; missing integrity blocks unless the package is explicitly bundled.
- The preflight is fail-closed and never grants production authorization.

## Current result

The current candidate intentionally has no `package-lock.json`, so the actual preflight returns `BLOCKED`, `PACKAGE_LOCK_JSON_MISSING`, and exit code `2`. Do not run `npm ci` until the lockfile is generated using an approved registry/mirror, reviewed, and committed into the candidate.

Default approved registry host: `registry.npmjs.org`.

For an approved internal mirror, set `RLA_APPROVED_NPM_REGISTRIES` to a comma-separated list of exact hostnames, for example `npm-mirror.example.gov`. Do not include URL schemes, paths, credentials, or port numbers. Configure this only after the organization formally approves the mirror.

## Commands

```sh
node scripts/dependency-lockfile-preflight.js
npm run test:dependency-lockfile:offline
```

The first command exits non-zero while blocked. A `PASS` means only that the structural lockfile checks pass; it is not proof of package provenance review, a successful installation, native driver operation, or production authorization.

## Mandatory remaining gates

1. Approved registry and dependency lockfile review.
2. Clean install in target-like staging from the reviewed lockfile.
3. Native SQLite driver smoke test and actual file-based backup/restore.
4. WAL/crash recovery, integrity and foreign-key checks, and clean-host restore drill.
5. Independent security review, penetration testing, UAT, audit-evidence review, and formal release approval.
