# RLA v26 v1.4.9 — Multi-process SQLite Concurrency

## Change
- SQLite connection initialization sets `PRAGMA busy_timeout=5000` to wait for short-lived database lock contention.
- SQLite journal mode is set to WAL for reader/writer coexistence.
- Added a two-server-process test sharing one SQLite file. The test creates 20 applications concurrently across both processes and verifies all 20 writes succeed, IDs are unique, and both processes read the complete set.

## Test boundary
This test uses the repository's test-only compatibility adapter backed by Node.js `node:sqlite`. It is useful evidence for SQLite file-locking behavior in this environment, but it does not validate the native npm `sqlite3` driver or a production deployment. The second process starts after the first process completes schema/bootstrap initialization; concurrent first-time migration/bootstrap remains unverified.

## Required follow-up
- Repeat with native `sqlite3` in the approved build environment.
- Test concurrent startup/migrations or enforce a single migration job before application replicas start.
- Validate backup/restore, filesystem permissions, WAL checkpointing, and deployment topology.
