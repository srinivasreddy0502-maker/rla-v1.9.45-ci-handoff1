# RLA v26 v1.9.25 — Approved Registry Lockfile Acquisition Runbook

## Purpose
The candidate currently has no `package-lock.json`. This runbook prepares a fail-closed plan for acquiring one from an explicitly approved HTTPS registry without inventing package versions or integrity values.

## Current environment result
The current environment could not resolve `registry.npmjs.org` (`EAI_AGAIN`). No lockfile was generated and no install was attempted. This is a connectivity limitation, not evidence that the registry is unsafe or that a lockfile is valid.

## Plan-only command
Set both variables explicitly in a connected, isolated staging runner:

- `RLA_APPROVED_NPM_REGISTRIES=registry.npmjs.org`
- `RLA_APPROVED_NPM_REGISTRY=https://registry.npmjs.org/`

Then run `npm run preflight:dependency-lockfile-acquisition`. The script only prints a plan; it does not access the network or write a lockfile.

## Controlled acquisition procedure
1. Create a clean, isolated temporary staging directory from the reviewed `package.json` and the relevant policy files. Do not use production credentials or land-record data.
2. Confirm the approved registry and runner PATH using the organization's change-controlled runner image.
3. Run the generated `npm install --package-lock-only --ignore-scripts --no-audit --no-fund --lockfile-version=3 --registry=https://registry.npmjs.org/` command in that temporary directory only.
4. Preserve command output, npm version, Node version, registry URL, timestamps, runner image identity, and generated lockfile SHA-256 as evidence.
5. Run the RLA dependency-lockfile preflight. Review every package URL, SHA-512 integrity, transitive dependency, and install-script policy finding. Do not promote a lockfile that has blockers.
6. Obtain independent review and approval before copying a verified lockfile into a candidate workspace. `npm ci` and native builds are separate, later gates.

## Safety properties
- Explicit registry origin is required; non-HTTPS origins, credentials, custom ports, paths, queries, fragments, and non-allowlisted hosts are rejected.
- Existing `package-lock.json` files are never overwritten by this planning tool.
- Dependency versions must be exact stable pins.
- The tool never performs network access, creates a lockfile, runs `npm ci`, or authorizes production use.

## Release status
`RELEASE BLOCKED — NOT RELEASE`. Native SQLite build, real backup/restore and WAL/crash recovery, independent security review, authorized penetration testing, UAT, audit evidence, and formal governance approval remain pending.
