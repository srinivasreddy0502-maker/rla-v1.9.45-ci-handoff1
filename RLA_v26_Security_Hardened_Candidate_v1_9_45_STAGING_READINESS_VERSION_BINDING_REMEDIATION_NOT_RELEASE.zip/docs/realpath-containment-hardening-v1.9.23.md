# RLA v26 — v1.9.23 Real-Path Containment Hardening

## Change

Restore-drill preflight previously used `path.resolve()` for source and evidence paths. That normalizes `.` and `..` but does not resolve symlinked ancestor directories. A source database reachable through an ancestor symlink could therefore be evaluated using lexical paths rather than the filesystem's canonical paths.

The preflight now:

- rejects a symlink at the final source-file or evidence-directory component;
- resolves ancestor path components with `fs.realpath()` after the final-component type checks;
- performs source/evidence containment checks against canonical paths;
- returns the canonical evidence path for subsequent lock and output creation.

Two regression tests cover a source file reached through an ancestor symlink that aliases into the evidence directory, and a symlinked evidence ancestor whose canonical path must be used.

## Verification

- Focused native SQLite restore-drill tests: 17 passed, 0 failed, 0 skipped.
- Full offline test workflow: 251 passed, 0 failed, 0 skipped across 29 test summaries.
- ZIP and SHA-256 checks are recorded alongside this candidate.

## Limits

These are filesystem/preflight tests, not a real SQLite backup/restore exercise. The native `sqlite3` driver is unavailable in the current environment and `package-lock.json` is missing; `npm ci` was not run. Symlink regression tests are skipped on Windows because symlink creation privileges vary there; the Linux test environment executed both tests.

## Release decision

`RELEASE BLOCKED — NOT RELEASE`. This candidate is not authorized for production or for modification of official land records. Independent security review, authorized penetration testing, UAT, native SQLite recovery drills, audit-evidence review, and formal governance approval remain mandatory.
