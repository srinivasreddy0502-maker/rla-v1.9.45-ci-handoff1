# RLA v26 v1.9.33 — Staging Evidence Intake Hardening

## Purpose

Provide a fail-closed intake validator for externally generated staging evidence. This does not create staging evidence, contact a registry, install dependencies, run npm, or authorize release.

## Required evidence categories

- Approved and isolated staging environment identity.
- `package-lock.json` presence, SHA-256, generation in the approved staging environment, dependency graph review, and provenance review.
- Native SQLite driver smoke-test details and runtime/platform identity.
- Backup/restore, SQLite `integrity_check`, `foreign_key_check`, WAL/crash recovery, and clean-host restore evidence.
- Independent security review, authorized penetration test, UAT, audit-evidence review, and formal governance approval.
- Evidence references with IDs, SHA-256 digests, capture timestamps, and reviewer IDs.

## Security controls

The CLI opens the input with `O_NOFOLLOW` and fails closed when that primitive is unavailable. It accepts only a regular file with exactly one hard link, rejects group/other-writable modes, bounds input to 1 MiB, reads in chunks, and compares descriptor metadata before and after reading. JSON must then pass schema-oriented validation. Invalid or incomplete evidence produces a blocked result.

## Important limitations

The intake tool validates structure and declarations only. It does not authenticate reviewers, cryptographically verify referenced artifacts, prove a staging environment is isolated, or independently establish that tests actually occurred. Evidence references must be independently checked by the authorized reviewers. Even a structurally complete bundle reports `EVIDENCE_COMPLETE_PENDING_INDEPENDENT_VERIFICATION`; `releaseStatus` remains `RELEASE_BLOCKED`, and `productionUseAuthorized` remains `false`.

## Current environment result

No approved staging evidence bundle was supplied or validated in this environment. The existing dependency lockfile is missing, npm installation was not invoked, and the native SQLite driver is unavailable. This candidate remains **RELEASE BLOCKED — NOT RELEASE**.
