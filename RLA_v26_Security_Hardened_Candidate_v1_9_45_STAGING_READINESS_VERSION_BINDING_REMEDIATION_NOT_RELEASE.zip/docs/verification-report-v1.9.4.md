# RLA v26 Security-Hardened Candidate v1.9.4 — Verification Report

**Track:** NOT_RELEASE  
**Decision:** RELEASE_BLOCKED — NOT RELEASE  
**Generated:** 2026-10-12  
**Baseline:** v1.9.3 (preserved unchanged)

## Scope

This candidate adds a bounded, machine-readable staging preflight evidence capture. It runs the existing native SQLite driver preflight in a child process, records a safe subset of its output, records the actual exit status, and keeps release authority false even when the driver smoke test passes. Evidence capture uses exclusive file creation (`wx`) and restrictive permissions (`0600`) so an existing evidence file is not silently overwritten.

## Verification results

- Full offline test suite: **179 passed, 0 failed, 0 skipped** across 24 test-runner summaries.
- New staging-readiness tests: **7 passed, 0 failed, 0 skipped**.
- JavaScript syntax checks: **51/51 passed**.
- ZIP integrity: verified after packaging.
- Native SQLite staging preflight: **BLOCKED**, exit code 2; `NATIVE_SQLITE3_DRIVER_UNAVAILABLE`.
- Approved `package-lock.json`: **NOT PRESENT / NOT VERIFIED**; `npm ci` must not be attempted until a reviewed lockfile is added.
- Evidence capture accurately records `preflightStatus: BLOCKED`, `releaseStatus: RELEASE_BLOCKED`, `releaseAuthorityGranted: false`, and `productionUseAuthorized: false`.

## Important limitations

The staging capture is not a backup/restore test. Native file backup/restore, WAL/crash recovery, clean-host restore, independent security review, penetration testing, UAT, and formal release approval remain unverified. No production authorization is granted. A passing offline suite is not evidence of native SQLite runtime correctness.

## Reproduction

From the candidate root:

```sh
npm run test:all:offline
find app scripts tests -name '*.js' -type f -print0 | xargs -0 -n1 node --check
node scripts/capture-staging-readiness.js docs/staging-readiness-evidence-v1.9.4.json
```

The capture command intentionally exits non-zero if native preflight is blocked. It will not overwrite an existing output file; choose a new evidence path for each run. The current captured evidence is in `staging-readiness-evidence-v1.9.4.json`.

## Required next actions

1. Generate and review `package-lock.json` using the approved registry/mirror, then install approved, lockfile-pinned dependencies in a target-like staging environment with the native `sqlite3` driver.
2. Run the native driver smoke test and then a real file-based backup/restore drill.
3. Verify `PRAGMA integrity_check`, `PRAGMA foreign_key_check`, WAL/crash recovery, and a clean-host restore.
4. Complete independent security review, penetration testing, UAT, audit evidence review, and formal approval.
5. Keep the release blocked until every mandatory gate has independently verifiable evidence and authorized approval.
