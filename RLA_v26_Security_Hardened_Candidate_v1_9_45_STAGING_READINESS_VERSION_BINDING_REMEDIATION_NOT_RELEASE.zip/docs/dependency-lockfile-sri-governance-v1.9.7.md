# Dependency Lockfile SRI Governance — v1.9.7

## Objective

Require strong, well-formed Subresource Integrity metadata for registry packages before allowing a dependency installation attempt.

## Controls

- Direct runtime dependencies must remain exact-version pins.
- `package-lock.json` must exist, use a supported modern lockfile format, match package identity, and agree with declared direct dependencies.
- Registry tarball origins must use HTTPS, have no embedded credentials, and match the approved registry-host allowlist.
- Non-bundled package entries must include integrity metadata.
- Integrity algorithm must be SHA-512.
- Encoded digest must decode to exactly 64 bytes and be canonical Base64 (decode/re-encode equality).
- Linked dependencies and unsafe or unapproved origins remain blocked.
- Any failed validation blocks installation. Passing validation does not grant production authorization.

## Operational workflow

1. Create the lockfile in an approved environment using the approved registry or internal mirror.
2. Review dependency changes and registry origins; verify SRI against trusted registry metadata.
3. Run `npm run preflight:dependency-lockfile`.
4. Only after preflight passes, perform a clean staging install using `npm ci`.
5. Record the exact Node/npm versions, lockfile digest, install log, and review approval.
6. Run native SQLite integration and recovery drills separately.

## Current candidate status

This candidate does not include `package-lock.json`; current preflight correctly returns `PACKAGE_LOCK_JSON_MISSING`. Do not fabricate lockfile entries or infer package integrity values. Release remains blocked.
