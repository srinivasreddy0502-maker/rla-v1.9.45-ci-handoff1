# v1.9.41 Candidate — Test Process Cleanup Remediation

Status: REMEDIATION CANDIDATE / NOT RELEASE.

## Finding
The offline multi-process and bootstrap tests used inconsistent child-process teardown. Some paths sent SIGKILL without confirming the child emitted `exit`; one path registered its exit listener after sending SIGTERM. This can make chained test completion nondeterministic and leave child-process/stdio handles pending.

## Change
A shared `tests/runtime/test-support/stop-child.js` helper now registers its exit listener before waiting, uses bounded graceful shutdown, escalates to SIGKILL when necessary, verifies exit, and throws if the child does not terminate. The helper is used by the multi-process concurrency, bootstrap race, bootstrap stress, and native-runtime integration tests.

## Safety
Only test harness teardown is changed; application authorization, jurisdiction checks, maker-checker workflow, land-record mutations, and production authorization policy are unchanged. The v1.9.40 ZIP remains immutable. This candidate is not release-approved.
