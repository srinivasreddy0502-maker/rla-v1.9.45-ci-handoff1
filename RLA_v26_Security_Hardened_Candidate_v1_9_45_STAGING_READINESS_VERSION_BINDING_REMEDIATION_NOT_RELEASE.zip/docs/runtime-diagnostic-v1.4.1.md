# RLA v26 — v1.4.1 Runtime Diagnostic / NOT FOR RELEASE

Date: 2026-10-12

## Purpose

This candidate corrects the test-runner command in v1.4. The prior `"test": "node --test tests"` command is not compatible with the available Node.js v22.16.0 invocation: Node interpreted `tests` as a module path and returned `MODULE_NOT_FOUND`. The script is now `node --test`, allowing Node's built-in test discovery to find top-level and nested test files.

## Verification evidence

- ZIP integrity: PASS for the source v1.4 archive before this packaging step.
- `node --check app/server.js`: PASS.
- `node --check tests/security-candidate.test.js`: PASS.
- `node --check tests/runtime/runtime-integration.test.js`: PASS.
- `node --test tests/security-candidate.test.js`: 14/14 PASS.
- `npm ping --fetch-retries=0 --fetch-timeout=8000`: FAIL, `EAI_AGAIN` resolving `registry.npmjs.org`.
- `sqlite3` dependency: unavailable (`MODULE_NOT_FOUND`).
- Runtime integration suite: NOT EXECUTED successfully; it cannot load `sqlite3` until the dependency can be installed in a network-enabled or approved mirrored environment.

## Status

`TEST_RUNNER_CORRECTED · STATIC_TESTS_PASS · RUNTIME_NOT_VERIFIED · RELEASE_BLOCKED`

Do not treat the candidate as production-ready. Do not use real land-record data. Next step is to install dependencies through an approved npm registry/mirror, then execute the full test suite and collect logs. Afterwards verify migration, maker-checker, user provisioning, jurisdiction-scoped audit, independent security review, penetration testing, and UAT.

The original v1.3 and v1.4 ZIP files remain unchanged.
