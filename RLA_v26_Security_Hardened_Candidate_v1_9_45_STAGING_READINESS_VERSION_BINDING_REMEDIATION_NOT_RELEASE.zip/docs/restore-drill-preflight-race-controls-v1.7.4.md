# RLA v26 — v1.7.4 Restore Preflight Race-Narrowing Controls

Status: NOT RELEASE / RELEASE BLOCKED.

## Changes
- Centralizes SQLite WAL/SHM sidecar inspection and output collision checks.
- Rechecks sidecars immediately before native database access and after the backup operation.
- Blocks the drill if a sidecar appears during backup.
- Retains refusal of existing outputs, symlink/non-regular sidecars, and unsafe run IDs.
- Adds tests for sidecar metadata, symlink rejection, and output collision handling.

## Limits
Repeated filesystem checks narrow but cannot eliminate races with active SQLite writers. This does not make raw file hashing a WAL-aware snapshot mechanism. Production use requires a controlled maintenance/quiescence protocol or validated SQLite online backup API behavior, native `sqlite3` installation, target-host tests, and independent approval. No real native restore is claimed.
