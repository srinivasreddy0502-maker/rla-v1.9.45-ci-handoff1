# Audit Evidence Append Workflow — v1.6.5

## Purpose

This candidate adds a serialized append operation to the v1.6.4 audit-evidence utility. It verifies the existing record chain before appending, derives the next sequence and previous-record digest, hashes referenced evidence files, signs the new record with an externally supplied HMAC key, and publishes the record without overwriting an existing sequence file.

## CLI

```sh
RLA_AUDIT_EVIDENCE_KEY='<secret-from-approved-secret-manager>' \
  node scripts/append-audit-evidence.js <private-records-dir> <private-evidence-root> <comma-separated-evidence-names> <actor-id> <event-type> <change-ref>
```

Use private directories with restrictive permissions. Evidence file names are relative to the evidence root. The CLI emits only a short result and never emits the key or record contents.

## Safety behavior

- Acquires an atomic `.append.lock` directory; if one exists, it fails closed and requires operator inspection.
- Verifies the full prior chain before adding a record.
- Uses a unique temporary file, fsync, and a hard-link publication step to avoid overwriting an existing record.
- Uses a random lock ownership token and removes the lock only if its token matches.
- Does not automatically reclaim stale locks.
- Does not write to or modify evidence source files.

## Limits / operational requirements

The append utility is not yet integrated into production RLA workflows or a separately administered WORM store. The records directory and evidence root must be protected from untrusted writers. HMAC key custody and rotation must be managed externally. A privileged administrator with write access to the chain and signing key can still rewrite records. HMAC does not prove that event claims are true. Native `sqlite3` backup/restore and target-host restore drill remain unverified.
