# RLA v26 — Backup/Restore Pipeline Integration Tests (v1.5.9 candidate)

## Purpose

This iteration adds an offline integration suite that exercises the orchestration across backup creation, HMAC/SHA-256 manifest creation, verified staging, restore preflight, SQLite integrity-check orchestration, temporary target copy, and installation. The tests use an explicit fake `sqlite3` adapter to remain deterministic without downloading native dependencies.

## Tests

1. Full offline pipeline creates, authenticates, stages, and installs a backup.
2. Successful replacement retains the prior target file as a recovery point.
3. Tampered manifest is rejected and the existing target remains unchanged.
4. Existing SQLite WAL sidecar blocks restore.
5. Missing operator attestations fail closed before a production CLI can proceed.

## Critical limitation

The adapter writes a test payload, not a real SQLite database. These tests prove orchestration and guard behavior only. They do **not** verify native `sqlite3`, the SQLite online-backup API, actual SQL `PRAGMA` behavior, WAL consistency, process-crash durability, or production integration. The CLI still requires target-environment native-driver tests and a controlled restore drill.

## Governance and release gates

Keep the release blocked until native driver execution, backup/restore drill, crash recovery, target filesystem durability, independent security review, penetration testing, UAT, and formal approval pass. Retain jurisdiction isolation, audit evidence, maker-checker review, and authorized human approval for official land-record changes. Use GPO (గ్రామ పాలన ఆఫీసర్), not VAO.
