# RLA v26 — v1.7.3 WAL-Aware Restore Preflight

Status: NOT RELEASE / RELEASE BLOCKED.

## Changes
- Adds a restore-drill preflight that refuses to operate when `-wal` or `-shm` sidecars exist beside the source database. This avoids treating a raw main-file hash as proof of a consistent SQLite snapshot.
- Refuses pre-existing output artifact names to prevent accidental overwrite.
- Rejects symbolic-link/non-regular WAL sidecars.
- Reuses the preflight before attempting to load the native driver.
- The preflight is intentionally conservative: a future controlled WAL-aware native backup workflow must handle live databases safely rather than deleting sidecars.

## Verification limits
Offline tests exercise preflight and consistency rules only. The native npm `sqlite3` driver remains unavailable in this workspace; a real native backup/restore was not run. WAL presence is blocked, not handled. Target-host restore, crash recovery, production integration, independent security review, penetration testing, UAT, and formal approval remain release blockers.
