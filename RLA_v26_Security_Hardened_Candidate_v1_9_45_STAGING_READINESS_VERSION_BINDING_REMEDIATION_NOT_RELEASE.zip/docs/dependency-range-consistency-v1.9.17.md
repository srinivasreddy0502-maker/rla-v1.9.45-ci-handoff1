# RLA v26 — Dependency Range Consistency Hardening v1.9.17

## Change

The dependency lockfile preflight now verifies that every declared dependency edge points to a locked package version compatible with the declared version spec. Previously it checked that a target package key existed, but did not compare the target's locked version with the requesting package's declared range.

## Supported syntax

The validator supports exact semantic versions, caret (`^`) and tilde (`~`) ranges, comparison operators (`>=`, `>`, `<=`, `<`) in conjunctions, `||` alternatives, and three-component wildcard ranges. Prerelease versions are handled conservatively. Unknown or unsupported spec syntax fails closed with `LOCK_DEPENDENCY_SPEC_UNSUPPORTED`; it is not assumed to be valid. This is an intentionally bounded validator, not a replacement for npm's full semver implementation.

## Regression tests

- A locked version outside a declared caret range is blocked.
- Common caret, tilde, comparator-conjunction and OR forms accept in-range versions.
- Unsupported git URL specs fail closed.
- Existing graph resolution, package identity, registry origin, SHA-512 SRI, install-script policy and bundled-dependency checks remain covered.

## Limits and decision

This is a structural consistency check. It does not authenticate a registry, prove package provenance, validate downloaded bytes, or authorize production installation. The candidate still has no `package-lock.json`, so dependency installation remains blocked and `npm ci` was not run.

**Decision: `RELEASE BLOCKED — NOT RELEASE`.**
