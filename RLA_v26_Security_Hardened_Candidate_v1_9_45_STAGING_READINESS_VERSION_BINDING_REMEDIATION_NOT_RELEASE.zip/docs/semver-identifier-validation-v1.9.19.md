# RLA v26 — SemVer Identifier Validation Hardening v1.9.19

## Change

The dependency lockfile preflight now validates non-empty, dot-separated SemVer prerelease and build-metadata identifiers. Numeric prerelease identifiers with leading zeroes are rejected. Build metadata remains excluded from precedence comparisons, consistent with SemVer 2.0.0.

## Why

The earlier compact regular expressions could accept malformed build metadata such as `1.2.3+..` and malformed prerelease syntax such as `1.2.3-alpha..1`. A lockfile guard should not interpret malformed versions as canonical pins or bounds.

## Verification scope

- Positive stable pins with valid build metadata.
- Empty or repeated build-metadata identifiers.
- Malformed prerelease identifiers and numeric prerelease leading zeroes.
- Build metadata does not affect version precedence.
- Existing dependency graph, registry-origin, SRI, install-script, and safe-install tests.

This is not a complete replacement for npm's `semver` package. Prerelease dependency pins/ranges remain blocked by policy. No network registry was queried and no lockfile was generated. `npm ci` remains blocked while `package-lock.json` is absent.
