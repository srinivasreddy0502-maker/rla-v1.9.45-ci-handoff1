# Scheduler Locking — v1.6.1 Candidate

`app/scheduler-lock.js` uses atomic directory creation as the cross-process lock acquisition point. The lock directory and owner metadata are private (POSIX modes 0700 and 0600). Lock metadata includes PID, acquisition timestamp, and a random ownership token. Release requires the exact token and refuses symlink/non-regular metadata.

`node scripts/run-scheduled-backup.js <source-db> <new-backup-file> <new-manifest-file> <private-lock-path>` wraps the consistent backup workflow with the lock. Supply `RLA_BACKUP_MANIFEST_KEY` through an approved secret manager. The runner does not log the secret.

**Fail-closed rule:** an existing or partially initialized lock is never automatically reclaimed. An operator must verify no backup process is active, inspect the lock owner and host/process state, preserve evidence as required, and remove a stale lock only under an approved runbook. A local file lock does not coordinate across hosts or network filesystems unless the filesystem's atomicity semantics are validated.

This is a candidate helper, not yet connected to the production scheduler/service. Native `sqlite3` backup execution, target-host filesystem semantics, alerts, retry policy, and end-to-end recovery remain release gates.
