# Staging Evidence Intake — Duplicate Digest Hardening v1.9.36

## Risk addressed

An evidence intake report could contain multiple reference IDs that point to the same underlying bytes. Counting those references separately can inflate apparent corroboration without adding independent evidence.

## Change

- Track normalized SHA-256 digests while validating evidence references.
- Reject repeated digests using blocker `EVIDENCE_REFERENCE_<n>_DUPLICATE_SHA256`.
- Compare digests case-insensitively by normalizing to lowercase; SHA-256 values are semantically identical regardless of hexadecimal letter casing.
- Preserve duplicate-ID, timestamp ordering, strict schema, UTF-8, no-follow, hard-link, file mode, and size-limit checks.
- Keep `releaseStatus: RELEASE_BLOCKED`, `releaseAuthorityGranted: false`, and `productionUseAuthorized: false` even when intake is complete.

## Test coverage

A regression test uses two different IDs and case-varied copies of the same digest. The validator must return `BLOCKED`, emit the duplicate SHA-256 blocker, and never grant release authority.

## Limitations

Digest uniqueness does not prove that evidence content is genuine, that a reviewer is authentic, that a test was actually run, or that the evidence source is independent. Those require trusted capture, access controls, independent verification, and audit review.
