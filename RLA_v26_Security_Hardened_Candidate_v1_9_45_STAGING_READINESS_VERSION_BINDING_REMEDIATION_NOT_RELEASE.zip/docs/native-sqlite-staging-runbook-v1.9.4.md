# Native SQLite Staging Readiness Runbook — v1.9.4

## Purpose

Capture repeatable evidence about whether the candidate's native `sqlite3` dependency is available in the current environment. This is only a preflight, not a restore drill and not a release approval.

## Before running

- Use an isolated staging host/container that matches the intended deployment platform and Node.js ABI.
- Use only the organization's approved npm registry/mirror and an audited lockfile.
- Do not point tests at official land records or production databases.
- Preserve the prior candidate ZIP and prior evidence files unchanged.

## Commands

First generate and review `package-lock.json` using the approved registry/mirror and include that lockfile in the reviewed candidate. The current v1.9.4 package does not include a lockfile, so **do not run `npm ci` against this candidate until that prerequisite is satisfied**. After the lockfile has been approved, run:

```sh
npm ci
npm run preflight:native-sqlite
node scripts/capture-staging-readiness.js docs/staging-readiness-<run-id>.json
```

Replace `<run-id>` with a unique identifier; the evidence writer deliberately refuses to overwrite existing files. The capture script records the child-process exit status, driver status, package/runtime details when available, bounded diagnostic text, unresolved follow-up gates, and an explicit `RELEASE_BLOCKED` decision.

## Interpretation

- `DRIVER_SMOKE_PASS`: the native module loads, opens/closes an in-memory DB, returns a SQLite version, and exposes the backup API. This does **not** prove a file backup/restore works.
- `BLOCKED`: the preflight did not pass. Preserve the report and fix the environment/dependency issue; do not fabricate a passing result. The missing approved lockfile is a separate unresolved dependency-governance gate.
- In either case, `releaseAuthorityGranted` and `productionUseAuthorized` remain `false`.

## Required real runtime drill

After the smoke test passes, use a disposable staging database with synthetic data to perform file backup, restore to a separate target, application-level read checks, `PRAGMA integrity_check`, `PRAGMA foreign_key_check`, WAL recovery, crash/restart recovery, and restore on a clean host. Save commands, exact runtime versions, exit codes, sanitized logs, output hashes, and independent reviewer approval in a restricted evidence directory. A human reviewer must verify evidence provenance and applicability to the candidate digest.

## Stop conditions

Stop and retain `RELEASE_BLOCKED` if the driver is missing, evidence is malformed or overwritten, restore output is inconsistent, any integrity check fails, audit events are missing, jurisdiction scoping fails, or independent review/approval is absent. Do not apply candidate migrations to official land records during testing.
