# RLA v26 v1.6.9 — Release Gate Evidence Registry

Status: `NOT_RELEASE`; release authority is never granted by this utility.

The verifier evaluates eight external gates: native sqlite3 backup/restore; WAL/crash-recovery restore drill; production audit workflow integration; independent WORM storage; independent security review; penetration test; UAT; and formal release approval. Each PASS entry must reference a regular evidence file within a private evidence directory and include a matching SHA-256, reviewer, timestamp, and approval reference. Missing, malformed, changed, or inaccessible evidence fails closed.

The shipped manifest deliberately marks all gates `BLOCKED`. Do not replace these statuses with PASS until the actual evidence exists and is independently reviewed. A passing manifest is not a release authorization; the function always returns `releaseStatus: RELEASE_BLOCKED` and `releaseAuthorityGranted: false`.

This module does not install or test the native sqlite3 driver, execute a database restore, conduct penetration testing, or perform UAT. Those remain external verification activities.
