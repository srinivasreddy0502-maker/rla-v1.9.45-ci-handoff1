# Release-Gate Manifest Numeric Precision Hardening — v1.9.0

## Purpose
JavaScript `Number` cannot exactly represent every integer outside the safe-integer range. A JSON manifest containing such values could be rounded during parsing, while another consumer using arbitrary-precision arithmetic could interpret the original integer differently.

## Change
- `parseJsonNoDuplicateKeys` rejects parsed numeric values for which `Number.isInteger(value)` is true and `Number.isSafeInteger(value)` is false.
- Error code: `RLA_JSON_INTEGER_NOT_SAFE`.
- Retains the prior rejection of numeric tokens that parse to non-finite values (`RLA_JSON_NUMBER_NOT_FINITE`).
- Regression coverage rejects `9007199254740992`, `9007199254740993e0`, and `1e300`; accepts `Number.MAX_SAFE_INTEGER`, `Number.MIN_SAFE_INTEGER`, and finite exponent forms within the safe integer range.

## Policy note
This is a candidate parser policy. Confirm compatibility with manifest schema owners before adoption. If legitimate scientific-magnitude values are needed in manifests, represent them as schema-validated strings or define an explicit decimal representation rather than relying on JavaScript `Number` precision.

## Limitations
This check is not a substitute for schema validation. It does not make all floating-point decimal values exact, and it does not prove cross-language equivalence for every numeric representation. Independent review remains required.
