# RLA v26 Hardened Candidate — NOT FOR RELEASE

This is an isolated engineering candidate, not a production release. It intentionally fails closed when the authorization policy is not configured. It preserves the original Library ZIP.

## Configuration
- `RLA_DB_PATH`: optional path for the SQLite database.
- `RLA_BOOTSTRAP_ADMIN_TOKEN`: one-time secure bootstrap token, minimum 32 characters. Do not commit it or log it. The bootstrap account is created only if it does not already exist.
- `RLA_BOOTSTRAP_ADMIN_JURISDICTION`: jurisdiction for the bootstrap user. Keep unset until policy owners define the authoritative jurisdiction identifier.
- `RLA_AUTHZ_POLICY_JSON`: reviewed role-to-permission JSON, e.g. `{"ADMIN":["applications:read","applications:create","applications:transition","audit:read"]}`. This example is illustrative only, not an approved Telangana Revenue role matrix.

## Candidate controls
- Removes the hardcoded demo token and seeded demo administrator.
- Production startup fails closed if bootstrap token or explicit authorization policy is missing.
- Adds jurisdiction fields and filters application reads; missing jurisdiction denies access.
- Requires explicit permission per application action.
- Makes application creation/transition and audit insert transactional.
- Enforces expected version in the SQL update predicate.
- Adds JSON content-type validation, malformed JSON handling, 64 KiB body limit, path checks, security headers and request IDs.
- Audit endpoint returns `503 AUDIT_SCOPE_NOT_IMPLEMENTED` until audit records can be scoped safely; it does not expose global audit data.
- DB initialization is awaited before the listener starts.

## Known limitations / release blockers
- This candidate has not been runtime-tested against sqlite3 because the dependency was not available in the current environment.
- The `evidence` table is schema-only; evidence upload/storage integrity is not implemented here.
- Role-to-permission policy and jurisdiction semantics must be approved by Revenue domain/security owners. Do not use the illustrative policy without review.
- Audit scope needs a governed jurisdiction relationship or approved global audit-reader policy.
- The static candidate tests verify presence of control patterns, not their runtime effectiveness.
- No penetration test, UAT, legal review, or release approval has occurred.
- This demo workflow must not update authoritative land records. AI remains advisory only; record changes require authorized human approval and a durable audit trail.
- Use **GPO (గ్రామ పాలన ఆఫీసర్)**, not VAO. GIS/OCR is not independent legal proof of ownership.


## v1.2 review correction

An empty policy object in development is not treated as configured. The health response reports `authorization-policy-missing`, and API routes fail closed with `AUTHORIZATION_POLICY_NOT_CONFIGURED` unless `RLA_AUTHZ_POLICY_JSON` was explicitly supplied. An explicit empty JSON object is syntactically configured but grants no permissions.

## Remaining runtime blockers

The SQLite dependency is not present in the current verification environment, so no live database/API integration test was executed. Before release, test concurrent writes on the single SQLite connection, rollback behavior, bootstrap/restart behavior, authorization policy semantics, and scoped audit requirements using an isolated test database. Static source-pattern tests do not establish these runtime properties.


## v1.3 policy hardening

An explicitly supplied authorization policy must define at least one role, every role must map to a non-empty list of explicit permissions, and wildcard `*` permissions are rejected. This is a conservative configuration guard, not a substitute for an approved role/permission matrix.


## v1.4 runtime suite authoring status — 2026-10-12

The following runtime suite has been authored but has **not been executed** because `npm install --no-audit --no-fund` timed out after 120 seconds in the verification environment:

- `tests/runtime/runtime-integration.test.js` — isolated temporary SQLite database; bootstrap and API creation; concurrent same-version transitions; jurisdiction read isolation; audit endpoint fail-closed behavior; injected audit insert failure and application rollback; restart without resupplying the bootstrap token.
- Run with `npm run test:runtime` after dependencies are installed.
- Static checks remain separate: `npm run test:static`.

The runtime suite is test code only, not evidence that the scenarios pass. Old-schema migration, maker-checker separation, user provisioning lifecycle, audit jurisdiction model implementation, penetration testing, UAT, legal/process approval, and the authoritative Revenue role matrix remain unresolved. Status remains `RUNTIME_TEST_SUITE_AUTHORED · RUNTIME_NOT_VERIFIED · RELEASE_BLOCKED`. Preserve the original v1.3 ZIP unchanged.
