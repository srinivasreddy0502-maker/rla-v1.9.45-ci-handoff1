# RLA v26 v1.9.32 Verification Report

**Status: RELEASE BLOCKED — NOT RELEASE**

## Change

Dependency lockfile preflight now rejects group/other-writable security-sensitive input files, group/other-writable candidate/config directories, and files with multiple hard links. The checks retain `O_NOFOLLOW`, bounded reads, before/after metadata comparisons, and fail-closed behavior.

## Automated checks

- Full configured offline workflow: **275 passed, 0 failed, 0 skipped** across **30** test summaries.
- Focused dependency lockfile preflight suite: **48 passed, 0 failed, 0 skipped**.
- JavaScript syntax: **67 files checked, 0 syntax errors**.
- Package-integrity manifest is generated and verified in the workspace and again after archive extraction; see the verification logs.
- ZIP integrity and SHA-256 are checked independently.

## Blocking evidence

- Dependency lockfile preflight: `PACKAGE_LOCK_JSON_MISSING`.
- Safe npm CI preflight: blocked; npm installation was not invoked.
- Acquisition planner: blocked because `RLA_APPROVED_NPM_REGISTRY` was not explicitly configured. No network test was performed and no lockfile was created.
- Native SQLite preflight: `NATIVE_SQLITE3_DRIVER_UNAVAILABLE`; no real native SQLite restore drill was completed.
- Independent security review, authorized penetration testing, recovery drills, UAT, audit-evidence review, and formal governance approval remain pending.

## Release decision

**RELEASE BLOCKED — NOT RELEASE.** No production use is authorized. Tests use synthetic fixtures only; do not test against real land records. Official record changes must remain subject to authorized human approval and maker-checker controls.
