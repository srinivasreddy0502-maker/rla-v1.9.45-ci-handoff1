# Native SQLite Restore-Drill Concurrency Lock — v1.9.22

## Change
The isolated native SQLite restore drill now acquires an exclusive, per-run lock file in the private evidence directory before opening the source database or writing backup artifacts.

- Lock creation uses exclusive-create (`wx`) and restrictive permissions (`0600`).
- A competing invocation with the same run ID fails closed.
- A pre-existing lock is treated as a possible active run or stale lock; the code does not auto-delete it.
- Lock metadata is flushed before the drill proceeds.
- Release only removes the same filesystem object created by this invocation, after checking device/inode identity.
- Regression tests cover concurrent acquisition, release, reacquisition, and stale-lock preservation.

## Operational note
A stale lock requires an operator to verify no process is active and then remove it under the approved staging procedure. This is a cooperative same-host concurrency guard, not a defense against a privileged process or a hostile actor with write access to the evidence directory. Keep that directory private and use a quiesced staging database. SQLite WAL/SHM sidecars remain a hard block.

## Scope and limitations
This change does not provide proof of a successful native SQLite restore drill. The native `sqlite3` driver is still unavailable in the current environment, and the package lockfile is still missing. No `npm ci`, real file backup/restore, production database operation, or release approval is claimed.
