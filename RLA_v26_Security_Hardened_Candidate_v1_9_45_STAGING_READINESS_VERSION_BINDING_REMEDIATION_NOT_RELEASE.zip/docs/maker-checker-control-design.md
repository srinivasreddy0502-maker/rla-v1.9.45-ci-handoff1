# RLA v26 — Maker–Checker Control Design (v1.4.5)

Status: IMPLEMENTED IN CANDIDATE v1.4.6 — NATIVE DRIVER / INDEPENDENT REVIEW STILL PENDING — NOT FOR RELEASE

## Objective
Ensure that official land-record mutations cannot be completed solely by the person who initiated the request, and that approval is explicit, attributable, jurisdiction-bound, and auditable.

## Required control model

1. **Separate request and decision records.** Store the request maker, requested operation, target record/version, evidence references, jurisdiction, created timestamp, and immutable request digest separately from approval decisions.
2. **Independent checker.** A checker must be a different authenticated principal from the maker. Compare immutable user IDs, never display names.
3. **Permission and jurisdiction.** Require a dedicated explicit permission such as `land_record:approve`; reject missing policy, missing jurisdiction, mismatched jurisdiction, inactive users, and unrecognized decision states by default.
4. **Version binding.** Approval must bind to the exact record version and request digest. If either changes after submission, invalidate the pending approval and require resubmission.
5. **Atomic application.** In one database transaction: verify pending status, maker/checker separation, jurisdiction, permission, version and digest; apply the approved change; append an audit event; mark the decision consumed. Any failure must roll back all writes.
6. **No self-approval via alternate routes.** Every endpoint and internal service that can change official land-record state must invoke the same domain-level approval guard. UI-only restrictions are insufficient.
7. **No silent override.** Emergency/override paths, if legally authorized, must be separate permissions, require a reason, create a high-severity audit event, and be periodically reviewed. Do not implement a bypass until the governing authority specifies it.
8. **Audit integrity.** Capture maker, checker, decision, jurisdiction, record/version, request digest, timestamps, reason, and correlation ID. Logs must not contain bearer tokens or unnecessary personal data.
9. **Idempotency and replay protection.** A decision identifier can be consumed once. Replays must not apply the mutation again.
10. **Legal workflow configuration.** Statutory role mapping and which state transitions require maker-checker must be approved by the competent Telangana authority before production.

## Required acceptance tests

- Maker cannot approve their own request, even through a direct API call.
- Different user without approval permission is denied.
- Authorized checker from another jurisdiction is denied.
- Checker cannot approve if record version or request digest changed.
- Concurrent duplicate approvals produce exactly one mutation and one consumed decision.
- Audit-write failure rolls back both the record mutation and approval consumption.
- Replayed approval cannot apply twice.
- Every mutation endpoint, including future endpoints, is covered by a domain-level guard test.
- Approval and rejection decisions are auditable; rejection does not mutate the official record.
- Disabled/revoked users cannot approve using stale credentials.

## Implementation boundary
Candidate v1.4.6 implements a separate `transition_requests` table, request-digest binding, maker/checker identity separation, dedicated `applications:transition_request` and `applications:approve_transition` permissions, jurisdiction checks, single-use decisions, stale-version handling, transactional state mutation + decision consumption + audit append, rejection without state mutation, and a `410 MAKER_CHECKER_REQUIRED` response on the legacy direct-transition route. Offline compatibility integration tests cover key behaviors. This is not yet production approval: the declared native `sqlite3` driver has not been verified in this environment, and the full acceptance matrix, independent security review, legal workflow approval, and UAT remain outstanding.
