# RLA v26 — Audit Checkpoint External Store v1.6.7

## Purpose

This candidate adds an application-level publisher and verifier for signed audit checkpoints. It copies a previously generated HMAC-signed checkpoint into a separately configured evidence-store directory, creates a receipt containing the checkpoint SHA-256 digest, signs that receipt with a separately managed store key, and verifies the receipt using a key-id-indexed keyring.

## API

- `publishCheckpoint({ checkpointPath, storageDir, checkpointId, storeKey, storeKeyId, now? })`
- `verifyStoredCheckpoint({ storageDir, checkpointId, storeKeys, checkpointKey, recordsDir })`
- `verifyReceipt(receipt, storeKey)`

Both the checkpoint and receipt are created exclusively (`wx`) and written with restrictive file permissions. Existing IDs cannot be overwritten. Symlink inputs and non-private storage directories are rejected. Verification checks the receipt HMAC, checkpoint digest, checkpoint HMAC, and current evidence-chain count/final digest.

## Key rotation

The receipt contains `storeKeyId`. During a rotation, retain old verification keys in `storeKeys` for existing receipts while using a new key ID for newly published receipts. Remove an old key only after retention and recovery policy permits it. This is an application-level verification keyring, not a managed KMS integration.

## Operational deployment requirements

- Configure `storageDir` on a genuinely separate, access-controlled storage boundary (prefer a separate host/account or immutable/WORM object store). Separate folders on the same writable disk are not independent protection against host compromise.
- Keep `storeKey` separate from `RLA_AUDIT_EVIDENCE_KEY`; do not commit either key or put it in logs. Use an approved secret manager/KMS in deployment.
- Run publication under a least-privilege service identity; grant readers verification-only access where the storage platform supports it.
- Monitor missing receipt/checkpoint pairs and failed verification; preserve partial writes for operator reconciliation rather than automatically deleting forensic evidence.
- Perform restore and retention drills against the actual target storage system.

## Scope and limitations

This module is not wired into the production audit append endpoint or backup scheduler. It does not provide cloud object-lock/WORM, remote replication, independent administrator separation, key custody/KMS, alert delivery, or deployment configuration. Local filesystem modes and exclusive creation are defense-in-depth only. A successful offline test does not prove these deployment properties.
