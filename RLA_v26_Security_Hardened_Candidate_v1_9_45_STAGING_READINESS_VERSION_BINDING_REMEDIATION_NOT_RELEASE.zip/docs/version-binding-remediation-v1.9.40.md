# v1.9.40 Candidate — Staging Evidence Version-Binding Remediation

Status: `RELEASE BLOCKED — NOT RELEASE`

## Finding
The v1.9.39 validator defaulted to `1.9.36-candidate`, causing evidence for the current candidate to be rejected as a version mismatch.

## Change
The validator now defaults the expected candidate version to the version in this candidate's `package.json`. Tests and the blank evidence-intake template use the same package-version source. The validator still never grants release authority; complete evidence remains pending independent verification.

## Required external validation
Approved isolated staging, registry approval, lockfile provenance, native SQLite runtime/recovery, independent security review, authorized penetration testing, UAT, and governance approval remain required.
