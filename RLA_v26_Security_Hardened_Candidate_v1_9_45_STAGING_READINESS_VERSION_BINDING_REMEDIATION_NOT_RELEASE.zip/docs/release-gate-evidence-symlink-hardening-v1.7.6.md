# RLA v26 v1.7.6 — Release-Gate Evidence Symlink Hardening

**Disposition: RELEASE BLOCKED — NOT RELEASE**

## Change summary

The release-gate evidence evaluator now opens the manifest and evidence artifacts without following symbolic links where the platform supports `O_NOFOLLOW`, verifies opened handles are regular files, and checks each evidence path component for symlinks before reading. This closes straightforward symlink substitution cases that could otherwise make a manifest appear to reference evidence inside the private evidence root while the file actually resides elsewhere.

The evaluator continues to require all eight release gates, valid reviewer/timestamp/approval metadata, and a matching SHA-256 digest. It continues to return `releaseAuthorityGranted: false` regardless of the evidence-completeness result.

## Added regression tests

- Evidence symlink rejected even when the symlink target has the expected digest.
- Symlinked intermediate evidence directory rejected.
- Symlinked manifest rejected.

## Verification

- `npm run test:all:offline`: 141 passed, 0 failed, 0 skipped across 23 test-runner summaries.
- Targeted release-gate evidence suite: 8 passed, 0 failed, 0 skipped.
- JavaScript syntax checks: all discovered `.js` files passed `node --check`.
- Native SQLite preflight: BLOCKED, exit code 2, `NATIVE_SQLITE3_DRIVER_UNAVAILABLE`.
- Native file-level backup/restore: NOT RUN.

## Security limitations

- This is evidence-file hardening, not a substitute for independent evidence review, access control at the host/filesystem level, or a target-host security assessment.
- `O_NOFOLLOW` behavior is platform-dependent; the evaluator should be exercised on the actual target host. Evidence root must remain private (mode 0700 on POSIX).
- The native SQLite driver is unavailable in this environment, so no real backup/restore, WAL/crash-recovery drill, or production-host recovery claim is made.

## Required release gates remain open

1. Native SQLite backup/restore and integrity validation on target-like staging.
2. WAL/crash recovery restore drill and independent verification.
3. Production audit-workflow integration and independent WORM storage verification.
4. Independent security review and penetration test.
5. UAT and formal release approval.

No production database was changed. Do not use this candidate for production deployment.
