# Staging Evidence Intake Strict Schema Hardening — v1.9.35

## Change

- Rejects invalid UTF-8 in evidence JSON rather than silently replacing malformed byte sequences.
- Enforces explicit allowlists for root and nested schema fields, so unrecognized fields cannot imply approval or alter interpretation without a schema revision.
- Binds the default expected candidate version to `1.9.35-candidate`.
- Preserves the rule that evidence intake never grants release authority.

## Validation

- Focused staging-evidence intake tests: 11 passed, 0 failed, 0 skipped.
- Full configured offline workflow: 286 passed, 0 failed, 0 skipped across 31 test summaries.
- JavaScript syntax: 70 files checked, 0 errors.

## Limits

Schema and UTF-8 validation do not authenticate reviewer identity, prove that referenced artifacts are genuine, validate a digital signature, or replace independent review. SHA-256 digests provide integrity comparison only when the trusted expected digest is obtained separately.

## Release status

**RELEASE BLOCKED — NOT RELEASE.** No network test or dependency installation was performed. No lockfile was created. Native SQLite recovery drills, independent security review, authorized penetration testing, UAT, audit review, and formal governance approval remain pending.
