# Audit Evidence Chain — v1.6.4

This standalone utility creates HMAC-authenticated audit evidence records with SHA-256 digests of referenced evidence files and a previous-record digest chain. The read-only verifier checks record HMACs, contiguous sequence numbers, chain linkage, and referenced file hashes.

## Environment

Provide `RLA_AUDIT_EVIDENCE_KEY` from an approved external secret manager. Never store it in source control, a ZIP, or logs. Use at least 32 UTF-8 bytes. Test keys are not production keys.

## Verification CLI

`RLA_AUDIT_EVIDENCE_KEY=<external-secret> node scripts/verify-audit-evidence-chain.js <records-dir> <evidence-root>`

Records must be named `record-000001.json`, `record-000002.json`, and so on. This CLI is read-only.

## Security limits

This utility is not yet wired into the production audit service, scheduler, backup/restore process, or land-record transaction pipeline. HMAC and a hash chain detect unauthorized changes only while the key remains protected; an administrator with write access to the whole chain and the signing key could rewrite it. For stronger evidence retention, integrate signed records with a separately administered append-only/WORM store and trusted key management. Never treat a hash chain as proof that the event descriptions themselves are true.
