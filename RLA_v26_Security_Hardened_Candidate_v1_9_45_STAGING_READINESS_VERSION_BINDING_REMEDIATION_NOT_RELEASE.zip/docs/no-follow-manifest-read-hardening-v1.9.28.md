# RLA v26 — No-Follow Manifest Read Hardening v1.9.28

## Scope

The dependency lockfile acquisition planner previously checked `package.json` with `lstat` and then separately read the pathname. That sequence leaves a time-of-check/time-of-use window in which a pathname could be replaced between the check and read.

## Change

- Added descriptor-based manifest reading with `O_NOFOLLOW`.
- The opened descriptor is checked with `fstat` to ensure it refers to a regular file.
- File identity, size, modification timestamp, and byte length are checked again after reading; unexpected change blocks the plan.
- The reader fails closed on platforms where `O_NOFOLLOW` is unavailable rather than silently falling back to a pathname read.
- Added tests for successful descriptor-based reading and direct symlink rejection.

## Validation

- Acquisition planner tests: 10/10 passed.
- Full offline workflow: 263 passed, 0 failed, 0 skipped across 30 test summaries.
- JavaScript syntax check: 66 files, 0 failures.
- Dependency lockfile preflight: blocked because `package-lock.json` is missing.
- Native SQLite preflight: blocked because the native `sqlite3` driver is unavailable.
- Safe npm CI preflight: blocked; npm installation was not executed.

## Limitations

This reduces the `package.json` symlink-swap window on supported platforms. It does not constitute a full filesystem sandbox, does not eliminate every possible concurrent-writer condition, and does not prove registry/package provenance or release readiness. The acquisition planner remains plan-only; it does not perform network access or create a lockfile.
