# RLA v26 v1.9.30 — Dependency Lockfile Preflight Directory-Boundary Hardening

## Scope

The dependency lockfile preflight now rejects a candidate root directory or `config` directory that is itself a symbolic link or is not a real directory. This complements the existing no-follow regular-file reads for `package.json`, `package-lock.json`, and `config/dependency-install-script-policy.json`.

## Fail-closed results

- Candidate root is missing, not a directory, or a symbolic link: `ROOT_DIRECTORY_PATH_UNSAFE`.
- `config` is missing, not a directory, or a symbolic link: `INSTALL_SCRIPT_POLICY_DIRECTORY_UNSAFE`.
- File-level no-follow and identity checks remain in place.

## Limitations

Node.js filesystem APIs do not provide a portable `openat`-style directory-descriptor traversal here. This change checks the named root and `config` directory with `lstat`, but does not claim to eliminate every race on ancestor path components or concurrent directory replacement. Run the preflight in a controlled, non-writable staging workspace and obtain independent review before install.

## Safety

No network request was made, no lockfile was created, and `npm ci` was not executed. The package remains a candidate only; this change does not grant release or production authority.
