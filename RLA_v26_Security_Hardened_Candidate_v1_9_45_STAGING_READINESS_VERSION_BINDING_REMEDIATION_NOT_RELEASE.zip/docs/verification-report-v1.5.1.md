# RLA v26 v1.5.1 — Startup Lock-Retry Verification Report

**Release status: NOT RELEASE / RELEASE_BLOCKED**

## Why this patch was required

Re-running the complete offline suite against v1.5.0 exposed an intermittent first-start race: one of two processes could exit during `PRAGMA journal_mode=WAL` or transaction startup with `database is locked`. The previous candidate's bootstrap pass was therefore not reliable in repeated execution. This is recorded as a discovered defect, not hidden.

## Change

- Added bounded startup retry for SQLite transient lock errors (`SQLITE_BUSY`, `SQLITE_LOCKED`, and corresponding lock/busy messages).
- Retry is limited to initialization; non-lock errors still fail closed.
- Exponential backoff starts at 25 ms and is capped at 500 ms, up to 8 total attempts.
- No retry is applied to arbitrary application writes or authorization failures.
- Native npm `sqlite3` dependency was not replaced; the test-only compatibility adapter remains test-only.

## Verification performed in this environment

| Check | Result |
|---|---:|
| Static security tests | 14/14 PASS |
| Offline runtime integration tests | 12/12 PASS |
| Two-process concurrent write smoke test | PASS |
| Concurrent fresh-database bootstrap test | PASS; repeated 5/5 additional runs |
| Full `npm run test:all:offline` after patch | PASS |
| JavaScript syntax checks | 5/5 PASS |
| ZIP integrity | PASS (computed after packaging) |
| Native npm `sqlite3` driver | NOT VERIFIED |

The tests use Node.js v22 `node:sqlite` through a test-only adapter. This is not equivalent to validation with the production `sqlite3` npm package. The retry logic was tested against the observed bootstrap race in this environment, but must still be validated with the native driver and the target deployment filesystem.

## Remaining release gates

1. Run all tests with the native `sqlite3` package in an approved network-enabled or internal-mirror build environment.
2. Test migration failure rollback, busy timeout under sustained contention, backup/restore, WAL checkpointing, crash recovery, and filesystem permissions.
3. Validate user provisioning/revocation and token lifecycle.
4. Complete independent security review, penetration testing, official workflow/role mapping approval, UAT, and deployment sign-off.

**Decision:** `STARTUP_LOCK_RETRY_OFFLINE_PASS · NATIVE_SQLITE3_NOT_VERIFIED · RELEASE_BLOCKED`.

The original v1.3–v1.5.0 ZIP files remain unchanged. RLA Master Repository remains `NOT_VERIFIED` until evidence is reviewed and accepted. GPO (గ్రామ పాలన ఆఫీసర్) role naming, jurisdiction isolation, human approval for official land-record changes, and audit trail requirements remain in force.
