# Release-Gate Review Freshness — v1.8.1

## Change

- Release-gate review timestamps remain canonical UTC timestamps with second precision.
- A review older than the explicit 90-day freshness window is blocked with `EVIDENCE_REVIEW_STALE`.
- Future-dated review evidence is blocked with `EVIDENCE_REVIEW_TIMESTAMP_FUTURE`.
- The freshness window is a candidate baseline policy and must be approved or changed by the responsible governance owner before adoption in a formal environment.
- Freshness validation does not prove reviewer identity, approval authenticity, trusted time, or evidence provenance.
- The evaluator still always returns `releaseAuthorityGranted: false`.

## Tests

- Stale review evidence is blocked.
- Review evidence within the 90-day boundary is accepted by the timestamp validator.
- Existing timestamp, path, permissions, hard-link, digest, schema, and fail-closed tests remain in place.

## Limitations

The validator depends on the host clock and the policy constant. Trusted time, identity, immutable audit/WORM anchoring, native SQLite restore, independent security review, penetration testing, UAT, and formal release approval remain separate requirements.
