# Audit Record Read Hardening — v1.9.38

## Change

When the append workflow reads existing `record-NNNNNN.json` files to verify the audit chain, it now opens each record with `O_NOFOLLOW` and fails closed when the runtime does not provide that flag. It validates the opened descriptor is a regular file, enforces a 1 MiB per-record bound before reading, and checks descriptor size before and after the read. The parsed record remains subject to the existing HMAC and chain-link verification.

## Threats addressed

- Symlink substitution for a previously existing audit record.
- Unbounded audit-record reads that could consume excessive memory before JSON parsing.
- Runtime/platform without no-follow open support silently following a final-component symlink.

## Tests

Synthetic temporary-directory tests verify append still works for valid chains, a symlink substituted for an existing record is rejected, and an oversized record is rejected before parsing. No production data or real land records are used.

## Limits

This is defense in depth, not proof against every filesystem race or malicious privileged host. The records directory must remain private and controlled; HMAC key custody, independent audit review, staging verification, and formal release approval remain external governance requirements.

## Release status

`RELEASE BLOCKED — NOT RELEASE`. No dependency installation or network access is performed by this change.
