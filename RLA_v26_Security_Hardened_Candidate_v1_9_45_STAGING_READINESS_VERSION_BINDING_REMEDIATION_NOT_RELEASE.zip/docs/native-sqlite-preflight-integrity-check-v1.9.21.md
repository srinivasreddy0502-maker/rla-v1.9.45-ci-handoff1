# RLA v26 — Native SQLite Preflight Integrity-Check Hardening v1.9.21

Status: `CANDIDATE_ONLY — RELEASE BLOCKED — NOT RELEASE`

## Finding

The native SQLite driver smoke preflight executed `PRAGMA integrity_check` but ignored its returned row. That meant the smoke test could continue even if SQLite returned an integrity error row. The separate restore-drill implementation already enforced `integrity_check === 'ok'`; the preflight did not.

## Change

- The preflight now requires a row whose `integrity_check` value is exactly the string `ok`.
- Missing rows, malformed rows, and error results fail closed.
- The emitted check list explicitly records `integrity-check-ok`.
- The validation helper is exported for isolated unit tests; normal command-line behavior remains unchanged.
- Added three offline tests covering the success case, a reported integrity error, and missing/malformed rows.

## Verification

- Focused native SQLite preflight helper tests: 3 passed, 0 failed, 0 skipped.
- Full offline suite: 247 passed, 0 failed, 0 skipped.
- Dependency lockfile tests: 35 passed, 0 failed, 0 skipped.
- JavaScript syntax checks: PASS.
- Native SQLite driver preflight remains BLOCKED because the real native `sqlite3` driver is unavailable. The new tests validate the fail-closed decision logic; they do not claim a real database integrity/recovery drill occurred.

## Release impact

This fix strengthens the smoke preflight but does not clear the release gate. `package-lock.json` remains absent, `npm ci` was not run, real SQLite backup/restore and crash recovery remain unverified, and independent security review, authorized penetration testing, UAT, audit-evidence review, and formal governance approval remain pending. Production use and official land-record mutation remain unauthorized.
