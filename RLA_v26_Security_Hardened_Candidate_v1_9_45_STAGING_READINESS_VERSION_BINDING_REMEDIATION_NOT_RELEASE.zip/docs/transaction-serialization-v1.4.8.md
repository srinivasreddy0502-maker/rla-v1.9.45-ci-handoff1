# RLA v26 — Transaction Serialization Hardening v1.4.8

Status: CANDIDATE IMPLEMENTATION; NOT FOR RELEASE

## Change
The server uses one SQLite connection. Transaction lifecycles are now serialized through a promise queue so overlapping HTTP requests cannot interleave `BEGIN IMMEDIATE`, transaction statements, `COMMIT`, and `ROLLBACK` on that connection. The queue releases in `finally` and remains usable after transaction errors.

## Regression coverage
- 12 concurrent application-creation requests must all return HTTP 201.
- All created application IDs must be unique.
- Existing concurrent duplicate approval, maker-checker, stale-request, rollback, jurisdiction-scope, migration, and restart tests remain in the suite.

## Limits
- Tests are run through the test-only adapter backed by Node.js built-in `node:sqlite`; native npm `sqlite3` remains unverified.
- This queue serializes transaction lifecycles only. A production multi-process deployment needs a reviewed database/concurrency design and must not rely on an in-process queue as a cross-process lock.
- Independent security review, penetration test, deployment configuration review, UAT and official workflow approval remain required.

Release decision: BLOCKED.
