# RLA v26 — v1.4.4 Security Candidate / NOT FOR RELEASE

Date: 2026-10-12

## Purpose

This candidate advances the v1.4.3 offline test work by implementing jurisdiction-scoped audit events and reads, plus an acceptance test for migrating a legacy audit table that does not contain a jurisdiction column.

## Changes

- Add nullable `jurisdiction` column to the audit table for new databases.
- Add an idempotent migration that adds the audit jurisdiction column to existing databases.
- Add an index on `(jurisdiction, created_at)` for scoped audit reads.
- Require a non-empty jurisdiction when writing new audit events.
- Stamp application creation and workflow transition audit events with the authenticated user's jurisdiction.
- Implement `GET /api/audit` as a permission-checked, jurisdiction-filtered query limited to the latest 500 rows.
- Preserve fail-closed behavior for legacy audit rows whose jurisdiction cannot be safely inferred: rows remain `NULL` and are not exposed by the scoped endpoint. They require a separately governed reconciliation process if historical visibility is needed.
- Add test coverage for cross-jurisdiction audit isolation and legacy-schema migration.

## Executed results

- JavaScript syntax checks: PASS for `app/server.js`, `tests/security-candidate.test.js`, `tests/runtime/runtime-integration.test.js`, and `tests/runtime/run-offline-adapter.js`.
- Static security tests: 14/14 PASS, 0 failures.
- Offline integration tests: 7/7 PASS, 0 failures using a test-only adapter backed by Node.js built-in `node:sqlite`.
- Covered: health/authenticated creation, missing-token rejection, same-version concurrent transitions (one success and one conflict), jurisdiction-scoped application reads, jurisdiction-scoped audit reads, audit-failure rollback, bootstrap restart, and legacy audit-schema migration without exposing unscoped historical rows.

## Important limitations

- The offline adapter is test-only and is not the declared native `sqlite3` npm driver. Native-driver installation and equivalent tests remain NOT VERIFIED because npm registry DNS/network resolution previously returned `EAI_AGAIN`.
- Node.js emitted an ExperimentalWarning for built-in `node:sqlite`.
- The legacy migration intentionally does not guess jurisdiction for historical audit rows. A controlled reconciliation process is needed before those records can be surfaced by jurisdiction.
- Maker-checker enforcement, user provisioning lifecycle, evidence storage/integrity workflows, identity-provider integration, production deployment hardening, independent security review, penetration testing, UAT, and official approval remain outstanding.
- No real land-record data should be used, and this candidate must not be deployed to production.

## Release decision

`STATIC_TESTS_PASS · OFFLINE_SQLITE_COMPAT_RUNTIME_PASS · NATIVE_SQLITE3_NOT_VERIFIED · MAKER_CHECKER_NOT_VERIFIED · RELEASE_BLOCKED`

Keep GPO (గ్రామ పాలన ఆఫీసర్) role naming, jurisdiction controls, authorized human approval for official land-record changes, and audit trail requirements.
