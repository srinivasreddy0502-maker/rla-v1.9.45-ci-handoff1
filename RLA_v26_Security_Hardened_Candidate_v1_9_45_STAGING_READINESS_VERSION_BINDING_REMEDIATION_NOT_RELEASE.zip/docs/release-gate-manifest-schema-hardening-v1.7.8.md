# Release-Gate Manifest Schema Hardening — v1.7.8

## Change

The release-gate evidence evaluator now rejects any gate ID that is not in the fixed `REQUIRED_GATES` allowlist. Previously, unknown entries were accepted into the parsed map but ignored by the fixed required-gate evaluation loop. The evaluator already rejected duplicate IDs; a regression test now locks that behavior down as well.

## Security rationale

Strict allowlisting avoids ambiguous manifests where a reviewer or automation believes an extra gate was evaluated even though the evaluator does not consider it. Unknown or duplicate IDs fail the manifest evaluation instead of being silently ignored.

## Scope and limitations

This is manifest-schema hardening only. It does not attest that supplied evidence is truthful, does not provide cryptographic reviewer identity, does not eliminate filesystem TOCTOU races, and does not grant release authority. The evaluator must continue to report `RELEASE_BLOCKED` until the separately required native SQLite backup/restore, WAL/crash recovery, audit/WORM, independent security review, penetration testing, UAT, and formal approval gates are completed.
