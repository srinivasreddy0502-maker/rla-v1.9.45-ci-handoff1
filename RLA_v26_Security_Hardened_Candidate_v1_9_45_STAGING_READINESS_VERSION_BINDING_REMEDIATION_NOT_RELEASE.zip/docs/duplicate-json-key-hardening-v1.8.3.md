# Release-Gate Manifest Duplicate JSON Key Hardening — v1.8.3

## Risk
Many default JSON parsers accept duplicate object keys and silently keep the last value. That can create different interpretations of the same release-evidence manifest across tools and reviewers.

## Change
- Add a strict JSON reader for the release-gate manifest that rejects duplicate keys at every object depth.
- Decode byte input as UTF-8 with fatal error handling.
- Recognize only JSON-defined whitespace characters.
- Keep the existing 1 MiB manifest limit and all fail-closed gate behavior.
- Add regression tests for duplicate top-level schema keys and duplicate nested `gateId` keys.

## Limits
This is a targeted manifest parser, not a general-purpose JSON library. It does not prove evidence authenticity, reviewer identity, host integrity, or eliminate filesystem races. Review the parser independently before production use.
