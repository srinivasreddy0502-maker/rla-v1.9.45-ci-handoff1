# Release-Gate Manifest Unicode Scalar Hardening — v1.8.7

## Change

The strict release-gate manifest parser now rejects JSON strings (including object keys) that decode to unpaired UTF-16 surrogate code units. This avoids ambiguous handling of escaped invalid Unicode across downstream serializers, logs, and review tools. Valid surrogate pairs remain accepted.

## Error

`RLA_JSON_LONE_SURROGATE`

## Scope and limitations

This control supplements, but does not replace, strict UTF-8 byte decoding, BOM rejection, duplicate-key detection, the 1 MiB manifest size cap, the 64-level nesting cap, or the 25,000-node cap. It does not establish reviewer identity or grant release authority. Independent parser review remains required.
