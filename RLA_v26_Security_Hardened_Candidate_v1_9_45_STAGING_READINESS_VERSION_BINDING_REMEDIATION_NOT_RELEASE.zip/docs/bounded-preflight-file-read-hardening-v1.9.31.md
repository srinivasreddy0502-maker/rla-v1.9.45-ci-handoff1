# RLA v26 v1.9.31 — Bounded Preflight File Reads

## Purpose

Bound memory and parsing exposure while inspecting dependency acquisition inputs. Prior versions used `readFileSync(fd)` after checking metadata; if a regular file grew during a read, that API could consume more data than the initial `fstat` size suggested.

## Change

- Replaced unbounded whole-file reads in the dependency lockfile preflight helper with a fixed-size chunk loop and a hard byte ceiling.
- Re-checks descriptor identity and metadata after reading; rejects changed or size-inconsistent content.
- `package.json` is capped at 1 MiB (`PACKAGE_JSON_TOO_LARGE`).
- `config/dependency-install-script-policy.json` is capped at 1 MiB (`INSTALL_SCRIPT_POLICY_TOO_LARGE`).
- `package-lock.json` is capped at 32 MiB (`PACKAGE_LOCK_JSON_TOO_LARGE`).
- The reader reads at most one byte beyond its configured ceiling to detect growth, then fails closed without JSON parsing.
- Added regression tests for each oversize input. Test fixtures are synthetic; no land records are used.

## Limitations

The limits are intentionally conservative and may need formal adjustment if the reviewed dependency graph legitimately requires a larger lockfile. Any limit change should be reviewed, tested, and recorded. This hardening does not create a lockfile, access the network, run `npm ci`, or authorize production use.
