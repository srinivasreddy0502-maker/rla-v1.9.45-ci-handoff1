# RLA v26 — Controlled Native SQLite Restore Drill Runbook (v1.7.5 candidate)

## Purpose and scope

This runbook defines the evidence required to turn the native SQLite restore drill from an offline-tested harness into a verified target-environment exercise. A successful dependency smoke test is **not** a successful restore drill, and neither is release approval.

## Preconditions (all required)

1. Use an isolated staging host that matches the intended production OS, architecture, Node.js major/minor, filesystem semantics, and deployment identity.
2. Record the candidate ZIP SHA-256 and ensure the extracted source is read-only for the operator running the drill.
3. Use a representative, non-production database or an approved sanitized copy. Never run this drill against the live official land-record database.
4. Stop/quiesce all writers and scheduled jobs for the source, or use an independently reviewed SQLite online-backup workflow that explicitly supports WAL mode. The current candidate deliberately blocks when `-wal` or `-shm` sidecars are present; do not delete sidecars to bypass the gate.
5. Create a dedicated evidence directory with mode `0700` on POSIX systems. Use a unique run ID; never reuse an evidence run ID or overwrite prior evidence.
6. Install dependencies from the approved lockfile using the organization's approved package mirror and integrity controls. Do not disable TLS, signature, or integrity checks to make installation succeed.

## Ordered execution

1. Capture `node --version`, `npm --version`, OS/architecture, package-lock hash, candidate ZIP hash, and the exact install command/result.
2. Run `npm run preflight:native-sqlite`. Accept only `DRIVER_SMOKE_PASS` as proof of module load, in-memory open/close, SQLite version query, and backup API presence. A `BLOCKED` result means stop and attach the complete JSON diagnostic.
3. Run `npm run test:native-sqlite-restore-drill:offline` and the complete `npm run test:all:offline` suite. Save stdout, stderr, exit codes, and test-runner summaries. These offline tests do not replace the native drill.
4. On an approved sanitized fixture, invoke the exported `runNativeRestoreDrill` function with a unique run ID and a private evidence directory. Keep the fixture outside the evidence directory. Capture the returned manifest and all artifact hashes.
5. Independently verify the backup and restored copies on a clean process: `PRAGMA integrity_check`, `PRAGMA foreign_key_check`, expected table inventory, and approved row-count / domain-specific invariants. Do not rely solely on hashes and table names.
6. Test a second restore into a fresh isolated directory, and perform a documented recovery drill including interruption/failure handling. Confirm that partial artifacts are quarantined and never treated as PASS evidence.
7. Have a second reviewer verify source/backup/restored hashes, logs, test exit codes, evidence directory permissions, run ID uniqueness, and the release-gate record.

## Required evidence bundle

- Candidate ZIP SHA-256 and dependency lockfile SHA-256.
- Host/runtime attestation and native preflight JSON.
- Install logs and all offline test logs with exit codes.
- Native drill manifest, backup/restored artifact hashes, integrity and foreign-key checks, table inventory, and approved data invariants.
- Failure/recovery observations, reviewer identity, UTC timestamps, deviations, and signed approval record.

## Fail-closed rules

Mark the drill `BLOCKED` if the driver cannot load; `Database#backup` is unavailable; any unexpected WAL/SHM sidecar exists under this candidate's current policy; the source changes during the drill; any integrity/FK check fails; hashes or table inventories differ; evidence is incomplete; output collisions exist; or any test command exits non-zero. Never convert missing evidence into PASS.

## Release decision

Until a native file-level restore drill and target-host recovery test have actually passed, plus independent security review, penetration testing, UAT, and formal authorization, the release status remains **RELEASE BLOCKED — NOT RELEASE**. This candidate does not alter or replace official land records. Official record changes must remain subject to authorized human approval, jurisdiction isolation, role-based access control, and auditable change history.
