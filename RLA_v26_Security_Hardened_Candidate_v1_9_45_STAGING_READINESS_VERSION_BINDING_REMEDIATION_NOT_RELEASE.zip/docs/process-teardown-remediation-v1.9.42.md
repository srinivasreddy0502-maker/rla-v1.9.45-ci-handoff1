# RLA v26 v1.9.42 — Test Child-Process Teardown Remediation

Status: remediation candidate; not a release authorization.

## Change

- Centralized child-process teardown in `tests/runtime/test-support/stop-child.js`.
- Registers exit observation before sending a signal to reduce exit-event race windows.
- Requests SIGTERM, waits for the child `exit` event or confirmed exit state, then uses SIGKILL only after the grace timeout.
- Waits again after forced termination and throws if exit is not observed.
- Removes the former short fixed-delay cleanup from `migration-rollback.test.js` and uses the shared teardown helper.
- Adds unit tests for no-child input, graceful termination, forced termination, already-exited children, and invalid timeout configuration.
- Extends the concurrent-bootstrap stress probe readiness deadline to a bounded 30 seconds to accommodate transient contention under a full offline suite; a timeout still fails the test.

## Validation scope

Unit and offline test results validate the test harness in this runtime. Offline SQLite tests use the test-only `node:sqlite` adapter and do not establish that the native npm `sqlite3` dependency is installed or that production recovery is verified.

## Release blockers retained

- `package-lock.json` is not present; approved registry/provenance evidence is missing.
- Native `sqlite3` runtime integration and true backup/restore/recovery still require authorized isolated staging.
- Independent security review, authorized penetration testing, UAT, and governance approval remain pending.

No production authorization is granted. Do not use real land records in tests.
