# RLA v26 Security-Hardened Candidate v1.8.6 — Verification Report

**Status: RELEASE BLOCKED — NOT RELEASE**

## Change summary

- Reject UTF-8 BOM bytes at the start of release-gate manifests.
- Reject U+FEFF at the beginning of string input to the strict manifest parser.
- Added two regression tests covering raw UTF-8 BOM and string-leading BOM.
- Existing duplicate-key rejection, strict UTF-8 decoding, JSON whitespace validation, 1 MiB manifest size limit, 64-level nesting limit, 25,000-node limit, timestamp freshness checks, evidence digest checks, symlink checks, hard-link checks, and POSIX private-permission checks remain in place.

## Verification results

- Offline test suite: **159 passed, 0 failed, 0 skipped** across **26 test-runner summaries**.
- Release-gate focused suite: **26 passed, 0 failed, 0 skipped**.
- JavaScript syntax checks: **PASS** for all JavaScript files under `app/`, `scripts/`, and `tests/`.
- ZIP integrity: **PASS**; 237 entries, no corrupt members in archive integrity check.
- Native SQLite preflight: **BLOCKED**, exit code 2, `NATIVE_SQLITE3_DRIVER_UNAVAILABLE`.
- Real native SQLite backup/restore: **NOT RUN**.

## Limitations and release blockers

The current environment does not have the native `sqlite3` driver available. Therefore these checks do not demonstrate real SQLite backup/restore, WAL/crash recovery, target-host recovery, or native database integrity. The BOM control is a parser-hardening measure, not proof of evidence authenticity or reviewer identity. Independent parser/security review, penetration testing, UAT, audit/WORM evidence validation, target-like staging restore drills, and formal release approval remain required.

Do not deploy this candidate to production. Preserve previous ZIPs unchanged and continue to fail closed until all release gates are independently evidenced and approved.
