# RLA v26 v1.9.14 — Safe npm TLS and Launcher Hardening

## Scope

This candidate strengthens the dependency-installation wrapper. It does not authorize a release or claim a successful `npm ci` run.

## Changes

- Strip inherited `NODE_TLS_REJECT_UNAUTHORIZED`, `NODE_EXTRA_CA_CERTS`, and `NODE_USE_ENV_PROXY` from the child environment. If an organization requires a custom CA or proxy, configure and review it through the staging host's managed trust/proxy configuration rather than inheriting an arbitrary per-process override.
- Force `npm_config_strict_ssl=true` in the child environment and report `tlsVerificationEnforced: true`.
- Do not execute the inherited `npm_execpath` value as a Node.js script. On POSIX, invoke `npm` by command name using the CI runner's trusted `PATH` with `shell: false`. On Windows, fail closed until a reviewed native launcher is supplied; do not fall back to a shell-based `.cmd` invocation.
- Add regression tests for TLS-bypass environment variables and the reported TLS state.

## Operational assumptions and limitations

The CI runner's `PATH` remains a trusted input and must be controlled by the runner configuration. This wrapper does not provide a complete OS-level sandbox. Lockfile and registry checks remain mandatory. The current workspace has no `package-lock.json`, so the preflight blocks before npm is invoked. Native SQLite installation and runtime validation have not been performed.

## Release gate

`RELEASE_BLOCKED`. Do not deploy this candidate to production or use it to mutate official land records. A reviewed lockfile, successful staging install, native SQLite checks, backup/restore and WAL recovery drills, independent security review, penetration testing, UAT, and formal approval remain required.
