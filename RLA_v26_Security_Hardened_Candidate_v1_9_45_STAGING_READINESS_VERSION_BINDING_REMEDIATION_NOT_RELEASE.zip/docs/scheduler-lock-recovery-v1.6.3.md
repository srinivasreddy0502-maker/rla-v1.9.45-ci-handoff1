# Scheduler Lock Recovery Authorization — v1.6.3

This feature creates a tamper-evident, HMAC-authenticated **authorization evidence record** for human-reviewed scheduler-lock recovery. It does not remove, rename, reclaim, or otherwise mutate a scheduler lock.

## Required controls

- A private output directory (POSIX mode 0700) and a new output filename.
- `RLA_SCHEDULER_RECOVERY_AUDIT_KEY` supplied from an approved secret manager; at least 32 UTF-8 bytes. Never place it in source control, the ZIP, or logs.
- Separate operator and independent approver identifiers.
- Incident/change reference and reason.
- All five attestations: service stopped, all writers stopped, process identity checked, backup before recovery verified, and change window approved.
- Current lock inspection is captured in the record; its token is never included.
- Output is created exclusively with mode 0600 and an HMAC-SHA256 integrity tag.

## CLI

Set the following environment values through the approved operational secret/configuration mechanism, then run:

`node scripts/authorize-scheduler-lock-recovery.js <existing-lock-path> <new-private-output.json>`

Required variables: `RLA_SCHEDULER_RECOVERY_AUDIT_KEY`, `RLA_RECOVERY_OPERATOR_ID`, `RLA_RECOVERY_APPROVER_ID`, `RLA_RECOVERY_INCIDENT_REF`, `RLA_RECOVERY_REASON`, and `RLA_RECOVERY_ATTESTATIONS` (JSON object with all required attestations set to `true`).

## Safety boundary

The record is evidence for a human-controlled recovery process, not proof by itself that the attestations are true and not a command to remove the lock. PID existence is not owner identity. A reviewer must independently verify the service/process state, preserve evidence, and follow the approved recovery runbook. Automated stale-lock deletion remains prohibited.

The HMAC key provides integrity only while protected. Key custody, rotation, independent audit-log storage, target-host filesystem behavior, and the operational recovery procedure must be approved before production use.
