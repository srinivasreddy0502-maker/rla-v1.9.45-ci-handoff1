# RLA v26 v1.9.15 — Safe npm Preflight Execution Guard

## Purpose

Add a process-level regression test proving the safe dependency wrapper does not execute `npm` when dependency-lockfile preflight is blocked.

## Test behavior

- Creates a temporary fake `npm` executable that writes a sentinel if invoked.
- Runs the actual `scripts/safe-npm-ci.js` wrapper with a controlled temporary `PATH` and an inherited `npm_execpath` pointing at that fake executable.
- Confirms the wrapper exits with code `2`, reports `PACKAGE_LOCK_JSON_MISSING`, and leaves the sentinel absent.
- Removes the temporary test directory in a `finally` block.
- The test is skipped on Windows because the current wrapper intentionally fails closed there pending a reviewed native launcher.

## Security boundary

This test proves the current missing-lockfile path blocks before npm execution. It does not prove the lockfile is trustworthy, prove npm supply-chain integrity, create a lockfile, execute `npm ci`, validate native SQLite, or authorize production use. The POSIX CI runner `PATH` must still be controlled and reviewed.

## Release decision

`RELEASE_BLOCKED — NOT RELEASE`. Official land records and production deployment remain out of scope until all required independent reviews and runtime/recovery checks pass.
