# RLA v26 — Audit Checkpoint Workflow v1.6.8 (NOT RELEASE)

## Change summary

This candidate adds controlled application-level orchestration around the v1.6.7 checkpoint and store primitives:

- `healthCheckEvidenceStore(storageDir)` creates a unique exclusive probe, writes and fsyncs it, checks it is a regular file, and removes it on the successful path. On failure it reports the probe path for operator inspection instead of silently hiding a storage issue.
- `checkpointAndPublish(...)` verifies the audit chain while creating a signed checkpoint in a distinct private staging directory, then publishes it to the separately configured evidence store. It never deletes staged evidence when publication fails.
- `inspectCheckpointStore(storageDir)` is a read-only inventory that flags checkpoint-only and receipt-only states for manual reconciliation; it never repairs or deletes evidence.
- `verifyPublishedCheckpoint(...)` exposes the existing store/chain verification through the workflow module.

## API

- `healthCheckEvidenceStore(storageDir)`
- `checkpointAndPublish({ recordsDir, stagingDir, storageDir, checkpointId, auditKey, storeKey, storeKeyId, now? })`
- `inspectCheckpointStore(storageDir)`
- `verifyPublishedCheckpoint({ storageDir, checkpointId, storeKeys, checkpointKey, recordsDir })`

## Test evidence

- `npm run test:all:offline`: PASS; aggregate 115 tests passed, 0 failed, 0 skipped, 0 todo across 20 test-runner summaries.
- JavaScript syntax checks for all `app/**/*.js` and `tests/**/*.js`: PASS.
- Workflow-specific tests: 6/6 PASS (store health probe, end-to-end local orchestration and verification, no-overwrite behavior, checkpoint-only and receipt-only partial publication inventory, and same-directory rejection).
- ZIP integrity is separately recorded in the package verification report.

## Safety behavior

- No automatic deletion or repair of partial publication artifacts. A failed publish can leave a staged checkpoint and/or a checkpoint-only object in the store; operators must inspect and reconcile it under an approved procedure.
- The storage health check proves basic local write/fsync/unlink behavior only. It does not prove remote durability, replication, WORM/object-lock, independent administrative access, or disaster recovery.
- This module is not wired to the HTTP audit append endpoint or scheduler. It is a tested orchestration API, not a production deployment integration.

## Release gates still open

1. Install and verify the native `sqlite3` driver in a network-enabled, approved build environment; run real DB backup/restore, WAL and crash-recovery tests.
2. Run a target-host restore drill and validate recovery point/time objectives.
3. Integrate with production audit append and scheduler only after a reviewed operational design; define retries, alerting, key custody, access separation, and reconciliation ownership.
4. Validate a genuine independent/WORM storage boundary and test loss/partial-write recovery there.
5. Complete independent security review, penetration testing, jurisdiction-isolation tests, GPO role/permission review, UAT, and formal approval.

## Decision

`RELEASE BLOCKED`. Offline tests do not constitute production validation. Previous candidate archives must remain unchanged. Official land-record changes must retain authorized human approval and a complete audit trail.
