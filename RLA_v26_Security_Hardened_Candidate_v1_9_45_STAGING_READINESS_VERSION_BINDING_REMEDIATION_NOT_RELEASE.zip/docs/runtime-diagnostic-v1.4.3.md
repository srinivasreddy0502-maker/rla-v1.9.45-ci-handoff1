# RLA v26 — v1.4.3 Offline Runtime Diagnostic / NOT FOR RELEASE

Date: 2026-10-12

## Purpose

The network environment previously failed to resolve `registry.npmjs.org` (`EAI_AGAIN`), preventing installation of the declared native `sqlite3` dependency. Node.js v22.16.0 exposes the built-in `node:sqlite` module in this environment. This candidate adds a **test-only compatibility adapter** backed by `node:sqlite` so the existing API integration suite can exercise SQL and application behavior offline.

## Important distinction

This is an offline compatibility test, not a test with the declared native `sqlite3` npm package. The adapter lives only under `tests/runtime/test-support/node_modules/sqlite3`, is selected only by `npm run test:runtime:offline`, and is not a production replacement. `package.json` continues to declare `sqlite3` as the production dependency. Node emits an ExperimentalWarning for `node:sqlite` in Node.js v22.16.0.

## Executed results

- `node --check app/server.js`: PASS.
- `node --check tests/runtime/runtime-integration.test.js`: PASS.
- `node --check tests/runtime/run-offline-adapter.js`: PASS.
- `node --test tests/security-candidate.test.js`: PASS, 14 tests, 0 failures.
- `node tests/runtime/run-offline-adapter.js`: PASS, 6 tests including nested subtests, 0 failures.
- Runtime scenarios exercised: health and authenticated application creation; missing-token rejection; same-version concurrent transitions (exactly one succeeds); jurisdiction-scoped reads; audit endpoint fails closed; injected audit insert failure rolls back application creation; restart with existing bootstrap account without resupplying bootstrap token.

Raw logs are included in `docs/static-test-log-v1.4.3.txt` and `docs/runtime-test-log-v1.4.3-offline.txt`.

## Remaining limitations / release gates

- Native `sqlite3` dependency installation and tests against the actual declared npm package remain unverified due to registry/network restrictions.
- The adapter is not a substitute for production-driver verification and must not be used in production.
- Audit read endpoint intentionally returns `503 AUDIT_SCOPE_NOT_IMPLEMENTED` until jurisdiction-aware audit storage/querying is implemented.
- Old-schema migration requires dedicated runtime acceptance tests; maker-checker enforcement, user provisioning lifecycle, evidence storage, identity provider integration, production deployment hardening, independent security review, penetration testing, UAT, and official approval remain outstanding.
- Do not use real land-record data or deploy to production.

## Release decision

`STATIC_TESTS_PASS · OFFLINE_SQLITE_COMPAT_RUNTIME_PASS · NATIVE_SQLITE3_NOT_VERIFIED · RELEASE_BLOCKED`

Keep GPO (గ్రామ పాలన ఆఫీసర్) role naming, jurisdiction controls, human approval for official land-record changes, and audit trail requirements.
