# RLA v26 v1.5.5 — Authenticated Backup Manifest

Status: **CANDIDATE / NOT RELEASE**

## Added

- `app/backup-manifest.js`: streaming SHA-256 over a non-empty regular backup file; a versioned manifest containing artifact basename, size, digest, and creation time; HMAC-SHA-256 authentication using `RLA_BACKUP_MANIFEST_KEY`; constant-time HMAC/digest comparisons; private mode (`0600`) temporary manifest file; atomic rename for manifest publication.
- `scripts/backup-manifest.js`: `create` and `verify` CLI operations. It does not create a database backup; it authenticates/verifies an already-created backup artifact.
- `tests/runtime/backup-integrity.test.js`: intact artifact, mode, artifact tampering, manifest tampering, wrong key, weak key, and empty artifact cases.

## Usage

Set `RLA_BACKUP_MANIFEST_KEY` through an approved secret manager or protected runtime environment. The key must contain at least 32 UTF-8 bytes. Do not commit it to source control, embed it in ZIPs, write it to logs, or pass it as a command-line argument.

```sh
RLA_BACKUP_MANIFEST_KEY="$RLA_BACKUP_MANIFEST_KEY" node scripts/backup-manifest.js create /secure/backup.sqlite /secure/backup.manifest.json
RLA_BACKUP_MANIFEST_KEY="$RLA_BACKUP_MANIFEST_KEY" node scripts/backup-manifest.js verify /secure/backup.sqlite /secure/backup.manifest.json
```

Verification must run before a backup is restored. A successful manifest verification does not replace SQLite integrity checks, restore drills, authorization checks, encryption, off-site retention, or recovery objectives.

## Security limits

- The HMAC proves integrity/authenticity only while the HMAC key remains secret. An attacker who can replace both artifact and manifest and also obtain the key can forge a new pair.
- The utility is not yet wired into the application's production backup scheduler or restore endpoint.
- Key rotation, KMS/HSM integration, encrypted backups, retention, off-site copies, restore access control, and disaster recovery remain operational release gates.
- Tests use local temporary files and the current Node.js environment; native npm `sqlite3` runtime integration is still not verified.
