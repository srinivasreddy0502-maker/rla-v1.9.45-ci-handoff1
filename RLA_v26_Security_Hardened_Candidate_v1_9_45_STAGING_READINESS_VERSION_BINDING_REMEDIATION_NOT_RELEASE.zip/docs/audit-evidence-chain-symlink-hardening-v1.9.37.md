# RLA v26 — Audit Evidence Chain Symlink Hardening v1.9.37

## Change

`app/audit-evidence-chain.js` now validates that the configured evidence root is a real directory rather than a symlink, checks each named path component with `lstat`, rejects symlinked parent directories, and opens the final evidence file with `O_NOFOLLOW` where the runtime supports it. File bytes are hashed from the opened descriptor after its file type is checked.

## Security rationale

Previously, the final file was checked for symlink status, but a symlink supplied as the evidence-root path or as an intermediate nested directory could redirect the evidence read outside the intended root. The new checks reject those cases and reduce final-component check/read substitution risk.

## Verification scope

Focused tests exercise a symlinked root and a nested directory symlink using synthetic temporary files. This is defense-in-depth, not a claim that all filesystem race conditions are eliminated. OS/filesystem-specific behavior and a separately controlled staging review remain required.

## Safety boundary

No real land-record data was used or changed. Audit evidence remains integrity evidence, not proof that an external claim is true. Release status remains `RELEASE BLOCKED — NOT RELEASE`.
