# RLA v26 — v1.4.2 Test-Entry Clarity / NOT FOR RELEASE

Date: 2026-10-12

## Change

The default `npm test` command now runs only the dependency-free static source-pattern suite. The SQLite-backed runtime suite is explicitly invoked with `npm run test:runtime`; `npm run test:all` runs both sequentially and is expected to fail until runtime dependencies are installed. This prevents a missing native dependency from being confused with a static-suite failure while keeping runtime checks explicit.

## Executed evidence in the available environment

- Candidate ZIP v1.4.1 SHA-256 before this new packaging step: `68077b49620445582b0f746915377b7394b4b403553bd0d5207f69329fc8074b`.
- Node.js: `v22.16.0`; npm: `10.9.2`.
- `node --test tests/security-candidate.test.js`: PASS, 14 tests, 0 failures.
- `node --test tests/runtime/runtime-integration.test.js`: BLOCKED, process exits before tests load because `sqlite3` cannot be found (`MODULE_NOT_FOUND`).
- Prior npm registry connectivity diagnostic: `EAI_AGAIN` resolving `registry.npmjs.org`.
- Syntax checks for `app/server.js`, `tests/security-candidate.test.js`, and `tests/runtime/runtime-integration.test.js`: PASS.

## Limits

The runtime suite has not executed against a live SQLite-backed server. Therefore bootstrap/restart, API authorization, jurisdiction isolation, concurrent writes, and transaction rollback remain unverified. A test suite that cannot load its dependency is not a runtime pass.

## Release decision

`STATIC_TESTS_PASS · RUNTIME_DEPENDENCY_BLOCKED · RUNTIME_NOT_VERIFIED · RELEASE_BLOCKED`

Do not use real land-record data or deploy to production. Preserve original v1.3, v1.4, and v1.4.1 archives unchanged. Next step: install from an approved network-enabled environment or internal npm mirror, then run `npm run test:runtime` and `npm run test:all` and preserve the raw logs. Also verify migration, maker-checker, user provisioning, jurisdiction-scoped audit, independent security review, penetration testing, UAT, and official approval. Keep GPO (గ్రామ పాలన ఆఫీసర్) role naming, jurisdiction controls, human approval for official land-record changes, and audit trail requirements.
