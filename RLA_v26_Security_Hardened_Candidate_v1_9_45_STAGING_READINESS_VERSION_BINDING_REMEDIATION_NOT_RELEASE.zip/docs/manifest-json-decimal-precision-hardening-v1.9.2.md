# Release-Gate Manifest Decimal Precision Hardening — v1.9.2

The strict JSON manifest parser now compares normalized decimal signatures for finite, non-zero numeric tokens against the shortest decimal representation returned by JavaScript `Number#toString`. If the token's exact decimal value would change during IEEE-754 conversion (for example `0.10000000000000001` to `0.1`), parsing fails closed with `RLA_JSON_NUMBER_PRECISION_LOSS`.

Existing error behavior remains for non-finite overflow, non-zero underflow to zero, and unsafe integer-valued numbers. Explicit zero and negative zero remain permitted. Exact round-tripping values such as `0.1`, `1.2300`, `1e-5`, and `5e-324` are accepted by tests.

This policy may reject numeric formats that a downstream application would otherwise tolerate. Governance-owner approval and independent parser review are required before release. It does not replace schema-level typing or arbitrary-precision decimal types where those are required.
