# RLA v26 v1.9.26 — Registry Allowlist Canonicalization

## Change
The dependency-lockfile preflight now accepts only canonical ASCII DNS hostnames in `RLA_APPROVED_NPM_REGISTRIES` (IDNs must be supplied as punycode). It rejects malformed labels, empty comma-separated entries, single-label names, trailing-dot hostnames, underscore labels, IP literals, non-ASCII hostnames, labels longer than 63 characters, and hostnames longer than 253 characters. Hostname comparisons remain lowercase-normalized and duplicate hosts are deduplicated.

## Why
An allowlist is a security boundary. Silently dropping empty entries and accepting malformed or non-DNS host strings makes configuration review less precise. This change makes the accepted syntax explicit and fails closed before dependency installation.

## Validation
- Valid lowercase and uppercase DNS names are accepted and normalized.
- Punycode-form IDN hostname is accepted.
- URLs, empty entries, malformed labels, trailing dots, IP literals, non-ASCII names, and overlong labels/hostnames are rejected.
- Dependency lockfile, acquisition-plan, and safe npm wrapper tests passed.
- Full offline workflow and JavaScript syntax checks are recorded in `verification-report-v1.9.26.md` and `staging-readiness-evidence-v1.9.26.json`.

## Scope limits
This validates hostname syntax only; it does not establish that a registry is trustworthy, that its metadata is authentic, or that a generated lockfile is safe. Registry ownership, package graph, SHA-512 integrity, install-script policy, native build provenance, and independent approval remain separate gates.

## Release status
`RELEASE BLOCKED — NOT RELEASE`.
