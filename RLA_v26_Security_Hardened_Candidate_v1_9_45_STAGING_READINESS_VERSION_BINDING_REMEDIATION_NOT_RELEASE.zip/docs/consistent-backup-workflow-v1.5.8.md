# RLA v26 — Consistent Backup Workflow (v1.5.8 candidate)

## Scope

This candidate adds `scripts/create-consistent-backup.js` to use the native `sqlite3` package's SQLite online backup API rather than copying a live database file. After the backup API reports completion, the script closes the source connection, validates that the result is a non-empty regular file, sets owner-only file permissions, fsyncs it, atomically publishes the backup, creates an authenticated SHA-256/HMAC manifest, and verifies that manifest against the published artifact. Existing backup/manifest destinations are refused to prevent accidental overwrite. If manifest creation or verification fails, the new artifact is removed rather than left looking complete.

## Operator workflow

1. Store `RLA_BACKUP_MANIFEST_KEY` in the approved secret manager. Never store it in source control, a ZIP, shell history, or logs.
2. Prepare backup and manifest directories with owner-only permissions, and ensure they are on approved storage with sufficient capacity.
3. Invoke the script with an existing SQLite source database and two new destination paths:

```sh
RLA_BACKUP_MANIFEST_KEY="$RLA_BACKUP_MANIFEST_KEY" \
  node scripts/create-consistent-backup.js \
  /var/lib/rla/rla.db \
  /secure/backups/rla-YYYYMMDDTHHMMSS.sqlite \
  /secure/backups/rla-YYYYMMDDTHHMMSS.manifest.json
```

4. Store stdout JSON as access-controlled operational evidence; do not include the secret in it.
5. Before restore, use `scripts/restore-verified-backup.js` with explicit confirmation, verified maintenance stop, and a private staging root. Complete application-level checks before reopening service traffic.
6. Apply approved encryption-at-rest, off-site replication, key rotation, retention, and cleanup controls at the storage/secret-management layer.

## Important limitations

- The native `sqlite3` online-backup path is implemented but could not be executed here because the native npm driver could not be installed. Offline tests use a test double and prove orchestration/fail-closed behavior only; they do not prove SQLite's native backup API or real WAL consistency.
- The script is a CLI and is not yet wired to an application scheduler, system service, monitoring/alerting, key rotation, encryption-at-rest, or off-site copy workflow.
- A production-like backup/restore drill, crash recovery and WAL tests, target filesystem durability checks, independent security review, penetration testing, UAT, and formal approval remain required.
- The destination directories must be private and access-controlled. POSIX group/other permission bits are rejected; Windows ACLs need separate target-host validation.
- No production-readiness, disaster-recovery readiness, RPO/RTO, or native-driver-success claim is made.

## Governance

Retain jurisdiction isolation, immutable audit evidence, maker-checker review, and authorized human approval for official land-record changes. Use **GPO (గ్రామ పాలన ఆఫీసర్)**, not VAO. Backup/restore operators must not be able to silently alter official records or bypass workflow approvals.
