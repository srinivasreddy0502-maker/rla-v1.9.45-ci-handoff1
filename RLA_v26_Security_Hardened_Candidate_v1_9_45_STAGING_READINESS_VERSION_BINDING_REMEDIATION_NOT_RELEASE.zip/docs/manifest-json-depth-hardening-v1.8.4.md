# Release-Gate Manifest JSON Depth Hardening — v1.8.4

## Change

The strict duplicate-key parser now enforces `MAX_JSON_DEPTH = 64` before descending into a JSON object or array. This bounds parser recursion for untrusted release-gate manifests, in addition to the existing 1 MiB manifest byte cap. The limit counts nested object/array containers and is a candidate policy pending governance-owner approval.

## Regression coverage

- Reject a manifest with nesting beyond the configured maximum.
- Accept JSON at the configured nesting boundary.
- Existing duplicate-key, strict UTF-8, manifest-size, evidence-integrity and fail-closed tests remain in the suite.

## Limitations

This is not a full JSON parser certification or proof against all resource-exhaustion vectors. Independent review remains required. Native SQLite backup/restore and target-host recovery are unaffected and remain unverified until native staging tests pass.
