# RLA v26 v1.9.29 — Dependency Lockfile Preflight No-Follow Hardening

## Scope

The dependency lockfile preflight previously read `package.json`, `package-lock.json`, and `config/dependency-install-script-policy.json` using path-based `readFileSync` calls. The v1.9.29 change applies one fail-closed descriptor reader to all three security-sensitive JSON inputs.

## Controls added

- Opens each file with `O_NOFOLLOW`; blocks if the runtime does not expose a usable `O_NOFOLLOW` flag.
- Uses `fstat` on the opened descriptor and requires a regular file.
- Compares device, inode, size, mtime, ctime, mode, and link count before and after the read.
- Checks the UTF-8 decoded byte length against the final descriptor size.
- Rejects symlink paths and blocks if file identity or relevant metadata changes during the read.
- Maps missing, malformed, unsafe-path, and changed-during-read cases to explicit blockers.
- Adds regression tests for symlinked manifest, lockfile, and install-script policy inputs.

## Verification

- Focused dependency lockfile preflight tests: 39 passed, 0 failed, 0 skipped.
- Full offline workflow: 266 passed, 0 failed, 0 skipped across 30 test summaries.
- JavaScript syntax: 67 files checked, 0 failures.
- No network call was performed, no lockfile was created, and `npm ci` was not executed.

## Limitations

This closes a specific path-following and read-time metadata-change window; it is not a proof against every filesystem race or every platform behavior. The approved isolated staging lockfile capture and independent dependency/provenance review remain pending.
