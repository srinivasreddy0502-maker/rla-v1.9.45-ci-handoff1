# RLA v26 — Safe npm Environment Isolation v1.9.13

## Purpose

The safe dependency installer now constructs a controlled child environment rather than passing through inherited npm and Node runtime override settings. This reduces the risk that ambient `npm_config_*`, `NPM_CONFIG_*`, `NODE_OPTIONS`, `NODE_PATH`, or `npm_execpath` variables silently redirect registry access, load injected code, or change npm behavior.

## Controls

- Removes inherited npm configuration variables before invoking npm.
- Removes `NODE_OPTIONS`, `NODE_PATH`, `npm_execpath`, and `npm_node_execpath` from the child environment.
- Pins npm's registry setting to the first explicitly approved registry host.
- Forces `ignore-scripts`, `audit=false`, `fund=false`, and `update-notifier=false` in the child environment, in addition to fixed CLI flags.
- Uses `shell: false` for child execution.
- On Windows, refuses to invoke npm when a trusted npm CLI path was not provided by the npm launcher; it does not fall back to shell execution of `npm.cmd`.
- Keeps the non-zero post-install status because native build and runtime verification remain separate gates.

## Limitations

This control does not replace a reviewed `package-lock.json`, registry administration, certificate validation, dependency provenance review, or isolation of the staging host. Proxy environment variables are preserved for controlled enterprise networking and must be managed by the staging administrator. No installation was executed as part of offline unit tests.

## Release status

`NOT RELEASE`. Native SQLite build, real backup/restore, WAL/crash recovery, clean-host restore drill, independent security review, penetration testing, UAT, and formal governance approval remain required.
