# RLA v26 — Dependency Install-Script Governance v1.9.11

## Purpose

Prevent an npm package lifecycle script from executing merely because it appears in a lockfile. Packages marked `hasInstallScript: true` require an exact package-key, package-name, and version approval before dependency installation is allowed by the RLA preflight.

## Policy file

`config/dependency-install-script-policy.json` ships as `UNAPPROVED_TEMPLATE` with no approvals. This is intentionally fail-closed. A governance owner must review the actual generated lockfile and each lifecycle script, then create an approved policy record containing:

- exact `packageKey`, `packageName`, and version;
- a documented reason and change/security review ticket;
- named approver and review timestamp;
- expiry timestamp later than review time;
- top-level `policyStatus: APPROVED` and a named `policyOwner`.

Wildcards and range versions are not accepted. Expired, duplicate, stale, malformed, or identity-mismatched approvals block installation. The policy file is not a cryptographic signature; its author and approval must be independently authenticated and its contents protected by the package integrity process.

## SQLite caveat

The `sqlite3` package may require a native install/build step. Do not blindly approve it. Review its install behavior, native binary provenance, build toolchain, and target platform first. Until then, the candidate must remain blocked. Do not run install scripts against production data or a production host during verification.

## Validation

Offline unit tests exercise missing approval, exact approved package/version, unapproved policy state, identity mismatch, expired approval, malformed metadata, duplicate approvals, and stale approvals. These tests validate the policy logic only; they do not represent an approved package lockfile or a successful native installation.
