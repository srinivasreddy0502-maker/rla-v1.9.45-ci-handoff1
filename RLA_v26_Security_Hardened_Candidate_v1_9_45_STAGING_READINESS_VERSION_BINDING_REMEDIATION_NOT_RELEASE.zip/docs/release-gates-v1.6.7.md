# Release Gates — v1.6.7

Status: **RELEASE BLOCKED — candidate only**

## Candidate verification

- [x] JavaScript syntax checks for `app/*.js`.
- [x] Full `npm run test:all:offline` command completed successfully.
- [x] New external checkpoint-store tests: 5/5 passed, 0 failed, 0 skipped.
- [x] Store receipt HMAC, checkpoint digest, checkpoint chain match, key-id keyring lookup, overwrite rejection, malformed identifier/weak-key rejection, and tamper detection covered by offline tests.
- [x] Candidate ZIP integrity and SHA-256 recorded in the accompanying verification report.

## Unmet production gates

- [ ] Native npm `sqlite3` driver install and integration tests on the target runtime.
- [ ] Real SQLite backup, restore, WAL/crash recovery, and target-host recovery drill.
- [ ] Connect checkpoint publication to the actual audit-evidence append/backup workflow.
- [ ] Provision and validate genuinely independent/WORM evidence storage and least-privilege identities.
- [ ] Approved secret-manager/KMS integration, rotation runbook, and key custody review.
- [ ] Independent security review and penetration testing.
- [ ] UAT, operational runbooks, monitoring/alert validation, and formal approval.

Offline tests use the candidate's offline adapters/test doubles and Node built-ins; they do not substitute for native-driver or production-storage verification. Do not use this candidate for official land-record mutations or production release until all gates pass. Any official land-record changes must remain subject to authorized human approval and jurisdiction isolation.
