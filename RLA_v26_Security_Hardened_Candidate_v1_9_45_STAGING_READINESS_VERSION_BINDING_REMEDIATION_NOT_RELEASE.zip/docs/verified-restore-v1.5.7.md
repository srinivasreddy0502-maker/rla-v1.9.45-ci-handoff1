# RLA v26 — Verified Restore Wrapper (v1.5.7 candidate)

## Purpose

v1.5.7 adds an operator-gated restore CLI that consumes only a manifest-verified staged backup, checks SQLite integrity and foreign-key consistency, copies the staged bytes to a temporary file beside the target, verifies the copied hash and SQLite checks again, and uses an atomic rename for installation. If an existing database is replaced, the old file is retained at a unique `.pre-restore-*` path.

## Mandatory operator gates

- Stop the application and all database writers before starting; the CLI requires the explicit operator attestation `RLA_RESTORE_MAINTENANCE_MODE=STOPPED`.
- Review the target path and recovery plan; the CLI requires `RLA_RESTORE_CONFIRM=YES`.
- Supply `RLA_BACKUP_MANIFEST_KEY` from the approved secret manager. Never place it in source control, ZIP files, logs, tickets, or shell history.
- The target directory must already exist. Existing `-wal` or `-shm` sidecars cause a fail-closed refusal; investigate them rather than deleting them automatically.
- The script retains the private staged backup and the previous target DB for evidence/recovery. Apply the approved retention policy to both after independent validation.

Example (POSIX shell; use the approved service-stop procedure and secret manager):

```sh
install -d -m 700 /var/lib/rla/restore-staging
RLA_BACKUP_MANIFEST_KEY="$RLA_BACKUP_MANIFEST_KEY" \
RLA_RESTORE_CONFIRM=YES \
RLA_RESTORE_MAINTENANCE_MODE=STOPPED \
node scripts/restore-verified-backup.js \
  /secure/backups/backup.sqlite \
  /secure/backups/backup.manifest.json \
  /var/lib/rla/restore-staging \
  /var/lib/rla/rla.db
```

The maintenance-mode value is an operator attestation, not an automatic proof that the service is stopped. Use this only through a controlled runbook. Restore stdout contains paths and hashes; protect the output as operational evidence.

## Important boundaries

- This is a CLI wrapper; it is not wired into the app server, an operational scheduler, or a deployment orchestrator.
- The native `sqlite3` npm-driver path has not been executed in this environment. Offline tests exercise the repository's existing offline adapter for the existing suite and only preflight/fail-closed behavior for this restore CLI.
- The script expects a valid, consistent SQLite database artifact. Backup creation must use a transaction-safe SQLite backup mechanism or a properly quiesced/checkpointed database procedure; copying a live WAL database file alone is not sufficient evidence of a consistent backup.
- Filesystem atomic rename and fsync behavior depends on the deployment filesystem. Test on the target OS/filesystem before operational use.
- No production release, disaster-recovery readiness, RPO/RTO, or end-to-end restore claim is made by this candidate.

## Release gates

Keep `NOT_RELEASE` until native-driver execution, scheduler-to-manifest integration, target-environment restore drills, application startup and application-level data validation after restore, independent security review, penetration testing, UAT, and formal approval are evidenced.
