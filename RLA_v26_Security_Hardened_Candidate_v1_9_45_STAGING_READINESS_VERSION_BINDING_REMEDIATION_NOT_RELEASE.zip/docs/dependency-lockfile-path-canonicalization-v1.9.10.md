# RLA v26 — Dependency Lockfile Path Canonicalization

**Candidate:** v1.9.10-candidate  
**Status:** Candidate hardening; not a release approval.

## Purpose

Harden the npm lockfile preflight against non-canonical package keys that could contain path traversal segments, backslashes, empty segments, malformed scope/name pairs, or unexpected path components. The validation is deliberately fail-closed.

## Rules added

- Package entries must use canonical `node_modules/<package>` placement, optionally nested under further `node_modules` scopes.
- Scoped packages must contain a valid scope segment and a package-name segment.
- Dot-prefixed names, `.`/`..`, empty segments, backslashes, NULs, and unexpected path components are rejected.
- Invalid keys produce `LOCK_PACKAGE_KEY_NON_CANONICAL` and installation remains blocked.
- Existing exact-version, registry allow-list, HTTPS, SHA-512 SRI, package identity, and dependency-graph checks remain in force.

## Validation

The dependency-lockfile test suite checks traversal attempts, nested/scoped valid keys, malformed paths, and fail-closed behavior. Full offline test suite and JavaScript syntax checks were run for this candidate; results are in the package logs.

## Important limitation

This is a custom preflight hardening layer, not a substitute for npm's own lockfile parser or a reviewed `npm ci` in a clean staging environment. The candidate still has no `package-lock.json` and no available native `sqlite3` driver in this environment. Dependency installation and native SQLite backup/restore remain unverified.
