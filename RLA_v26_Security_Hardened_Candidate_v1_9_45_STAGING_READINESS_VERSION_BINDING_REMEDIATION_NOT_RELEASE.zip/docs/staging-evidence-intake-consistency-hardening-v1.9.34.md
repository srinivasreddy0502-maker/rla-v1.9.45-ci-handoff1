# RLA v26 v1.9.34 — Staging Evidence Intake Consistency Hardening

## Change

This candidate tightens staging evidence intake in three ways:

1. Rejects duplicate evidence-reference IDs so a bundle cannot ambiguously refer to multiple artifacts under the same ID.
2. Rejects evidence references whose canonical UTC `capturedAt` is later than the bundle `generatedAt` timestamp.
3. Adds `evidenceInputDigestSha256` to the intake report and calculates `reportDigestSha256` over the complete report (excluding the digest field itself). This makes changes to the parsed evidence bundle affect the reported digest.

The digest is a tamper-evidence aid, not a digital signature, reviewer authentication, trusted timestamp, or independent proof that referenced evidence is genuine. JSON serialization is not claimed to be a universal canonicalization scheme; use the exact generated report/input bytes and independent artifact verification during formal review.

## Validation

- Focused staging-evidence intake tests cover duplicate IDs, future-relative capture timestamps, digest sensitivity, secure file reading, symbolic links, hard links, writable modes, and input-size bounds.
- Full configured offline workflow is recorded in `RLA_v26_v1_9_34_offline_test.log`.
- JavaScript syntax check and workspace/archive package integrity checks are recorded in accompanying logs.

## Limitations and release decision

The validator checks evidence structure and consistency only. It does not authenticate reviewers or prove that the evidence describes real test execution. A complete bundle remains `EVIDENCE_COMPLETE_PENDING_INDEPENDENT_VERIFICATION`; the tool never grants release authority.

**RELEASE BLOCKED — NOT RELEASE.** `package-lock.json` is missing, `npm ci` was not executed, the native SQLite driver is unavailable, and staging/recovery/security/UAT/governance evidence remains outstanding. Tests must use synthetic data only, never real land records.
