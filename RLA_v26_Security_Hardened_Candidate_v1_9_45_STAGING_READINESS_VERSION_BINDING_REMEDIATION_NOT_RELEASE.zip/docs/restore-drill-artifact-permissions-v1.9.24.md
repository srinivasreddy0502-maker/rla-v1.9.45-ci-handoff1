# RLA v26 v1.9.24 — Restore-Drill Artifact Permission Hardening

## Change
The native SQLite restore-drill now checks that generated backup and restored artifacts are regular non-symlink files and, on POSIX systems, tightens their mode to `0600` before validation and evidence hashing. The evidence directory remains required to be private (`0700` or stricter). Windows does not provide equivalent POSIX mode semantics; ACL review remains part of staging verification.

## Why
Artifact permissions can otherwise depend on the process umask or filesystem defaults. Tightening generated database copies reduces accidental exposure if the evidence directory is later copied or moved. This is defense-in-depth, not a substitute for filesystem ACLs, encryption at rest, or controlled access to the evidence directory.

## Verification
A regression test creates a permissive-mode artifact and verifies it becomes `0600` on POSIX. A symlink artifact is rejected. The focused restore-drill suite passed 18/18 tests.

## Limitations
The native SQLite driver is unavailable in the current environment, and `package-lock.json` is missing. Therefore `npm ci` and a real native database backup/restore were not executed. Release remains blocked.
