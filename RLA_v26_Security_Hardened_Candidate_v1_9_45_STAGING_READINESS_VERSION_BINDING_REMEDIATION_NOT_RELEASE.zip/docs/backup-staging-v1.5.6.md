# RLA v26 — Verified Backup Staging (v1.5.6 candidate)

## Purpose

The v1.5.5 manifest verification protects integrity at the time a file is checked. A separate restore process must not verify one path and later restore from a mutable source path. v1.5.6 adds `stageVerifiedBackup()` and a `stage` CLI command to create a private, verified snapshot for a downstream restore process.

## Workflow

1. Create a manifest for a completed backup using the approved secret key.
2. Before restore, authenticate the manifest and verify the source artifact.
3. Copy the artifact into a newly-created unique directory under an existing private staging root.
4. Set the staged file to owner-only permissions (`0600`) and the unique directory to owner-only (`0700`).
5. Verify the staged copy against the same authenticated manifest, including artifact name, size, and SHA-256 digest.
6. Pass the returned `stagedPath` to the restore implementation. Do not restore from the original backup path.
7. Retain/delete staged artifacts according to the approved recovery and evidence-retention procedure.

Example (POSIX shell; adapt paths to the approved host layout):

```sh
install -d -m 700 /var/lib/rla/restore-staging
RLA_BACKUP_MANIFEST_KEY="$RLA_BACKUP_MANIFEST_KEY" \
  node scripts/backup-manifest.js stage \
  /secure/backups/backup.sqlite \
  /secure/backups/backup.manifest.json \
  /var/lib/rla/restore-staging
```

The CLI emits JSON including `stagedPath`. Capture it through a controlled deployment/restore wrapper; do not paste secrets into command history, logs, tickets, or the repository. `RLA_BACKUP_MANIFEST_KEY` must come from the approved secret manager and must not be embedded in this ZIP.

## Security behavior

- Rejects a backup input that is a symbolic link or not a non-empty regular file.
- Requires an existing staging root; on POSIX, the root must not grant group/other permissions.
- Creates a unique private staging directory and owner-only staged file.
- Verifies the copied staged artifact after copying, so a source mutation during copy cannot silently produce an accepted mismatched snapshot.
- Removes the newly created staging directory if staging fails.

## Limits / release gates

- Staging is a helper utility and CLI, not yet wired into the application's actual backup scheduler or restore endpoint.
- This does not prove SQLite database consistency, transaction-safe backup creation, restore correctness, recovery-point objectives, or disaster-recovery readiness.
- A privileged actor able to modify the private staging directory may still affect the file; OS/service-account isolation and controlled restore execution remain required.
- Native `sqlite3` npm-driver integration remains unverified where the package cannot be installed from the registry.
- Keep the candidate `NOT_RELEASE` until operational backup/restore integration, native-driver tests, independent security review, penetration testing, UAT, and formal workflow approval pass.
