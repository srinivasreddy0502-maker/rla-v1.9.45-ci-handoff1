# RLA v26 v1.6.0 Release Gates

Status: **NOT RELEASE — RELEASE BLOCKED**.

- [x] Existing offline static security suite passes.
- [x] Existing offline runtime adapter suite passes.
- [x] Backup/restore helper tests pass using injected test doubles.
- [x] New backup preflight checks key shape, native API shape, paths, permissions and overwrite protection.
- [x] ZIP archive integrity checked.
- [ ] Install and load the actual native `sqlite3` npm package in the target runtime.
- [ ] Run backup/restore end-to-end against a real SQLite database with WAL enabled and concurrent writes.
- [ ] Test process termination, disk-full, permission failure and crash recovery paths.
- [ ] Deploy scheduler/locking/alerts only after operator approval; no scheduler is enabled by this package.
- [ ] Validate off-site replication, retention, encryption at rest and key rotation.
- [ ] Run target-host restore drill and application-level post-restore validation.
- [ ] Complete independent security review, penetration test, UAT and formal sign-off.

A passing preflight or offline adapter suite is not evidence of a successful production backup or restore. Keep previous candidate ZIPs immutable. Preserve jurisdiction isolation, audit trail, maker-checker and authorized human approval for official land-record mutations. Role label: **GPO (గ్రామ పాలన ఆఫీసర్)**.
