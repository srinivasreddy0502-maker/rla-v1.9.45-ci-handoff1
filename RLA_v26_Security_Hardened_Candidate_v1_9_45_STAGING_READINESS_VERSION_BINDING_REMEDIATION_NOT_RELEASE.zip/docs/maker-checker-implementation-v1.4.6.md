# RLA v26 — Maker–Checker Implementation v1.4.6

Status: CANDIDATE IMPLEMENTATION; NOT FOR RELEASE

## API contract
- `POST /api/applications/:id/transition-requests` creates a pending request and does not mutate application state. Requires `applications:transition_request`.
- `POST /api/applications/:id/transition-requests/:requestId/decision` accepts `APPROVE` or `REJECT`; requires `applications:approve_transition`.
- Legacy `POST /api/applications/:id/transition` returns `410 MAKER_CHECKER_REQUIRED` and cannot mutate state.

## Controls implemented
- Maker and checker are compared by immutable user IDs.
- Approval requires a distinct checker, explicit permission, and matching jurisdiction.
- Request digest binds application, maker, jurisdiction, from/to state, and expected version.
- State version/state are rechecked at decision time. Stale requests are marked `STALE`.
- Approval updates application, consumes pending request, and appends audit in one transaction.
- Rejection is auditable and does not mutate application state.
- Decision consumption uses a `WHERE status='PENDING'` predicate to prevent replay.

## Verification performed
- Static tests: 14/14 PASS.
- Offline compatibility runtime suite backed by Node.js `node:sqlite`: 7/7 PASS.
- JavaScript syntax checks: PASS.
- Native npm `sqlite3` driver: NOT VERIFIED (registry/network blocker).

## Remaining release gates
- Execute full suite with declared native `sqlite3` driver and supported Node.js LTS version.
- Test approval audit-write failure rollback, migration from all supported production schemas, user provisioning/revocation and token lifecycle.
- Independent security review, penetration test, legal workflow/role mapping approval, UAT, deployment/backup/restore validation.
- Do not use real land-record data or deploy to production until all gates are signed off.
