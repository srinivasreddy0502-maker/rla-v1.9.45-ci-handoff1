# Audit Evidence Checkpoints — v1.6.6

## Purpose
Create a signed checkpoint of the current audit evidence chain head. The checkpoint records the count and final record digest, authenticated with HMAC-SHA256. An independently stored checkpoint can reveal if the local chain was later altered or truncated.

## Commands
```sh
RLA_AUDIT_EVIDENCE_KEY='<secret-from-approved-secret-manager>' node scripts/create-audit-checkpoint.js <private-records-dir> <new-checkpoint-path>
RLA_AUDIT_EVIDENCE_KEY='<secret-from-approved-secret-manager>' node scripts/verify-audit-checkpoint.js <private-records-dir> <checkpoint-path>
```

Checkpoint creation is exclusive: existing files are never overwritten. The verifier checks checkpoint HMAC and compares the signed record count and chain-head digest to the current chain. Store checkpoints in a separately administered append-only/WORM system for stronger tamper resistance.

## Limitations
A checkpoint stored beside the chain with the same access controls is not an independent trust anchor. HMAC does not prove event truth and requires external key custody. This feature is not yet integrated into production audit workflows. Native sqlite3 backup/restore remains unverified.
