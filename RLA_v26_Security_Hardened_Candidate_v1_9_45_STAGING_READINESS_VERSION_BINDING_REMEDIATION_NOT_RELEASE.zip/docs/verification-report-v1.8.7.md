# RLA v26 — Security-Hardened Candidate v1.8.7 Verification Report

**Status: RELEASE BLOCKED — NOT RELEASE**

## Change under test

Release-gate manifest JSON parsing now rejects strings and object keys that decode to lone UTF-16 surrogate code units. Valid surrogate pairs remain accepted. The parser reports `RLA_JSON_LONE_SURROGATE` for this condition.

## Verification results

- Offline suite: **161 passed, 0 failed, 0 skipped** (`npm run test:all:offline`).
- Release-gate evidence focused suite: **28 passed, 0 failed, 0 skipped**.
- JavaScript syntax checks: **48 passed, 0 failed**.
- ZIP archive integrity: **PASS** (`unzip -t` succeeded; 246 entries).
- Native SQLite preflight exit code: **2**. Exact output is retained in `docs/native-sqlite-preflight-v1.8.7.txt`.
- Native backup/restore and WAL/crash-recovery drill: **NOT RUN / NOT VERIFIED** because the native SQLite dependency preflight is blocked in this runtime.

## Existing controls retained

The candidate retains strict UTF-8 decoding, UTF-8 BOM rejection, duplicate JSON key rejection, a 1 MiB manifest size cap, a 64-level nesting cap, a 25,000-node cap, review freshness checks, evidence digest checks, symlink/hard-link checks, and fail-closed release-gate behavior.

## Scope and limitations

Offline tests do not establish production readiness. This parser change does not authenticate reviewers, prove approval authority, or grant release authority. Windows ACL validation, independent security review, penetration testing, target-host restore validation, UAT, and formal approval remain outstanding.

## Release decision

**Do not deploy to production.** Continue to block release until native SQLite backup/restore, WAL/crash recovery, integrity/foreign-key checks, independent security review, penetration testing, UAT, audit/WORM evidence validation, and formal release approval have all been completed with retained evidence.
