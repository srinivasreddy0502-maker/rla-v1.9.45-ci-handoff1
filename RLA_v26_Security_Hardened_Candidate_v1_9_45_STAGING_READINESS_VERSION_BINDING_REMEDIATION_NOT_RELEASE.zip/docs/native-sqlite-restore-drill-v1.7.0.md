# RLA v26 — Native SQLite Restore Drill Harness v1.7.0

**Candidate status:** NOT RELEASE / RELEASE BLOCKED

## Purpose

This harness is intended to perform an actual `npm sqlite3` driver backup into an isolated evidence directory, copy that backup to a separate isolated restore file, and validate source, backup, and restored files with `PRAGMA integrity_check` and `PRAGMA foreign_key_check`. It never replaces the source database. The restore output is a drill artifact, not a production restore.

## Commands

1. Install dependencies in a controlled build environment using the approved lockfile and package registry policy.
2. Run `npm run preflight:native-sqlite`. A missing or unloadable native driver returns exit code 2 and a `BLOCKED` JSON result.
3. Prepare a read-only source database path and a separately administered evidence directory with mode `0700` (Unix-like systems).
4. Call `runNativeRestoreDrill({ sourceDbPath, evidenceDir, runId })` from a controlled runner. The evidence directory must be separate from the source database directory. Preserve generated backup, restored database, and manifest as evidence.
5. Independently inspect manifest hashes, table validation, application-level invariants, timestamps, and operator/reviewer records. Do not infer production recoverability from this harness alone.

## Safety properties

- Opens the source database read-only.
- Uses SQLite's native backup API rather than copying the live source file as the backup operation.
- Creates unique backup, restored-copy, and manifest artifacts; it does not overwrite existing run IDs.
- Checks regular files and rejects symlinks at source-path validation.
- Uses exclusive creation for the manifest and records hashes plus SQLite integrity checks.
- Does not delete evidence automatically after partial failure.

## Not covered / release blockers

- Native driver has not been installed or proven available in this environment; a real restore drill is therefore **NOT RUN** here.
- WAL/concurrent-writer/crash/power-loss/disk-full scenarios and filesystem-specific semantics require target-host tests.
- This is not an application-level data correctness, point-in-time recovery, encryption, key-management, retention, or WORM guarantee.
- Production database replacement, production audit integration, independent security review, penetration testing, UAT, and formal approval remain separate mandatory gates.
