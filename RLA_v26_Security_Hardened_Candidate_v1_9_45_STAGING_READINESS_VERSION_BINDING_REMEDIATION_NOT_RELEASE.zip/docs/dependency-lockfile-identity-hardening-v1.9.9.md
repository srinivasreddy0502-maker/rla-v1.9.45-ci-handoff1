# RLA v26 v1.9.9 — Dependency Lockfile Identity Hardening

## Scope

This candidate extends the offline npm lockfile preflight to validate identity and version metadata for every non-root package entry in the `packages` map.

## Controls added

- Each non-root package entry must use a key with a valid `node_modules` package path.
- The package entry must carry an exact version string matching the project's accepted version syntax.
- When an entry includes `name`, it must match the package name inferred from its lockfile path, including scoped packages such as `@scope/name`.
- Any mismatch adds a blocker and keeps `installAllowed` false.
- Tests cover missing transitive versions, package-name mismatch, and scoped package path parsing.

## Limitations

These are structural preflight checks, not a full npm or semver implementation. They do not prove registry authenticity, package safety, successful installation, native-driver loading, or production readiness. The candidate has no `package-lock.json`; the preflight therefore remains blocked. No `npm ci` or real Native SQLite runtime test was performed.
