# Release-Gate Review Timestamp Hardening — v1.8.0

## Change

- Review timestamps on `PASS` evidence must now use an unambiguous UTC form: `YYYY-MM-DDTHH:mm:ssZ`.
- Invalid calendar dates and non-canonical timestamp representations are rejected.
- Review timestamps in the future are rejected.
- This check is metadata validation only; it does not prove the reviewer identity, timestamp source, or approval authenticity. Those require independently trusted identity and audit systems.
- Release authority remains false in the evaluation result; evidence validation cannot authorize deployment.

## Tests

- Existing valid UTC review timestamp accepted.
- Ambiguous timestamp rejected.
- Future timestamp rejected.
- Focused release-gate evidence tests pass.

## Limitations

System clock correctness is assumed for the future-time check. A privileged actor able to change the host clock may affect this check. Use a trusted time source and externally anchored audit/WORM evidence for formal approval workflows. Native SQLite restore remains unverified in this runtime.
