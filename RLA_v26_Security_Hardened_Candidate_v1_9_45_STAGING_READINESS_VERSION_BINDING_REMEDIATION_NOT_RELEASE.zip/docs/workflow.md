# Workflow
INTAKE → EVIDENCE → VALIDATION → OFFICER_REVIEW → AUTHORITY → ORDER → RECORD_UPDATE → NOTIFICATION → CLOSED.

Transitions require the expected version and an allowed next state. Exact statutory workflow variants must be validated against current authorised requirements before production.
