# RLA v26 — v1.7.2 Restore Drill Consistency Controls

Status: NOT RELEASE / RELEASE BLOCKED.

## Changes
- Restore drill records source SHA-256 before and after the backup operation.
- The drill fails closed if the source file hash changes during the drill.
- Backup and restored-copy SHA-256 values must match.
- Source, backup, and restored copies must all pass integrity and foreign-key checks and have matching user-table inventories.
- The manifest records the additional source-after hash and consistency result.
- This only validates a stable main database file; SQLite WAL/concurrent-write consistency still requires a controlled target-host drill and explicit WAL handling.

## Verification limits
Offline unit tests exercise consistency rules. They do not prove native `sqlite3` is installed or that a real native restore drill ran. Driver absence remains a hard block. No production database is replaced.
