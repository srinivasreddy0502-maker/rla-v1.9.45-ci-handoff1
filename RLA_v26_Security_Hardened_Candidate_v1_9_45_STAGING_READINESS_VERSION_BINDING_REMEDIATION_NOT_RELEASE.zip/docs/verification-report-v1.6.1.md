# RLA v26 — v1.6.1 Scheduler Locking Verification

**Status:** NOT RELEASE / RELEASE BLOCKED  
**Candidate package version:** `0.8.1-candidate`  
**Verification date:** 2026-10-12

## Change scope

- Added `app/scheduler-lock.js`, using atomic directory creation for exclusive lock acquisition.
- Stores private owner metadata with PID, timestamp, and a random ownership token.
- Release requires token match and rejects symlinks/non-regular metadata.
- Existing or partially initialized locks are never automatically reclaimed; stale-lock cleanup requires operator review.
- Added `scripts/run-scheduled-backup.js` to wrap the consistent-backup helper with lock acquisition/release.
- Added five tests for lock acquire/release, competing invocation, ownership mismatch, parent-directory permissions, and missing metadata.

## Offline test results

- Static security suite: 14/14 PASS.
- Offline runtime integration: 12/12 PASS.
- Multi-process concurrent writes: 1/1 PASS.
- Concurrent bootstrap: 1/1 PASS.
- Bootstrap stress: 10 iterations passed; test runner reports 11 tests including the parent test.
- Migration rollback: 1/1 PASS.
- Offline backup/restore smoke: 1/1 PASS.
- Backup integrity and staging: 8/8 PASS.
- Restore preflight: 3/3 PASS.
- Consistent backup workflow: 5/5 PASS.
- Backup/restore pipeline: 5/5 PASS.
- Backup preflight: 5/5 PASS.
- Scheduler lock tests: 5/5 PASS.
- New-file Node.js syntax checks: PASS.
- ZIP integrity: PASS.

The offline runtime suite uses the existing Node.js `node:sqlite` adapter and test doubles. It is not native npm `sqlite3` driver verification.

## Security limitations

- The scheduler wrapper is not connected to the production scheduler, application service, monitoring, or deployment orchestrator.
- File locks coordinate only where the target filesystem guarantees atomic directory creation; multi-host/network filesystem semantics require validation.
- A stale lock is intentionally not auto-recovered. An operator must establish that no backup process is active before approved cleanup.
- Native `sqlite3` installation and actual online-backup API execution remain unverified in this environment due prior npm registry DNS/network failures.
- No production database, real target host, off-site replica, alert delivery, crash recovery drill, or disaster recovery exercise was tested.
- RPO/RTO and operational recovery readiness are not claimed.

## Remaining release gates

1. Native npm `sqlite3` installation and actual backup/restore execution.
2. Target filesystem/OS validation, including atomicity, fsync, permissions, and network filesystem behavior if used.
3. Production scheduler integration, monitoring, alerting, retry policy, and retention controls.
4. WAL/concurrent-write/crash recovery tests and target-host restore drill.
5. Application-level post-restore validation and measured RPO/RTO evidence.
6. Independent security review, penetration testing, UAT, and formal approval.

## Governance

Preserve GPO (గ్రామ పాలన ఆఫీసర్) role naming, jurisdiction isolation, audit trails, and authorized human approval for official land-record changes. Earlier candidate ZIPs remain unchanged.
