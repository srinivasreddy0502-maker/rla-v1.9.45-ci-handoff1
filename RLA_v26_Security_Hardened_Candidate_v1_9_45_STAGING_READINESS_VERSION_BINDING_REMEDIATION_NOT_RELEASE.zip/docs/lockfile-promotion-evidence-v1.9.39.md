# RLA v26 — Controlled Lockfile Promotion Evidence (v1.9.39)

## Purpose

Validate consistency of an operator-supplied dependency-lockfile capture evidence bundle against the staged `package.json` and `package-lock.json`. This is an offline consistency check, not proof that a staging system, registry, TLS session, reviewer, or command execution is genuine.

## Safety boundary

- Do not generate a lockfile in the release workspace.
- Capture only in an explicitly approved, isolated staging environment.
- Use an explicitly configured HTTPS registry origin that matches the approved host allowlist.
- Capture with `npm install --package-lock-only --ignore-scripts --no-audit --no-fund --lockfile-version=3 --registry=<approved-origin>`.
- Do not run `npm ci` as part of lockfile capture. Native `sqlite3` install/build provenance and smoke testing are separate review gates.
- Evidence must identify the operator and a distinct reviewer (maker-checker separation), bind exact package/lockfile byte counts and SHA-256 digests, and reference dependency graph/provenance review records.
- A consistent result is only `EVIDENCE_CONSISTENT_PENDING_EXTERNAL_ATTESTATION`. The validator never grants production authority and always reports `RELEASE_BLOCKED`.

## Evidence schema

The JSON input contains: `schemaVersion`, `candidateVersion`, canonical UTC `generatedAt`; `staging` approval/isolation/environment/operator identifiers; `registry` origin/TLS/HTTP response fields; `capture` exact argv, exit status, network and install-script assertions, npm/Node versions and isolated working-directory assertion; `lockfile` SHA-256, byte count, lockfile version, package manifest SHA-256, dependency graph review reference and provenance review status; and independent `review` identity/time/reference.

The capture and review fields are evidence assertions supplied by the operator. This validator checks their shape and consistency, not their authenticity. Independently corroborate them against staging logs, registry records, reviewer identity, change ticket and signed/immutable audit evidence before promotion.

## Run

```sh
RLA_APPROVED_NPM_REGISTRIES=registry.npmjs.org \
  node scripts/validate-lockfile-promotion-evidence.js /secure/evidence/lockfile-capture.json /secure/staging/candidate
```

The registry allowlist shown is an example only; use the authority-approved value for the actual environment. The script reads evidence and staged package files without following symlinks and does not install dependencies or access the network.

## Required independent gates after consistency validation

1. Validate the complete lockfile dependency graph and registry integrity metadata with the dependency-lockfile preflight.
2. Independently review the lockfile diff and provenance; verify captured artifacts against staging records.
3. Review install-script policy and separately attest the native SQLite binary/source build, runtime ABI, OS and architecture.
4. In isolated staging only, run the approved safe install flow after review and perform SQLite smoke, migration/rollback, concurrency, integrity and backup/restore/recovery drills.
5. Complete independent security review, authorized penetration testing, UAT, audit-evidence review and formal governance approval.

Until every mandatory gate has real evidence and authorized approval, retain `RELEASE BLOCKED — NOT RELEASE`. Do not use real land records for tests.
