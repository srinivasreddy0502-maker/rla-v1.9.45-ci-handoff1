# Release-Gate Manifest UTF-8 BOM Hardening — v1.8.6

## Change

The strict release-gate JSON parser now explicitly rejects a UTF-8 byte-order mark (BOM), both when presented as the three leading UTF-8 bytes and when a string input begins with U+FEFF. This avoids silent decoder normalization where the bytes reviewed or hashed can differ from the logical text parsed by the application.

## Validation

- Added a raw UTF-8 BOM manifest rejection test.
- Added a string-leading U+FEFF parser rejection test.
- Existing strict UTF-8, duplicate-key, JSON whitespace, nesting-depth, node-count and size checks remain in place.

## Limits

This is a parser-hardening control only. It does not establish the authenticity of reviewer identity or approvals, does not provide Windows ACL validation, and does not remove all filesystem TOCTOU risks. Candidate policy changes require governance-owner approval.

## Release status

`RELEASE BLOCKED — NOT RELEASE`. Native SQLite backup/restore and WAL/crash-recovery drills remain unverified until run in the target-like staging environment with the approved native driver.
