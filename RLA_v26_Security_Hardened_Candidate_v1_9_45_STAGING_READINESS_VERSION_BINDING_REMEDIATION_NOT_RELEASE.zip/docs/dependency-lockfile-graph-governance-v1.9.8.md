# RLA v26 v1.9.8 — Dependency Lockfile Graph Governance

**Status:** Candidate-only; release remains blocked.

## Purpose

A syntactically valid npm `package-lock.json` is not sufficient if a package's declared dependency points to a package entry absent from the lockfile. v1.9.8 checks the dependency edges declared by each lockfile package entry before installation is allowed.

## Rules

- Check `dependencies` and `optionalDependencies` entries for every package record in `packages`.
- Each dependency name must resolve to a package entry in the nearest applicable `node_modules` scope, searching parent scopes as Node's package lookup does.
- A missing target blocks installation with `LOCK_DEPENDENCY_TARGET_MISSING`.
- A malformed dependency declaration or non-string/empty dependency specification blocks installation.
- Existing exact direct dependency pinning, package identity checks, approved HTTPS registry hostname checks, and SHA-512 SRI checks remain in force.
- A PASS only means these static lockfile checks passed. It does not prove the lockfile was created from trusted registry metadata, that install scripts are safe, or that native modules work on the target host.

## Test coverage

Added regression cases for a dangling transitive dependency, a dependency available at the root scope, a nested dependency scope, and malformed dependency declarations.

## Operational limitation

The candidate still has no reviewed `package-lock.json`; the real dependency preflight is expected to fail closed with `PACKAGE_LOCK_JSON_MISSING`. Native SQLite installation and real database recovery drills remain unverified.
