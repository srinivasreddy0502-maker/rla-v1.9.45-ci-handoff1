# RLA v26 v1.9.20 — SemVer Safe-Integer Hardening

## Change

The dependency lockfile preflight now rejects SemVer major/minor/patch numeric components that cannot be represented exactly by JavaScript `Number`. Previously, a value larger than `Number.MAX_SAFE_INTEGER` could be rounded during comparisons, making a version-range decision unreliable.

## Controls

- `parseSemverVersion` fails closed when any core numeric component is not a safe integer.
- Direct dependency pins and locked package versions use the same safe exact-version check.
- Unsupported/unsafe values block installation; they are not normalized or guessed.
- Added regression coverage for unsafe major, minor, and patch components, the maximum safe integer boundary, range evaluation, and direct dependency pin rejection.

## Limitations

This does not implement all npm SemVer range syntax. Unsupported syntax must continue to fail closed. It does not establish package provenance, validate a real lockfile, prove dependency installation, or authorize release.
